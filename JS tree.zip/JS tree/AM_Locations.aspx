﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AM_Locations.aspx.cs" MasterPageFile="~/LayoutMaster.Master" Culture="auto" UICulture="auto" Inherits="SummitWeb.MDLAssetMgmt.AM_Locations" %>

<%@ Register Src="~/UserControls/UC_InstanceDDL.ascx" TagName="UCInstance" TagPrefix="UC" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <%: Scripts.Render("~/bundle/Asset/js") %>
    <style>
        .jstree-default .jstree-closed > .jstree-ocl {
            position: relative;
        }

            .jstree-default .jstree-closed > .jstree-ocl:before {
                position: absolute;
                font-family: FontAwesome;
                content: "\f055";
                font-size: 28px;
                font-style: normal;
                color: #a9b3bd;
                top: 6px;
                left: 0px;
            }

        .jstree-default .jstree-open > .jstree-ocl {
            background-image: none !important;
        }

        .jstree-default .jstree-open > .jstree-ocl {
            position: relative;
        }

            .jstree-default .jstree-open > .jstree-ocl:before {
                position: absolute;
                font-family: FontAwesome;
                content: "\f056";
                font-size: 28px;
                font-style: normal;
                color: #a9b3bd;
                top: 6px;
                left: 0;
            }

        .jstree-default .jstree-closed > .jstree-ocl {
            background-image: none !important;
        }

        .jstree-anchor {
            background-color: #f6f6f6;
            color: #737373;
            box-shadow: none;
            border: 1px solid #dedede;
            margin: 0;
        }

        .jstree-node {
            padding: 10px 0;
        }

        .jstree-default .jstree-anchor {
            height: 35px;
            line-height: 30px;
            margin-left: 5px;
            width: 40%;
            padding-left: 10px;
        }

        .jstree-default .jstree-clicked {
            background-color: #6dabd0;
            border: 1px solid #2dcc70;
            color: #fff;
        }

        .jstree-default .jstree-node, .jstree-default .jstree-icon {
        }
        /*.jstree-default .jstree-anchor, .jstree-default .jstree-wholerow{ background:url('../images/tick-white.png') scroll right center no-repeat;
               }*/
        .jstree input {
            height: 30px !important;
            color: #777;
            font-size: 13px;
            border: 1px solid #dedede;
            min-width: 100px;
            margin-top: 1px;
        }

        .jstree-default .jstree-no-icons .jstree-anchor > .jstree-themeicon {
            display: inline-block;
        }

        .default-node > a {
            border-left: 4px solid #2ecb70 !important;
        }

        .inactive-node > a {
            border-left: 4px solid #d86344 !important;
        }

        .new-node > a {
            border-left: 4px solid #e8d829 !important;
        }

        .legend .legend-item {
            float: left;
            margin-right: 3px;
            padding: 8px;
        }

        .legend .default {
            background-color: #2ecb70;
        }

        .legend .inactive {
            background-color: #d86344;
        }

        .legend .newnode {
            background-color: #e8d829;
        }

        .legend .txt {
            float: left;
        }

        .action-name:hover {
            text-decoration: underline;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="BodyContentPlaceHolder" runat="server">
    <div ng-controller="AssetController">
        <div class="page-header">
            <div class="col-xs-12 pad-left-zero">
                <div class="col-xs-3 pad-left-zero">
                    <div class="page-title">
                        <h3>
                            <asp:Localize ID="lblTitle" runat="server" Meta:resourcekey="lblTitleResource"></asp:Localize>
                        </h3>
                    </div>
                </div>
                <div class="col-xs-8 col-md-8 col-sm-8 pad-right-zero">
                    <div class="col-sm-6 col-md-6 btns-container pad-right-zero align-right">
                        <asp:Button ID="btnSave" runat="server" Text="<%$ Resources:GlobalResources, btnSave %>" CssClass="btn btn-primary" OnClick="btnSave_Click" OnClientClick="return Validate();" />
                        <asp:Button ID="btnCancel" runat="server" Text="<%$ Resources:GlobalResources, btnCancel %>" CssClass="btn btn-primary cancel" OnClientClick="return ValidateCancel();" />
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 disp-table">
                <div class="col-xs-2 pad-left-zero disp-tbl-cell">
                    <div class="instance-select-wrapper">
                        <h3 class="instance-title">
                            <%--<asp:Localize ID="lblselect" runat="server" Text="<%$ Resources:GlobalResources, Department %>"></asp:Localize>--%>
                            <asp:Label ID="lblInstanceName" runat="server" CssClass="mandatoryField"></asp:Label></h3>
                        <UC:UCInstance ID="UCInstanceList" runat="server" />
                    </div>

                </div>
                <div class="col-xs-9 disp-tbl-cell gv-container">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-6 col-lg-6 grid-pnl-title">
                                    <asp:Localize ID="lblDetails" runat="server" Text="<%$Resources:GlobalResources,Details %>"></asp:Localize>
                                </div>
                               <div class="col-xs-6 col-lg-6 padding-top-10px">
                                    <div class="col-md-3 col-xs-3 legend padding-zero">
                                        <span class="legend-item inactive"></span>
                                        <span class="txt">
                                            <%=GetLocalMessage("Inactive") %>
                                        </span>
                                    </div>
                                    <div class="col-md-3 col-xs-3 legend padding-zero">
                                        <span class="legend-item newnode"></span><span class="txt">
                                            <%=GetLocalMessage("NewNode") %>
                                      </span>
                                    </div>
                                    <div class="col-md-6 col-xs-6 align-right">
                                        <asp:CheckBox ID="chkIncDeactive" runat="server" CssClass="checkbox-with-label"
                                            AutoPostBack="True" Text="<%$ Resources:Globalresources, IncludeInactive %>" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body pad-left-zero">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <div class="pull-right">
                                        <i class="fa fa-info-circle" style="font-size: 16px;"></i>
                                        <asp:Label ID="lblInfo" runat="server" meta:resourcekey="lblInfo" CssClass="lbl-note"></asp:Label>
                                    </div>
                                    <div id="locationTree" class="category-treeview">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-1 disp-tbl-cell">
                    <div class="action-container">
                        <div class="action-title">
                            <asp:Localize ID="lblActions" runat="server" Text="<%$Resources:GlobalResources,Action %>"></asp:Localize>
                        </div>
                        <div class="actions-content col-xs-12">
                            <%--<div class="action col-xs-6">
                                <a href="AM_Locations_List.aspx" class="show-list-btn">
                                    <span class="action-name">
                                        <asp:Localize ID="lblShowList" runat="server" Text="<%$Resources:GlobalResources,Showlist %>"></asp:Localize>
                                    </span>
                                </a>
                            </div>--%>
                            <div class="actions action col-xs-6">
                                <a id="toggleTree" class="icon fa fa-expand" href="javascript:void(0)" style="font-size: 20px; color: #7c7c7c; text-decoration: none;" title='<%=GetLocalMessage("ExpandAllTooltip") %>'>
                                    <span class="action-name">
                                        <asp:Label ID="lblExpandAll" runat="server"></asp:Label>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <asp:HiddenField ID="hdnLoc" runat="server" />
    <script src="../Includes/plugins/jstree/jstree.dnd.js"></script>
    <script src="../Includes/plugins/jstree/jstree.search.js"></script>
    <script src="../Includes/plugins/jstree/jstree.contextmenu.js"></script>
    <script src="../Includes/plugins/jstree/jstree.state.js"></script>
    <script src="../Includes/plugins/jstree/jstree.wholerow.js"></script>
    <asp:HiddenField ID="hdnCategoryID" runat="server" Value="" />
    <asp:HiddenField ID="hdnLastCategoryId" runat="server" />
    <asp:HiddenField ID="hdnInitialCatId" runat="server" />
    <asp:HiddenField ID="hdnData" runat="server" />
    <asp:HiddenField ID="hdnInstanceInitialCatId" runat="server" />
    <asp:HiddenField ID="hdnEnable" runat="server" />
    <script>
        var ControllerScope;
        var Type;
        var Initialize = function () {
            var OrgID = '<%=OrgID %>';
            var UserID = '<%=UserID %>';
            var Instance = $('#<%=UCInstanceList.Instance.ClientID %>').val();

            ControllerScope = AssetControllerScope();
            ControllerScope.init({ Instance: Instance, OrgID: Number(OrgID), userid: UserID, IncludeInActive: $("#BodyContentPlaceHolder_chkIncDeactive").prop('checked').toString() });

            form = $("#form1");
            $('#<%=UCInstanceList.Instance.ClientID %>').change(function () {
                blockUI();
            });
            $('#<%=chkIncDeactive.ClientID %>').change(function () {
                blockUI();
            });

            ControllerScope.getAllLocationsTree(categoryLoaded);

            ControllerScope.init({ orgid: OrgID, userid: UserID, instance: Instance, IncludeInActive: "true" });
            ControllerScope.getAllLocationsTree(locationLoadedIncludingInactive);

            InitializeSelect2();

            $("#toggleTree").click(function (e) {
                fnToggleTree();
            });
            //  ControllerScope.GetAllLocationTree(categoryLoaded);

        }
        var jsonObj = [];
        var LocationList;
        function categoryLoaded() {
            //console.log(ControllerScope.GetAllLocationTree);
            LocationList = ControllerScope.GetAllLocationTree;
            $('#locationTree').jstree({
                "plugins": ["search", "types", "themes", "ui", "dnd", "contextmenu"],
                "core": {
                    "animation": 0,
                    "check_callback": true,
                    "themes": { "stripes": false, "icons": false },
                    'data': ControllerScope.GetAllLocationTree
                },
                'search': { 'fuzzy': false },
                'types': {


                    "location": {
                        "icon": "../Includes/plugins/jstree/dist/Images/Location-icon.png",
                        "valid_children": ["default", "store", "location", "floor"]
                    },
                    "Location": {
                        "icon": "../Includes/plugins/jstree/dist/Images/Location-icon.png",
                        "valid_children": ["default", "store", "location", "floor"]
                    },
                    "store": {
                        "icon": "../Includes/plugins/jstree/dist/Images/Store-icon.png",
                        "valid_children": []
                    },

                    "floor": {
                        "icon": "../Includes/plugins/jstree/dist/Images/Floor-icon.png",
                        "valid_children": []
                    }
                },
                "contextmenu": {
                    "items": fnContextMenu
                }

            }).bind("create_node.jstree", function (e, data) {
                var item = {}
                fnGenerateNewId();
                item["id"] = data.node.id;
                item["text"] = data.node.text;
                item["action"] = "CREATE";
                item["cid"] = newId.toString();
                item["Active"] = "1";
                if ($.isNumeric(data.node.parent)) {
                    item["parent"] = data.node.parent;
                }
                else {
                    item["parent"] = fnGetCIDFromLocalObject(data.node.parent);
                }
                //if (data.node.icon == '../Includes/plugins/jstree/dist/Images/Store-icon.png')
                if (Type == 'Store') {
                    item["type"] = "Store";
                }
                    //else if (data.node.icon == '../Includes/plugins/jstree/dist/Images/Floor-icon.png') {
                else if (Type == 'Floor') {
                    item["type"] = "Floor";
                }
                else {
                    item["type"] = "Location";
                }
                data.node.li_attr.class = "new-node";
                $("#locationTree").jstree(true).redraw_node(data.node.id, true);
                fnAddItemtoJSON(item);
            }).bind("rename_node.jstree", function (e, data) {
                var proceed = true;
                if ($("#BodyContentPlaceHolder_chkIncDeactive").prop('checked') == false) {
                    if (typeof (LocationListIncludingInActive) != 'undefined') {
                        $.each(LocationListIncludingInActive, function (key, value) {
                            if (value.text == data.node.text && value.parent == data.node.parent && data.node.text != data.old) {
                                data.node.text = data.old;
                                $("#locationTree").jstree(true).redraw_node(data.node.id, true);
                                <%--bootbox.alert('<%= GetLocalMessage("NodeExists") %>');--%>
                                InitOnScreenNotification('<%=GetLocalMessage("NodeExists") %>', 'warning', 1500);
                                proceed = false;
                                return;
                            }
                        });
                    }
                }
                if (proceed) {
                    var item = {};
                    var updated = false;
                    item["id"] = data.node.id;
                    item["text"] = data.node.text.trim();
                    item["action"] = "RENAME";
                    if ($.isNumeric(data.node.id)) {
                        item["cid"] = data.node.id;
                    }
                    else {
                        item["cid"] = fnGetCIDFromLocalObject(data.node.id);
                    }
                    if ($.isNumeric(data.node.parent)) {
                        item["parent"] = data.node.parent;
                    }
                    else {
                        item["parent"] = fnGetCIDFromLocalObject(data.node.parent);
                    }
                    item["Active"] = fnGetStatus(item["cid"]);
                    if (Type == 'Store') {
                        item["type"] = "Store";
                    }
                    else if (Type == 'Floor') {
                        item["type"] = "Floor";
                    }
                    else {
                        item["type"] = "Location";
                    }
                    fnAddItemtoJSON(item);
                }
            }).bind("move_node.jstree", function (event, data) {
                var item = {};
                var updated = false;
                item["id"] = data.node.id;
                item["text"] = data.node.text;
                item["action"] = "DND";
                if ($.isNumeric(data.node.id)) {
                    item["cid"] = data.node.id;
                }
                else {
                    item["cid"] = fnGetCIDFromLocalObject(data.node.id);
                }
                if ($.isNumeric(data.node.parent)) {
                    item["parent"] = data.node.parent;
                }
                else {
                    item["parent"] = fnGetCIDFromLocalObject(data.node.parent);
                }
                item["Active"] = fnGetStatus(item["cid"]);

                if (Type == 'Store') {
                    item["type"] = "Store";
                }
                else if (Type == 'Floor') {
                    item["type"] = "Floor";
                }
                else {
                    item["type"] = "Location";
                }
                if (data.node.icon == '../Includes/plugins/jstree/dist/Images/Store-icon.png') {
                    item["type"] = "Store";
                }
                if (data.node.icon == '../Includes/plugins/jstree/dist/Images/Floor-icon.png') {
                    item["type"] = "Floor";
                }
                fnAddItemtoJSON(item);
            }).bind('ready.jstree', function (e, data) {
                $.each(LocationList, function (key, value) {
                    if (value.Active == false) {
                        var id = value.id;
                        var node = $('#locationTree').jstree(true).get_node(id);
                        if (typeof ($("#locationTree").jstree(true).get_node(id).li_attr) != 'undefined') {
                            $("#locationTree").jstree(true).get_node(id).li_attr.class = "inactive-node";
                        }
                        $("#locationTree").jstree(true).redraw_node(id, true);
                    }

                });

                if ($(".jstree-open").length == 0) {
                    $("#BodyContentPlaceHolder_lblExpandAll").html("<%=GetLocalMessage("ExpandAll")%>");
                    $("#toggleTree").removeClass("fa-compress").addClass("fa-expand");
                }
                else {

                    $("#BodyContentPlaceHolder_lblExpandAll").html("Collapse All");
                    $("#toggleTree").removeClass("fa-expand").addClass("fa-compress");
                }

                if (LocationList.length == 0 && $('#BodyContentPlaceHolder_UCInstanceList_lstInstance').val() != null) {
                    $("#locationTree").jstree('create_node', '#', { 'id': '', 'text': '<%=GetGlobalMessage("NewNode")%>' }, 'first');
                }
            });
        };

        function Validate() {
            var errors = 0;
            $('#locationTree').jstree("deselect_all");
            var json = $('#locationTree').jstree(true).get_json('#', { flat: true });
            $.each(json, function (key, value) {
                if (value.text.trim().toLowerCase().indexOf("new node") >= 0 || value.text.trim() == "") {
                    $("#locationTree").jstree('select_node', [value, value.text]);
                    var ref = $('#locationTree').jstree(true);
                    ref.edit(ref.get_selected()[0]);
                    $('html, body').animate({
                        scrollTop: $(".jstree-rename-input").offset().top - 150
                    }, 500);
                    $(".jstree-rename-input").css('border', '1px solid red');
                    $(".jstree-rename-input").val(value.text);
                    if (value.text.trim() == "") {
                        $(".jstree-rename-input").val("");
                    }
                    errors++;
                    return false;
                }
            });
            if (errors == 0) {
                $('#BodyContentPlaceHolder_hdnData').val(JSON.stringify(jsonObj));
                console.log($('#BodyContentPlaceHolder_hdnData').val());
                blockUI();
                return true;
            }
            else {
                return false;
            }
        };

        var LocationListIncludingInActive;
        function locationLoadedIncludingInactive() {
            LocationListIncludingInActive = ControllerScope.GetAllLocationTree;
        };

        function fnContextMenu($node) {
            var tree = $("#locationTree").jstree(true);
            var grmyRef = $.jstree.reference("#locationTree");
            var $el = $("#locationTree>ul>li:first-child");

            var items = {
                "CreateLocation": {
                    "separator_before": false,
                    "separator_after": false,
                    "label": "<%=GetLocalMessage("CreateParentLocation")%>",
                    "action": function (obj) {
                        Type = 'Location';
                        $('#locationTree').jstree("deselect_all");
                        $("#locationTree").jstree('create_node', '#', { 'id': '', 'text': '<%=GetGlobalMessage("NewNode")%>' }, 'first');
                        $('#locationTree').jstree('select_node', 'ul > li:first');
                        $('#locationTree').jstree('edit_node', 'ul > li:first');
                        var ref = $('#locationTree').jstree(true);
                        ref.edit(ref.get_selected()[0]);
                        $('html, body').animate({
                            scrollTop: $(".jstree-rename-input").offset().top - 150
                        }, 500);


                    }
                },
                "CreateChildLocation": {
                    "separator_before": false,
                    "separator_after": false,
                    "label": "<%=GetLocalMessage("CreateChildLocation")%>",
                    "action": function (obj) {
                        Type = 'Location';
                        $node.type = "default";
                        $node.class = "child";
                        $node.attr = "child";
                        $node = tree.create_node($node);
                        tree.edit($node);
                        $('html, body').animate({
                            scrollTop: $(".jstree-rename-input").offset().top - 150
                        }, 500);
                        $node.icon = "../Includes/plugins/jstree/dist/Images/Location-icon.png";
                        $("#locationTree").jstree(true).redraw_node($node.id, true);


                    }
                },
                "CreateStore": {
                    "separator_before": false,
                    "separator_after": false,
                    "label": "<%=GetLocalMessage("CreateStore")%>",
                    "action": function (obj) {
                        Type = 'Store';
                        $node.type = "default";
                        $node.class = "child";
                        $node.attr = "child";
                        $node = tree.create_node($node);
                        tree.edit($node);
                        $('html, body').animate({
                            scrollTop: $(".jstree-rename-input").offset().top - 150
                        }, 500);
                        $node.icon = "../Includes/plugins/jstree/dist/Images/Store-icon.png";
                        $("#locationTree").jstree(true).redraw_node($node.id, true);


                    }
                },
                "CreateFloor": {
                    "separator_before": false,
                    "separator_after": false,
                    "label": "<%=GetLocalMessage("CreateFloor")%>",
                    "action": function (obj) {
                        Type = 'Floor';
                        $node.type = "default";
                        $node.class = "child";
                        $node.attr = "child";
                        $node = tree.create_node($node);
                        tree.edit($node);
                        $("#locationTree").jstree(true).redraw_node($node.id, true);
                        $('html, body').animate({
                            scrollTop: $(".jstree-rename-input").offset().top - 150
                        }, 500);

                        if (typeof ($node.li_attr) != 'undefined') {
                            $node.li_attr.class = "child";
                            $("#locationTree").jstree(true).redraw_node($node.id, true);
                        }

                    }
                },
                "Rename": {
                    "separator_before": false,
                    "separator_after": false,
                    "label": "<%=GetLocalMessage("Rename")%>",
                    "action": function (obj) {
                        var nodeText = $node.text;
                        if ($node.icon == '../Includes/plugins/jstree/dist/Images/Store-icon.png') {
                            Type = "Store";
                        }
                        else if ($node.icon == '../Includes/plugins/jstree/dist/Images/Floor-icon.png') {
                            Type = "Floor";
                        }
                        else {
                            Type = "Location";
                        }
                        tree.edit($node);
                        $(".jstree-rename-input").val(nodeText);
                        $(".jstree-rename-input").css('width', '100%');
                    }
                },
                "InActive": {
                    "separator_before": false,
                    "separator_after": false,
                    "label": "<%=GetLocalMessage("Deactive")%>",
                    "action": function (obj) {

                        var item = {};
                        item["id"] = $node.id;
                        item["type"] = $node.type;
                        item["text"] = $node.text;
                        item["action"] = "INACTIVE";
                        if ($.isNumeric($node.id)) {
                            item["cid"] = $node.id;
                        }
                        else {
                            item["cid"] = fnGetCIDFromLocalObject($node.id);
                        }
                        if ($.isNumeric($node.parent)) {
                            item["parent"] = $node.parent;
                        }
                        else {
                            item["parent"] = fnGetCIDFromLocalObject($node.parent);
                        }
                        item["Active"] = "0";
                        fnAddItemtoJSON(item);

                        $node.li_attr.class = "inactive-node";
                        $("#locationTree").jstree(true).redraw_node($node.id, true);
                    }
                },
                "Active": {
                    "separator_before": false,
                    "separator_after": false,
                    "label": "<%=GetGlobalMessage("Active")%>",
                    "action": function (obj) {

                        var item = {};
                        item["id"] = $node.id;
                        item["text"] = $node.text;
                        item["type"] = $node.type;
                        item["action"] = "ACTIVE";
                        if ($.isNumeric($node.id)) {
                            item["cid"] = $node.id;
                        }
                        else {
                            item["cid"] = fnGetCIDFromLocalObject($node.id);
                        }
                        if ($.isNumeric($node.parent)) {
                            item["parent"] = $node.parent;
                        }
                        else {
                            item["parent"] = fnGetCIDFromLocalObject($node.parent);
                        }
                        item["Active"] = "1";
                        fnAddItemtoJSON(item);

                        $node.li_attr.class = "jstree-node";
                        $("#locationTree").jstree(true).redraw_node($node.id, true);
                    }
                },
                "configure": {
                    "separator_before": false,
                    "separator_after": false,
                    "label": "Configure",
                    "action": function (obj) {
                        var LocationID = $node.id;
                        var Location = $node.text;
                        var Instance = $('#<%=UCInstanceList.Instance.ClientID%>').val();
                        var Height;
                        var Type;
                        if ($node.icon == '../Includes/plugins/jstree/dist/Images/Store-icon.png') {
                            Height = '70%';
                            Type = 'Store';
                        }
                        else if ($node.icon == '../Includes/plugins/jstree/dist/Images/Floor-icon.png') {
                            Height = '80%';
                            Type = 'Floor';
                        }
                        else {
                            Height = '70%';
                            Type = 'Location';
                        }
                        var Enabled=$('#<%=hdnEnable.ClientID%>').val();
                        fnGetLocationDetails(LocationID, Location, Instance, Height, Type,Enabled);
                    }
                }
            };

            if (typeof ($node.li_attr) != 'undefined') {
                if ($node.li_attr.class == "inactive-node") {
                    delete items.InActive;
                    delete items.set_as_default;
                }
                else {
                    delete items.Active;
                }
                if ($node.icon == '../Includes/plugins/jstree/dist/Images/Store-icon.png') {
                    delete items.CreateLocation;
                    delete items.CreateChildLocation;
                    delete items.CreateStore;
                    delete items.CreateFloor;
                }
                if ($node.icon == '../Includes/plugins/jstree/dist/Images/Floor-icon.png') {
                    delete items.CreateLocation;
                    delete items.CreateChildLocation;
                    delete items.CreateStore;
                    delete items.CreateFloor;
                }
            }

            if ($.isNumeric($node.id) == false) {
                delete items.configure;
                delete items.InActive;
            }

            return items;
        };

        var newId;
        function fnGenerateNewId() {
            var lastId = parseInt($("#BodyContentPlaceHolder_hdnLastCategoryId").val(), 10) + 1;
            $("#BodyContentPlaceHolder_hdnLastCategoryId").val(lastId);
            newId = lastId;
        };

        function fnGetCIDFromLocalObject(id) {
            var Result = "#";
            $.each(jsonObj, function (i, val) {
                if (val.id == id) {
                    Result = val.cid;
                }
            });
            return Result;
        };

        function fnAddItemtoJSON(item) {
            var Updated = false;
            $.each(jsonObj, function (i, val) {
                if (val.cid == item.cid) {
                    val.text = item.text;
                    if (typeof (item.type) != 'undefined')
                        val.type = item.type;

                    val.parent = item.parent;
                    val.Active = item.Active;
                    val.path = fnGetPath(item.id);
                    val.createdby = UserID;
                    Updated = true;
                }
            });

            if (Updated == false) {
                item.path = fnGetPath(item.id);
                item.createdby = UserID;
                jsonObj.push(item);
            }
        };
        function fnGetStatus(cid) {
            var Result = "0";
            $.each(jsonObj, function (i, val) {
                if (val.cid == cid) {
                    Result = val.Active;
                }
            });
            $.each(LocationList, function (i, val) {
                if (val.id == cid) {
                    if (val.Active) {
                        Result = "1";
                    }
                }
            });

            return Result;
        };

        function ValidateCancel() {
            if (jsonObj.length > 0) {
                var record = bootbox.confirm('<%= GetLocalMessage("CnfrmMsg") %>', function (res) {
                if (res == true) {
                    window.location.href = "AM_Locations.aspx";
                    return true;
                } else {
                    $('.bootbox-confirm').modal('hide');
                    return false;
                }
            });
        }
        else {
            window.location.href = "AM_Locations.aspx";
        }
        return false;
    };

    function fnGetLocationDetails(LocationID, Location, Instance, Height, Type,Enabled) {
        var URL;
        URL = 'AM_Locations_Configure_PopUp.aspx?ID=' + LocationID + '&IN=' + Instance + '&Loc=' + Location+ '&Enabled='+ Enabled
        $.SPopUp({
            'width': '60%',
            'height': Height,
            'autoScale': false,
            'transitionIn': 'elastic',
            'transitionOut': 'elastic',
            'type': 'iframe', 'showCustomTitle': true, 'title': Type + ' Details', 'titlePosition': 'top', 'href': URL
        });
    };

    function fnToggleTree() {
        if ($("#toggleTree").hasClass("fa-expand")) {
            $("#locationTree").jstree('open_all');
            $("#BodyContentPlaceHolder_lblExpandAll").html('<%=GetLocalMessage("CollapseAll")%>');
            $("#toggleTree").removeClass("fa-expand").addClass("fa-compress");
            $("#toggleTree").attr('data-original-title','<%=GetLocalMessage("CollapseAllTooltip")%>');

        }
        else {
            $("#locationTree").jstree('close_all');
            $("#BodyContentPlaceHolder_lblExpandAll").html('<%=GetLocalMessage("ExpandAll")%>');
            $("#toggleTree").removeClass("fa-compress").addClass("fa-expand");
            $("#toggleTree").attr('data-original-title', '<%=GetLocalMessage("ExpandAllTooltip")%>');

        }
    };

    function fnGetPath(id) {
        var result = '|';
        var path = $("#locationTree").jstree(true).get_path(id, '|', true);
        if (typeof (path) != 'undefined') {
            var splitPathArray = path.split('|');
            $.each(splitPathArray, function (key, value) {
                //result += fnGetCIDFromLocalObject(value) + '|';
                if ($.isNumeric(value)) {
                    result += value + '|';
                }
                else {
                    var nodeObj = $.grep(jsonObj, function (element) {
                        if (element.id == value) {
                            return true;
                        } else {
                            return false;
                        }
                    });
                    if (nodeObj.length > 0) {
                        result += nodeObj[0].cid + '|';
                    }
                }

            });
        }
        return result;
    };

    $(document).ready(function () {
        Initialize();
       
        var oKbData = {};
        oKbData.OrgID = '<%=OrgID%>';
        oKbData.Instance = $('#<%=UCInstanceList.Instance.ClientID %>').val();
        oKbData.UserID = '<%=UserID%>';
        var KbData = { args: JSON.stringify(oKbData) };
        
        $.fn.SPopUp.defaults.onClosed = function () {
            blockUI();
            location.reload();
        };
    });
    </script>

</asp:Content>
