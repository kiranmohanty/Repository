﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Summit_BLL.Incident;
using Summit_BLL.Common;
using SummitWeb;
using Summit_BLL;
using Summit_BLL.Admin;
using Summit_H;
using System.Data;

using Newtonsoft.Json;

namespace SummitWeb.MDLAssetMgmt
{
    public partial class AM_Locations : BasePage
    {
        #region [Variables]
        string strModule = "AM";
        
        #endregion [Variables]
        #region//Properties
        string Instance
        {
            get
            {
                return UCInstanceList.Instance.SelectedValue;
            }
            set
            {
                UCInstanceList.Instance.ClearSelection();
                if (UCInstanceList.Instance.Items.FindByValue(value) != null)
                    UCInstanceList.Instance.SelectedValue = value;
            }
        }
        int CategoryID { get; set; }
        string AdminInstance;
        #endregion


        protected void Page_Load(object sender, EventArgs e)
        {
            AdminInstance = AppSettings.CurrentAdminInstance;
            BindEvents();
            if (!IsPostBack)
            {
                hdnEnable.Value = IsPageEditable.ToString();
                ManageButtons(hdnEnable.Value.ToBool());
                Initialize();
                if (AdminInstance.IsNotNullAndEmpty())
                {
                    //EnableForm();
                    UCInstanceList.Instance.SelectedValue = AdminInstance;
                    if (Session["sMsg"].IsNotNullAndEmpty())
                    {
                        ShowMessage(Session["sMsg"], MessageType.Success, MessageContainer.ModalPopup);
                        Session.Remove("sMsg");
                    }
                }
                GetLastId();
            }
        }


        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (hdnData.Value == string.Empty)
                {
                    return;
                }
                Summit_BLL.AM_Locations objLocation = new Summit_BLL.AM_Locations();
                var doc = JsonConvert.DeserializeXmlNode("{\"subroot\":" + hdnData.Value + "}", "root");
                String xml = doc.InnerXml.ToString();
                String Result = objLocation.SaveLocationTree(Instance, hdnInitialCatId.Value.ToInt(), xml);
                if (Result == String.Empty)
                {
                    Session["sMsg"] = GetGlobalMessage("SucessfulMsg");
                    Response.Redirect("~/MDLAssetMgmt/AM_Locations.aspx", false);
                }
                else if (Result == "LocationConcurrencyMsg")
                {
                    GetLastId();
                    ShowMessage(GetLocalMessage("LocationConcurrencyMsg"), MessageType.Warning, MessageContainer.OnScreen);
                }
                else
                {
                    GetLastId();
                    ShowMessage(GetLocalMessage("InactiveDenied") + "<br><br><b>" + Result + "</b>", MessageType.Information, MessageContainer.OnScreen);
                }
            }
            catch(Exception ex)
            {

            }
        }

        /// <summary>
        /// Instance selected index changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lstInstance_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                AppSettings.CurrentAdminInstance = UCInstanceList.Instance.SelectedValue;
                SaveAppSettings();
                AdminInstance = AppSettings.CurrentAdminInstance;
                GetLastId();
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_Locations.lstInstance_SelectedIndexChanged", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }

        /// <summary>
        /// Here binding the event to user control
        /// </summary>
        void BindEvents()
        {
            UCInstanceList.Instance.SelectedIndexChanged += lstInstance_SelectedIndexChanged;
            UCInstanceList.Instance.AutoPostBack = true;
        }
        /// <summary>
        /// Load instance list
        /// </summary>
        void LoadInstance()
        {
            try
            {
                lblInstanceName.Text = AppSettings.InstanceDisplayName;
                UCInstanceList.ListRole = Summit_BLL.Common.InstanceListRole.Administrator;
                UCInstanceList.ModuleCode = SSModules.AM;
                UCInstanceList.BindData();
                if (!Instance.IsNotNullAndEmpty())
                    ShowMessage(string.Format("{0} {1}.", GetGlobalMessage("SelectInstance"), AppSettings.InstanceDisplayName), MessageType.Information, MessageContainer.OnScreen);
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "IM_EditCriticality.LoadInstance", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }

        /// <summary>
        /// Initialize methods to load master data
        /// </summary>
        void Initialize()
        {
            LoadInstance();
        }

        private void GetLastId()
        {
            try
            {
                Summit_BLL.AM_Locations objLocM = new Summit_BLL.AM_Locations();
                hdnLastCategoryId.Value = objLocM.GetLastLocationId(String.Empty, strModule);
                hdnInitialCatId.Value = hdnLastCategoryId.Value;
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_Locations.GetLastId()", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }

        private void ManageButtons(bool Access)
        {
            if(Access.Equals(true))
            {
                btnSave.Visible = true;
            }
            else
            {
                btnSave.Visible = false;
            }
        }
    }
}