﻿<%@ Page Title="" Language="C#" MasterPageFile="~/PopupLayout.Master" AutoEventWireup="true" CodeBehind="AM_Locations_Configure_PopUp.aspx.cs" Inherits="SummitWeb.MDLAssetMgmt.AM_Locations_Configure_PopUp" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
         .div-bottom-padding > div > div{
            padding-bottom: 10px;
            float:left;
            width:100%;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPanel" runat="server">
    <div id="divLocationDetails">
        <div class="row">
            <div class="col-xs-12 disp-table gv-container">
                <div class="col-xs-11 disp-tbl-cell margin-left-10px">
                    <div>
                        <div class="panel-body div-bottom-padding">
                            <div class="row">
                                <div class="form-group " runat="server" visible="false">
                                    <div class=" col-xs-2 col-md-2 pad-left-zero">
                                        <asp:label id="lblID" runat="server" text="<%$ Resources:GlobalResources, ID %>"></asp:label>
                                    </div>
                                    <div class="col-md-2 col-xs-2 pad-left-zero pad-right-zero">
                                        <asp:textbox id="txtID" readonly="true" cssclass="form-control" runat="server"></asp:textbox>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="form-group" runat="server">
                                    <div class="col-md-3 col-xs-3 pad-left-zero">
                                        <asp:label id="lblValue" runat="server" cssclass="mandatoryField control-label" text="Value" meta:resourcekey="lblValueResource"></asp:label>
                                    </div>
                                    <div class="col-md-4 col-xs-4 pad-left-zero">
                                        <asp:textbox id="txtValue" maxlength="50" cssclass="form-control" runat="server" onblur="javascript:setshortLocationCode(this)"></asp:textbox>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="form-group" runat="server">
                                    <div class="col-md-3 col-xs-3 pad-left-zero pad-right-zero">
                                        <asp:label id="lblLocationShortCode" runat="server" cssclass="control-label mandatoryField" meta:resourcekey="lblLocationShortCodeResource"></asp:label>
                                    </div>
                                    <div class="col-md-4 col-xs-4 pad-left-zero">
                                        <asp:textbox id="txtLocationShortCode" maxlength="50" cssclass="form-control" runat="server" onblur="javascript:return onsetshortLocationCode(this);"></asp:textbox>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="form-group" runat="server">
                                    <div class="col-md-3 col-xs-3 pad-left-zero pad-right-zero">
                                        <asp:label id="lblType" runat="server" text="Type" cssclass="control-label mandatoryField" meta:resourcekey="lblTypeResource"></asp:label>
                                    </div>
                                    <div class="col-md-4 col-xs-4 pad-left-zero">
                                        <asp:dropdownlist id="lstType" cssclass="select2" runat="server">
                                            <asp:ListItem Text="<%$ Resources: GlobalResources, DDLSelect %>" Value=""></asp:ListItem>
                                            <asp:ListItem Text="<%$ Resources: GlobalResources, AM_Floor %>" Value="Floor"></asp:ListItem>
                                            <asp:ListItem Text="<%$ Resources: GlobalResources, Location %>" Value="Location"></asp:ListItem>
                                            <asp:ListItem Text="<%$ Resources: GlobalResources, AM_Store %>" Value="Store"></asp:ListItem>
                                        </asp:dropdownlist>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group " runat="server" visible="false" id="divRFID">
                                    <div class="col-md-3 col-xs-3 pad-left-zero pad-right-zero">
                                        <asp:label id="lblRFID" runat="server" text="RF ID" cssclass="control-label" meta:resourcekey="lblRFIDResource"></asp:label>
                                    </div>
                                    <div class="col-md-4 col-xs-4 pad-left-zero">
                                        <asp:textbox id="txtRF_ID" maxlength="5" cssclass="form-control" runat="server"></asp:textbox>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="form-group " runat="server" visible="false" id="divFloorMgrEmailID">
                                    <div class="col-md-3 col-xs-3 pad-left-zero pad-right-zero">
                                        <asp:label id="lblFlrMngrEmailID" runat="server" text="Floor Manager Email ID" cssclass="control-label" meta:resourcekey="lblFlrMngrEmailIDResource"></asp:label>
                                    </div>
                                    <div class="col-md-4 col-xs-4 pad-left-zero">
                                        <asp:textbox id="txtFloorMgrEmailId" cssclass="form-control" runat="server" textmode="MultiLine" rows="3"></asp:textbox>
                                    </div>
                                      <div id="DivFlrMgrNote" runat="server" class="">
                                    <div class="col-md-10 col-sm-12 col-xs-12" style="padding-left:169px">
                                        <asp:label id="lblFlrMgrNote" runat="server" cssclass="lbl-note" meta:resourcekey="lblEmailResource"></asp:label>
                                    </div>
                                </div>
                                </div>
                            </div>
                            
                           <%-- <div class="row">
                              
                            </div>--%>
                            
                            <div class="row">
                                <div class="form-group " id="divSubnet" runat="server">
                                <div class="row">
                                    <div class="col-xs-3 col-md-3">
                                        <asp:label id="lblSubnet" runat="server" cssclass="control-label pad-left-zero" text="Floor Subnet" meta:resourcekey="lblSubnetResource"></asp:label>
                                    </div>
                                    <div class="col-xs-8 col-md-8">
                                        <div class="col-xs-8 col-md-8 pad-left-zero">
                                             <div class="row">
                                                    <div class="col-xs-4 col-md-4">
                                                        <asp:label id="lblFrom" runat="server" cssclass="control-label pad-left-zero" text="<%$ Resources:IPFromResource.HeaderText %>"></asp:label>
                                                    </div>
                                                    <div class="col-md-8 col-xs-8 pad-right-zero" id="divIPFrom">
                                                        <asp:textbox id="txtSN11" runat="server" cssclass="form-control SubNetTxt" maxlength="3"></asp:textbox>
                                                        <asp:textbox id="txtSN12" runat="server" cssclass="form-control SubNetTxt" maxlength="3"></asp:textbox>
                                                        <asp:textbox id="txtSN13" runat="server" cssclass="form-control SubNetTxt" maxlength="3"></asp:textbox>
                                                        <asp:textbox id="txtSN14" runat="server" cssclass="form-control SubNetTxt" maxlength="3"></asp:textbox>
                                                    </div>
                                                </div>
                                           <div class="row">
                                                <div class="col-xs-4 col-md-4">
                                                    <asp:label id="lblTo" runat="server" cssclass="control-label pad-left-zero padding-top-5px" text="<%$ Resources:IPToResource.HeaderText %>"></asp:label>
                                                </div>
                                                <div class="col-md-8 col-xs-8 pad-right-zero padding-top-5px">
                                                    <asp:textbox id="txtSN21" runat="server" cssclass="form-control SubNetTxt" maxlength="3"></asp:textbox>
                                                    <asp:textbox id="txtSN22" runat="server" cssclass="form-control SubNetTxt" maxlength="3"></asp:textbox>
                                                    <asp:textbox id="txtSN23" runat="server" cssclass="form-control SubNetTxt" maxlength="3"></asp:textbox>
                                                    <asp:textbox id="txtSN24" runat="server" cssclass="form-control SubNetTxt" maxlength="3"></asp:textbox>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xs-4 col-md-4">
                                            <div class="row">&nbsp;</div>
                                            <div class="row padding-left-10px">
                                                 <asp:button id="btnAdd" runat="server" text="ADD" cssclass="btn btn-primary pull-left" OnClientClick="javascript: return ValidateIP()" onclick="btnAdd_Click" meta:resourcekey="btnAdd" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            
                            <div class="row">
                                 <div class="form-group " id="divMailTo" runat="server">
                                     <div class="col-md-3 col-xs-3 pad-left-zero pad-right-zero">
                                         <asp:label id="lblMailTo" runat="server" cssclass="control-label pad-left-zero" text="Mail To" meta:resourcekey="lblMailToResource"></asp:label>
                                     </div>
                                    <div class="col-sm-4 col-md-4 col-xs-4 pad-left-zero">
                                        <asp:textbox id="txtMailTo" runat="server" cssclass="form-control" data-rule-required="true" rows="2" textmode="MultiLine"></asp:textbox>
                                    </div>
                                      <div id="divEmailNote" runat="server" visible="false">
                                      <div class="col-md-10 col-sm-12 col-xs-12" style="padding-left:175px">
                                        <asp:label id="lblEmailNote" runat="server" cssclass="lbl-note" text="Note: If asset request for return mail will be send to notify email." meta:resourcekey="lblEmailNoteResource"></asp:label>
                                    </div></div>
                                </div>
                            </div>
                           
                                           
                           

                           <div class="row">
                               <div class="form-group " id="divGrd" runat="server" visible="false">
                                <div class="col-md-3 col-lg-3 col-xs-3">&nbsp;</div>
                                <div class="col-md-6 col-xs-6 padding-zero">
                                   
                                        <asp:gridview id="gvIPRange" runat="server" backcolor="White" bordercolor="DarkGray"
                                            borderstyle="Solid" borderwidth="1px" cellpadding="3" width="100%" autogeneratecolumns="False"
                                            cssclass="mstGV" emptydatatext="<%$ Resources: GlobalResources, NoData %>" font-bold="False" datakeynames="uID"
                                            onrowdeleting="gvIPRange_RowDeleting">
                                            <FooterStyle CssClass="MstFooter" />
                                            <RowStyle CssClass="DashRow" HorizontalAlign="Center" />
                                            <EmptyDataRowStyle Font-Bold="True" ForeColor="Black" HorizontalAlign="Center" VerticalAlign="Middle"
                                                CssClass="msgError" />
                                            <HeaderStyle Font-Bold="True" CssClass="DashHeader" Wrap="False" ForeColor="#545454" />
                                            <AlternatingRowStyle CssClass="DashAltRow" />
                                            <Columns>
                                                <asp:BoundField DataField="IPFrom" HeaderText="IP Range From" HeaderStyle-Width="40%" meta:resourcekey="IPFromResource">
                                                    <ItemStyle HorizontalAlign="Left" />
                                                </asp:BoundField>
                                                <asp:BoundField HeaderText="IP Range To" DataField="IPTo" HeaderStyle-Width="40%" meta:resourcekey="IPToResource">
                                                    <ItemStyle HorizontalAlign="Left" />
                                                </asp:BoundField>
                                                <asp:TemplateField HeaderText="<%$ Resources:GlobalResources, Delete %>">
                                                    <ItemTemplate>                                                        
                                                        <asp:ImageButton ID="lnkDelete" runat="server" CommandName="Delete" CausesValidation="false" ForeColor="Transparent" ImageUrl="~/Images/delete.png"
                                                            CommandArgument='<%# Eval("UID") %>' OnClientClick="<%$Resources:DeleteConfirmation %>" />
                                                    </ItemTemplate>
                                                    <HeaderStyle HorizontalAlign="Left" Width="10%"></HeaderStyle>
                                                    <ItemStyle HorizontalAlign="Center" VerticalAlign="Middle"/>
                                                </asp:TemplateField>
                                                </Columns>
                                            </asp:gridview>
                                       
                                    </div>
                                </div>
                           </div> 
                            
                        </div>
                    </div>
                    <div class="col-xs-12 pad-right-zero">
                        <div class="col-xs-12 col-md-12 col-sm-12 pad-right-zero">
                            <div class="col-sm-12 col-md-12 btns-container pad-right-zero align-right">
                                <asp:button id="btnSave" runat="server" text="<%$ Resources:GlobalResources, btnSave %>" cssclass="btn btn-primary" onclick="btnSave_Click" />
                                <asp:button id="btnCancel" runat="server" text="<%$ Resources:GlobalResources, btnCancel %>" cssclass="btn btn-primary cancel" onclick="btnCancel_Click" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <asp:hiddenfield id="hidLocationID" runat="server" />
    <script type="text/javascript">
        var Initialize = function () {

            form = $("#form1");
            $.validator.addMethod("ValidEMailTo", function (value, element) {
                var Result = true;
                if (value == null || value == '')
                    Result = true;
                else {
                    if (JValidateRegexForLocalization(this, value, element, "multiemailvalidationsemicolon")) { return true; } else { return false; }
                } return Result;
            }, "<%= GetGlobalMessage("SpecifyValidEMail")%>");
            $('#<%=btnSave.ClientID %>').click(function () {
                form.validate({
                    rules: {
                        '<%= txtValue.UniqueID %>': {
                            required: true
                        },
                        '<%= txtLocationShortCode.UniqueID %>': {
                            required: true
                        },
                        '<%= lstType.UniqueID %>': {
                            required: true
                        },
                        '<%= txtMailTo.UniqueID %>': {
                            maxlength: 500, ValidEMailTo: true, required: false
                        },
                        '<%= txtFloorMgrEmailId.UniqueID %>': {
                            maxlength: 500, ValidEMailTo: true, required: false
                        },
                    },
                    messages: {
                        '<%= txtValue.UniqueID %>': {
                            required: '<%= string.Format(GetGlobalMessage("SpecifytheValue"),GetLocalMessage("lblValueResource.Text"))%>',
                        },
                        '<%= txtLocationShortCode.UniqueID %>': {
                            required: '<%= string.Format(GetGlobalMessage("SpecifytheValue"),GetLocalMessage("lblLocationShortCodeResource.Text"))%>',
                        },
                        '<%= lstType.UniqueID %>': {
                            required: '<%= string.Format(GetGlobalMessage("SelectThe"),GetLocalMessage("lblTypeResource.Text"))%>',
                        },
                        '<%= txtMailTo.UniqueID %>': {
                            required: '<%=GetLocalMessage("ValidEMailTo")%>', maxlength: '<%= string.Format(GetGlobalMessage("msgMaxCharacters"), GetLocalMessage("lblMailToResource.Text"),"500") %>', ValidEMailTo: '<%=GetLocalMessage("EmailErrorNotify")%>',
                        },
                        '<%= txtFloorMgrEmailId.UniqueID %>': {
                            maxlength: '<%= string.Format(GetGlobalMessage("msgMaxCharacters"), GetLocalMessage("lblMailToResource.Text"),"500") %>', ValidEMailTo: '<%=GetLocalMessage("EmailErrorNotify")%>',
                        }
                    }
                });
            });
        }

        //Allow only numeric
        function KeyCheck(myfield, e, nextField) {
            var keycode;
            if (window.event) keycode = window.event.keyCode;
            else if (e) keycode = e.which;
            else return true;

            if (keycode == 46) {
                if (document.getElementById(nextField))
                    document.getElementById(nextField).focus();
                return false;
            }
            else if (((keycode > 47) && (keycode < 58)) || (keycode == 8)) { return true; }
            else return false;
        }


        function ValidateFromIP()
        {
            var SN11Flag = false;
            var SN12Flag = false;
            var SN13Flag = false;
            var SN14Flag = false;
            var SN11 = document.getElementById("<%=txtSN11.ClientID%>").value;
            var SN12 = document.getElementById("<%=txtSN12.ClientID%>").value;
            var SN13 = document.getElementById("<%=txtSN13.ClientID%>").value;
            var SN14 = document.getElementById("<%=txtSN14.ClientID%>").value;
            if (SN11 != 'undefined' && SN11 != '')
            {
                SN11Flag = true;
            }
            if (SN12 != 'undefined' && SN12 != '')
            {
                 SN12Flag = true;
            }
            if (SN13 != 'undefined' && SN13 != '')
            {
                SN13Flag = true;
            }
            if (SN14 != 'undefined' && SN14 != '') {
                SN13Flag = true;
            }
            if(SN11Flag && SN12Flag && SN13Flag && SN12Flag)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        function ValidateToIP()
        {
            var SN21Flag = false;
            var SN22Flag = false;
            var SN23Flag = false;
            var SN24Flag = false;
            var SN21 = document.getElementById("<%=txtSN21.ClientID%>").value;
            var SN22 = document.getElementById("<%=txtSN22.ClientID%>").value;
            var SN23 = document.getElementById("<%=txtSN23.ClientID%>").value;
            var SN24 = document.getElementById("<%=txtSN24.ClientID%>").value;
            if (SN21 != 'undefined' && SN21 != '')
            {
                SN21Flag = true;
            }
            if (SN22 != 'undefined' && SN22 != '')
            {
                 SN22Flag = true;
            }
            if (SN23 != 'undefined' && SN23 != '')
            {
                SN23Flag = true;
            }
            if (SN24 != 'undefined' && SN24 != '') {
                SN24Flag = true;
            }
            if(SN21Flag && SN22Flag && SN23Flag && SN24Flag)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        function ValidateIP() {
            var flag = false;
            if (!ValidateFromIP()) {
                InitOnScreenNotification('<%=GetLocalMessage("ValidIPAddress")%>', 'error', 1500);
                return false;
            }
            else {
                flag = true;
            }

            if (!ValidateToIP()) {
                InitOnScreenNotification('<%=GetLocalMessage("ValidIPAddress")%>', 'error', 1500);
                return false;
            }
            else {
                flag = true;
            }

            return flag;
        }

        //Copy Txt
        function CopyVal(myfield, toField) {
            if (isNaN(myfield.value)) {
                myfield.value = "";
            }

            var CopyTo = document.getElementById(toField);
            if ((parseInt(myfield.value) >= 0 && parseInt(myfield.value) <= 255))
                CopyTo.value = myfield.value;
            else {
                CopyTo.value = "";
                myfield.value = "";
            }
        }

        function setshortLocationCode(val) {
            var Value = document.getElementById(val.id).value;
            var shortcode = document.getElementById("<%=txtLocationShortCode.ClientID%>")
            if (Value != "" && shortcode.value.length == 0) {
                if (Value.length > 4)
                    shortcode.value = Value.substring(4, 0);
                else
                    shortcode.value = Value;

                return;
            }
        }

        $(document).ready(function () {
            $('.icon').tooltip({ container: 'body' });
            Initialize();
            InitializeSelect2();
        });
    </script>
</asp:Content>
