﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Summit_H;
using Summit_BLL;
using Summit_DAL;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SummitWeb.MDLAssetMgmt
{
    public partial class AM_Locations_Configure_PopUp : PopupBasePage
    {
        #region [Variables]
        string Instance;
        string LocationID;
        string Location;

        #endregion [Variables]

        #region [Properties]
        #endregion [Properties]

        #region [Form Method]
        /// <summary>
        /// On Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    //if (Session["sMsg"].IsNotNullAndEmpty()) { ShowMessage(Session["sMsg"].ToString(), MessageType.Success, MessageContainer.OnScreen); Session.Remove("sMsg"); }
                    if (Request.QueryString["ID"].ToStringFromObject() != null)
                    {
                        Instance = Request.QueryString["IN"].ToStringFromObject();
                        Location = Request.QueryString["Loc"].ToStringFromObject();
                        LocationID = Request.QueryString["ID"].ToStringFromObject();
                        if (Request.QueryString["Enabled"] != null && Request.QueryString["Enabled"] != string.Empty)
                        {
                            bool Enable = Convert.ToBoolean(Request.QueryString["Enabled"]);
                            if (Enable == false)
                            {
                                btnSave.Visible = false;                                
                            }
                            else
                            {                                
                                btnSave.Visible = true;
                            }
                        }
                    }
                    BuildIPEvents();
                    if (OrgID.ToString() != null)
                    {
                        DisableForm();
                        if (Instance != null)
                        {
                            EnableForm();
                        }
                    }
                    if (Request.QueryString["ID"].ToStringFromObject() != null)
                    {
                        GetLocation(LocationID.ToInt());
                    }
                }
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_Locations_Configure_PopUp.Page_Load", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }

        /// <summary>
        /// On Add Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AM_LocationsM _loc = new AM_LocationsM();
                string SubnetFrom = txtSN11.Text + "." + txtSN12.Text + "." + txtSN13.Text + "." + txtSN14.Text;
                string SubnetTo = txtSN21.Text + "." + txtSN22.Text + "." + txtSN23.Text + "." + txtSN24.Text;
                if (_loc.SaveFloorIPRange(CONST.DBRetType.DATAVIEW, SubnetFrom, SubnetTo, txtID.Text.ToInt()))
                {
                    gvIPRange.DataSource = _loc.DVData;
                    gvIPRange.DataBind();
                    ResetSubnet();
                    ShowMessage(GetLocalMessage("SubSaveSuccess"), MessageType.Success, MessageContainer.ModalPopup);
                }
                else
                {
                    ShowMessage(GetLocalMessage("ErrSave"), MessageType.Success, MessageContainer.ModalPopup);
                }
            }
            catch (Exception ex)
            {
                btnSave.Enabled = false;
                Helper.LogMessage("WEB", "AM_Locations_Configure_PopUp.btnAdd_Click", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }

        /// <summary>
        /// On Submit Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            bool redirect = false;
            try
            {
                Summit_BLL.AM_Locations _Locations = new Summit_BLL.AM_Locations();
                AM_LocationsM _LocationsM = new AM_LocationsM();

                int UID = 0;
                if (txtID.Text != "") UID = int.Parse(txtID.Text.Trim());
                string ParentValue = hidLocationID.Value;
                int ParentVal = 0;

                if (txtID.Text != "" && ParentValue != "Root0" && ParentValue != "")
                {
                    if (_LocationsM.CheckParentNode(int.Parse(txtID.Text), int.Parse(hidLocationID.Value)))
                        throw new Exception("Cannot select child nodes as parent!");
                }
                if (ParentValue != "Root0")
                {
                    if (hidLocationID.Value.Length > 0)
                        ParentVal = int.Parse(hidLocationID.Value);
                }
                if ((UID == ParentVal && ParentValue != "Root0") && (UID == ParentVal && hidLocationID.Value != ""))
                    throw new Exception("Cannot select Location as its own parent!");


                if (lstType.SelectedItem != null) _Locations.Type = lstType.SelectedItem.ToString();
                EnableRFID();
                if (Helper.fnIsNumeric(txtID.Text)) _Locations.UID = int.Parse(txtID.Text.Trim());
                if (Instance != null) _Locations.Instance = Instance;
                if (txtValue.Text != "") _Locations.Value = txtValue.Text.Trim();
                if (txtRF_ID.Text != "") _Locations.RFID = txtRF_ID.Text.Trim();
                if (txtFloorMgrEmailId.Text != string.Empty) _Locations.FloorMgrEmailIDs = txtFloorMgrEmailId.Text;

                if (ParentValue != "Root0" && ParentValue != "")
                    _Locations.Parent_ID = ParentVal;

                //if (chkActive.Checked == true) { _Locations.Active = true; } else { _Locations.Active = false; }
                _Locations.Active = true;
                if (OrgID != null) _Locations.Org_Id = OrgID;
                if (txtLocationShortCode.Text != "") _Locations.LocationShortCode = txtLocationShortCode.Text.Trim();
                if (txtMailTo.Text != "" && txtMailTo.Text.Trim().Length > 0)
                    _Locations.MailTo = txtMailTo.Text.Trim().ToString();
                if (UserID.IsNotNullEmptyAndGreaterThanZero())
                {
                    _Locations.UpdatedBy = UserID;
                }
                string ErrMsg = string.Empty;
                if (_LocationsM.SaveLocationDetails(_Locations, CONST.DBRetType.SCALAR, out ErrMsg))
                {
                    if (string.IsNullOrEmpty(ErrMsg) == true)
                    {
                        ShowMessage(GetGlobalMessage("SucessfulMsg").ToString(), MessageType.Success, MessageContainer.ModalPopup);
                        redirect = false;
                    }
                    else if (string.IsNullOrEmpty(ErrMsg) == false)
                    {
                        ShowMessage(ErrMsg, MessageType.Information, MessageContainer.OnScreen);
                    }
                }
                else
                {
                    ShowMessage(GetLocalMessage("ErrSaveLocation"), MessageType.Error, MessageContainer.OnScreen);
                }
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_Locations_Configure_PopUp.btnSave_Click", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
            if (redirect)
            {
                Response.Redirect("~/MDLAssetMgmt/AM_Locations_Configure_PopUp.aspx");
            }
        }

        /// <summary>
        /// On Cancel Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                if (Request.QueryString["ID"] != null)
                {
                    GetLocation(Request.QueryString["ID"].ToInt());
                }
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_Locations_Configure_PopUp.btnCancel_Click", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }
        #endregion [Form Method]

        #region [Custom Method]
        /// <summary>
        /// Reset Form
        /// </summary>
        public void ResetForm()
        {
            txtID.Text = "";
            txtValue.Text = "";
            txtLocationShortCode.Text = "";
            lstType.SelectedIndex = -1;
            //hidLocationID.Value = "";            
            lstType.Enabled = true;
            txtFloorMgrEmailId.Text = string.Empty;
            txtRF_ID.Text = string.Empty;
            ResetSubnet();
            EnableRFID();
            txtMailTo.Text = string.Empty;
        }

        /// <summary>
        /// Disabling Form Elements
        /// </summary>
        private void DisableForm()
        {
            txtID.Enabled = false;
            txtValue.Enabled = false;
            lstType.Enabled = false;
            btnSave.Enabled = false;
            txtRF_ID.Text = string.Empty;
            txtSN11.Text = string.Empty;
            txtSN12.Text = string.Empty;
            txtSN13.Text = string.Empty;
            txtSN14.Text = "0";
            txtSN21.Text = string.Empty;
            txtSN22.Text = string.Empty;
            txtSN23.Text = string.Empty;
            txtSN24.Text = "255";
            txtFloorMgrEmailId.Text = string.Empty;
            txtLocationShortCode.Text = string.Empty;
        }

        /// <summary>
        /// Enabling Form Elements
        /// </summary>
        private void EnableForm()
        {
            txtID.Enabled = true;
            txtValue.Enabled = true;
            lstType.Enabled = true;
            btnSave.Enabled = true;
        }

        /// <summary>
        /// Enabling of RFID 
        /// </summary>
        private void EnableRFID()
        {
            try
            {
                if (lstType.SelectedValue.Equals("Floor", StringComparison.OrdinalIgnoreCase))
                {
                    divRFID.Visible = true;
                    divSubnet.Visible = true;
                    divGrd.Visible = true;
                    divFloorMgrEmailID.Visible = true;
                    divMailTo.Visible = false;
                    divEmailNote.Visible = false;
                    DivFlrMgrNote.Visible = true;
                }
                else
                {
                    divRFID.Visible = false;
                    divSubnet.Visible = false;
                    divGrd.Visible = false;
                    divFloorMgrEmailID.Visible = false;
                    divMailTo.Visible = true;
                    divEmailNote.Visible = true;
                    DivFlrMgrNote.Visible = false;
                }
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_Locations_Configure_PopUp.EnableRFID", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }

        /// <summary>
        /// Reset Subnet
        /// </summary>
        private void ResetSubnet()
        {
            txtSN11.Text = string.Empty;
            txtSN12.Text = string.Empty;
            txtSN13.Text = string.Empty;
            txtSN14.Text = "0";
            txtSN21.Text = string.Empty;
            txtSN22.Text = string.Empty;
            txtSN23.Text = string.Empty;
            txtSN24.Text = "255";
        }

        /// <summary>
        /// Build IP Events
        /// </summary>
        private void BuildIPEvents()
        {
            txtSN11.Attributes.Add("onKeyPress", "return KeyCheck(this,event,'" + txtSN12.ClientID + "');");
            txtSN11.Attributes.Add("onBlur", "CopyVal(this, '" + txtSN21.ClientID + "');");
            txtSN12.Attributes.Add("onKeyPress", "return KeyCheck(this,event,'" + txtSN13.ClientID + "');");
            txtSN12.Attributes.Add("onBlur", "CopyVal(this, '" + txtSN22.ClientID + "');");
            txtSN13.Attributes.Add("onKeyPress", "return KeyCheck(this,event,'" + txtSN14.ClientID + "');");
            txtSN13.Attributes.Add("onBlur", "CopyVal(this, '" + txtSN23.ClientID + "');");
            txtSN14.Attributes.Add("onKeyPress", "return KeyCheck(this,event,'');");

            txtSN21.Attributes.Add("readonly", "true");
            txtSN22.Attributes.Add("readonly", "true");
            txtSN23.Attributes.Add("readonly", "true");
            txtSN23.Attributes.Add("onKeyPress", "return KeyCheck(this,event,'');");
            txtSN24.Attributes.Add("onKeyPress", "return KeyCheck(this,event,'');");
        }

        /// <summary>
        /// Get Floor Details 
        /// </summary>
        private void GetFloorDetails()
        {
            AM_LocationsM _loc = new AM_LocationsM();
            if (_loc.GetFloor_IPRangeDetails(CONST.DBRetType.DATAVIEW, txtID.Text.ToInt()))
            {
                gvIPRange.DataSource = _loc.DVData;
                gvIPRange.DataBind();
            }
            else
            {
                gvIPRange.DataSource = null;
                gvIPRange.DataBind();
            }
        }

        /// <summary>
        /// Load Location Details
        /// </summary>
        /// <param name="UID"></param>
        private void GetLocation(int UID)
        {
            try
            {
                string stLocationType = string.Empty;
                ResetForm();
                lstType.Enabled = false;
                Summit_BLL.AM_Locations _Locations1 = new Summit_BLL.AM_Locations();
                Summit_BLL.AM_Locations _Locations = new Summit_BLL.AM_Locations();
                AM_LocationsM _LocationsM = new AM_LocationsM();

                _Locations1.Org_Id = OrgID;
                _Locations1.UID = UID;

                _LocationsM.GetTreeNodes(CONST.DBRetType.OBJECT, _Locations1, "", "", true, false, false);
                _Locations = _LocationsM.oLocations;

                txtID.Text = UID.ToString();
                if (_Locations.Value != null) txtValue.Text = _Locations.Value.ToString();
                if (_Locations.RFID != "") txtRF_ID.Text = _Locations.RFID;
                if (_Locations.FloorMgrEmailIDs.IsNotNullAndEmpty()) txtFloorMgrEmailId.Text = _Locations.FloorMgrEmailIDs;
                if (_LocationsM.GetFullLocation(CONST.DBRetType.DATAVIEW, _Locations.Parent_ID) == "")
                {
                    hidLocationID.Value = "Root0";
                }
                else
                {
                    hidLocationID.Value = _Locations.Parent_ID.ToString();
                }
                if (_Locations.LocationShortCode != null) txtLocationShortCode.Text = _Locations.LocationShortCode.ToString();
                if (_Locations.Type != null)
                {
                    lstType.SelectedValue = _Locations.Type.ToString();
                    EnableRFID();
                    stLocationType = _Locations.Type.ToString();
                }
                if (_Locations.MailTo != null) txtMailTo.Text = _Locations.MailTo.ToString();
                GetFloorDetails();
            }
            catch (Exception ex)
            {
                btnSave.Enabled = false;
                Helper.LogMessage("WEB", "AM_Locations_Configure_PopUp.GetLocation()", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }
        #endregion [Custom Method]

        #region [Grid Method]
        protected void gvIPRange_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                AM_LocationsM _loc = new AM_LocationsM();
                string SubnetFrom = txtSN11.Text + "." + txtSN12.Text + "." + txtSN13.Text + "." + txtSN14.Text;
                string SubnetTo = txtSN21.Text + "." + txtSN22.Text + "." + txtSN23.Text + "." + txtSN24.Text;
                if (_loc.DeleteFloorIPRange(CONST.DBRetType.DATAVIEW, gvIPRange.DataKeys[e.RowIndex].Value.ToInt(), txtID.Text.ToInt()))
                {
                    gvIPRange.DataSource = _loc.DVData;
                    gvIPRange.DataBind();
                    ShowMessage(GetLocalMessage("DelSuccess"), MessageType.Success, MessageContainer.ModalPopup);
                }
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_Locations_Configure_PopUp.gvIPRange_RowDeleting", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }
        #endregion [Grid Method]
    }
}