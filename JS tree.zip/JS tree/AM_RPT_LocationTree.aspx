﻿<%@ Page Title="" Language="C#" MasterPageFile="~/PopupLayout.Master" AutoEventWireup="true" CodeBehind="AM_RPT_LocationTree.aspx.cs" Inherits="SummitWeb.MDLAssetMgmt.AM_RPT_LocationTree" %>
<%@ Register Src="~/UserControls/UC_InstanceDDL.ascx" TagName="UCInstance" TagPrefix="UC" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <link href="../Includes/plugins/jquery/jquery.treetable.css" rel="stylesheet" />
    <script src="../Includes/plugins/jquery/jquery.treetable.js"></script>
    <link href="../Includes/plugins/jquery/jquery.treetable.theme.default.css" rel="stylesheet" />
    <style type="text/css">
     .treetable .indenter > a {text-decoration: none !important;}
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPanel" runat="server">
     <div id="divAllocatedAssetReportContainer">
        <div class="page-header">
            <div class="col-xs-12 pad-left-zero">
                <div class="col-xs-12 pad-left-zero">
                    <div class="page-title">
                        <h3><asp:Label ID="lblPageHeading" runat="server" meta:resourcekey="lblPageHeading"></asp:Label></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 disp-table gv-container">
                <div class="col-xs-11 col-md-11 pad-left-zero disp-tbl-cell">
                    <div class="page-min-height">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-6 col-md-6 col-lg-6 grid-pnl-title">
                                        <asp:Label ID="lblPanelHeading" runat="server" Text="<%$ Resources:GlobalResources, Details %>"></asp:Label>
                                    </div>
                                    <div class="pull-right panel-header-filters" style="padding-right:0px;padding-left:0px;width:120px">
                                        <div class="filter last" style="padding-right:0px">
                                            <span id="spanExpand" style="display:block"><a id="ExpandCollapse" href="javascript:void(0)" onclick="ExpandAll();">
                                                <span id="spanExapandCollapseImg" class="fa fa-plus-square" style="color: #7c7c7c;font-size: 16px;"></span>
                                                <asp:Label ID="lblExpandAll" runat="server" meta:resourcekey="lblExpandAll"></asp:Label>
                                            </a>
                                            </span>
                                            <span id="spanCollapse" style="display:none">
                                                <a href="javascript:void(0)" onclick="CollapseAll();">
                                                 <span class="fa fa-minus-square" style="color: #7c7c7c;font-size: 16px;"></span>
                                                 <asp:Label ID="lblCollapseAll" runat="server" meta:resourcekey="lblCollapseAll"></asp:Label>
                                                </a>
                                            </span>
                                        </div>
                                        <%--<div class="filter last" style="padding-right:0px">
                                            
                                        </div>--%>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body padding-zero">
                                <div class="table-responsive">
                                    <div id="PrintSection" runat="server" class="divGrid" style="overflow:auto;">
                                          <table id="example-basic" class="table mstGV" style="padding:0px; border:none;">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        <asp:Label ID="lblLocation" runat="server" Text="<%$ Resources:GlobalResources, Location %>"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="lblType" runat="server" Text="<%$ Resources:GlobalResources, Type %>"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="lblCount" runat="server" Text="<%$ Resources:Count %>"></asp:Label>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody >
                                                <asp:Literal ID="ltrlTree" runat="server"></asp:Literal>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-1 col-md-1 disp-tbl-cell">
                    <div class="action-container rpt-action-container action-col-2">
                        <div class="filters">
                            <div class="filter-tooltip filter-title action-title-with-filter" title="<%$ Resources:FilterTitle%>" runat="server">
                                <a id="filter" class="filters-pop" href="javascript:void(0);"><span class="filter-icon">&nbsp;</span><asp:Label ID="lblAnchorText" runat="server" Text="<%$ Resources:GlobalResources, Filter %>"></asp:Label></a>
                                <div id="filters" class="filters-content-small" style="display: none;">
                                    <div class="popover-head">
                                        <asp:Label ID="lblFilterHeading" runat="server" Text="<%$ Resources:GlobalResources, Filter %>"></asp:Label>
                                        <a id="ActionFilterClose" class="pull-right close">X</a>
                                    </div>
                                    <div class="content">
                                        <div class="arrow_box"></div>
                                        <div class="col-xs-12 col-md-12">
                                             <div class="row">
                                                <div class="col-xs-6 col-md-4">
                                                    <asp:Label class="control-label mandatoryField" ID="lblInstance" runat="server"></asp:Label>
                                                </div>
                                                <div class="col-xs-6 col-md-8 pad-left-zero">
                                                    <UC:UCInstance ID="UCInstanceList" runat="server"  ShowAsDropdownList="true"/>
                                                </div>
                                            </div>
                                            <div class="filters-btn-container">
                                                <div class="pull-right">
                                                    <asp:Button ID="btnApply" runat="server" Text="<%$ Resources:GlobalResources, btnApply %>" CssClass="btn btn-primary" OnClick="btnApply_Click" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="action-title action-title-with-filter">
                            <asp:Localize ID="lAction" runat="server" Text="<%$ Resources:GlobalResources, Action %>" />
                        </div>
                        <div class="actions-content col-md-12 col-xs-12">
                            <div class="actions col-md-6 col-xs-12 padding-zero" id="divPrintAction" runat="server">
                                <asp:LinkButton ID="lbtnPrintData" runat="server" CssClass="icon fa fa-print icon-font"  OnClientClick="javascript:return OpenWindowToPrintPO();return false;">
                                    <asp:Label ID="lblPrintData" runat="server" Text="<%$ Resources:GlobalResources, Print %>" CssClass="control-label" style="padding-top:15px" Tooltip="<%$ Resources: PrintTitle %>"></asp:Label>
                                </asp:LinkButton>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <asp:HiddenField ID="hdnDefaultPopupFlag" runat="server" Value="" />
        <asp:HiddenField ID="hdnChartDetails" runat="server" />
    </div>
    <script>
        var form;
        var Initialize = function () {
            // this is to apply css on dropdown button
            InitializeSelect2();

            //used for action tooltip
            InitTooltip(".icon", "bottom", "hover", "true", "body");

            form = $("#form1");
            var Instance = $('#<%=UCInstanceList.Instance.ClientID %>').val();
            
            var btnApply = '<%=btnApply.ClientID %>';
            if(!(typeof($('#'+btnApply).val())=='undefined')){
                $('#<%=btnApply.ClientID %>').click(ValidateOnApply);
            }
            
            if (Instance == null || Instance == '') {
                unblockUI();
            }
        }
       
        function ValidateOnApply() {
            form.validate({
                rules: { 
                    <%= UCInstanceList.Instance.UniqueID %>: {
                        required: true
                    },
                },
                messages: { 
                    <%= UCInstanceList.Instance.UniqueID %>: {
                        required:"<%=string.Format(GetGlobalMessage("SelectThe"),InstanceDisplayName)%>"                   
                    },
                }
            });

            if (form.valid()) {
                blockUI();
                $('#<%=hdnDefaultPopupFlag.ClientID %>').val("0");
            }
        }

        $(document).ready(function () {
            Initialize();
            var hdnPopUpValue=$('#<%=hdnDefaultPopupFlag.ClientID %>').val();
            if(hdnPopUpValue == "")
            {
                TogglePopUp();
            }
            else if(hdnPopUpValue=="1")
            {
                TogglePopUp();
            }
        });

        $('#filter').click(TogglePopUpOnFilterClick);
        $('#ActionFilterClose').click(TogglePopUpOnFilterClick);

        function TogglePopUpOnFilterClick(){
            $('#<%=hdnDefaultPopupFlag.ClientID %>').val("");
            $("#filters").toggle();
        }
        
        function TogglePopUp(){
            $("#filters").toggle();
        }

        //function to print
        function OpenWindowToPrintPO(ddd) {
            var content = document.getElementById('<%=PrintSection.ClientID%>');
            var Heading = "<%=GetLocalMessage("PopupPrintHeading")%>";
            PrintGridData(content, Heading);
            return false;
        }

        function getDocHeight() {

            var doc = doc || document;
            // stackoverflow.com/questions/1145850/
            var body = doc.body, html = doc.documentElement;
            var height = Math.max(body.scrollHeight, body.offsetHeight,
        html.clientHeight, html.scrollHeight, html.offsetHeight);

        }

        $("#example-basic").treetable({
            expandable: true,
            onNodeCollapse: function () {
                getDocHeight()
            },
            onNodeExpand: function () {
                getDocHeight()
            }
        });

        function fnOpenChildStore(parentid, Instance, sType) {
            var url = "../MDLAssetMgmt/AM_RPT_StoreWise.aspx?param=LC|" + parentid + "|" + Instance;
            var title = '<%=GetLocalMessage("PopupListHeading")%>';

            showSpopUpNav({
                'width': '100%', 'height': '100%', 'autoScale': false, 'transitionIn': 'elastic', 'transitionOut': 'elastic',
                'type': 'iframe', 'showCustomTitle': true, 'title': title, 'titlePosition': 'top', 'href': url
            });
        }

        function ExpandAll(){
            jQuery('#example-basic').treetable('expandAll'); 
            $("#spanCollapse").css("display","");
            $("#spanExpand").css("display","none");
            return false;
        }

        function CollapseAll(){
            jQuery('#example-basic').treetable('collapseAll');
            $("#spanCollapse").css("display","none");
            $("#spanExpand").css("display","");
            return false;
        }
</script>
</asp:Content>
