﻿using Summit_BLL;
using Summit_H;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SummitWeb.MDLAssetMgmt
{
    public partial class AM_RPT_LocationTree : BasePage
    {
        private int rowCount = 0;
        string Instance
        {
            get
            {
                return UCInstanceList.Instance.SelectedValue;
            }
            set
            {
                UCInstanceList.Instance.ClearSelection();
                if (UCInstanceList.Instance.Items.FindByValue(value) != null)
                    UCInstanceList.Instance.SelectedValue = value;
            }
        }

        public string InstanceDisplayName
        {
            get
            {
                return AppSettings.InstanceDisplayName;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //BindEvents();

                if (!Page.IsPostBack)
                {
                    Initialize();
                }
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_RPT_LocationTree.Page_Load()", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }

        /// <summary>
        /// Binds events to user instance dropdown
        /// </summary>
        void BindEvents()
        {
            UCInstanceList.Instance.SelectedIndexChanged += ddlInstance_SelectedIndexChanged;
            UCInstanceList.Instance.AutoPostBack = false;
        }

        /// <summary>
        /// Initialize methods to load master data
        /// </summary>
        void Initialize()
        {
            LoadInstance();
            if (Instance.IsNotNullAndEmpty())
            {
                LoadDashboard();
            }
            ShowFilterPopupWhenNoData();
        }

        private void ShowFilterPopupWhenNoData()
        {
            if (rowCount == 0)
            {
                SetHdnPopupFlagValue("1");
            }
        }

        /// <summary>
        /// Load instance list
        /// </summary>
        private void LoadInstance()
        {
            lblInstance.Text = AppSettings.InstanceDisplayName;
            UCInstanceList.ListRole = Summit_BLL.Common.InstanceListRole.RPTUser;
            UCInstanceList.ModuleCode = SSModules.AM;
            UCInstanceList.BindData();

            string CurrentReportInstance = AppSettings.CurrentReportInstance;
            if (CurrentReportInstance.IsNotNullAndEmpty())
            {
                UCInstanceList.Instance.SelectedValue = CurrentReportInstance;
            }

            if (Instance == "")
                ShowMessage(GetGlobalMessage("SelectInstance") + " " + AppSettings.InstanceDisplayName + ".", MessageType.Information, MessageContainer.OnScreen);
        }

        /// <summary>
        /// This is called when user selects value from instance dropdown 
        /// </summary>
        protected void ddlInstance_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (Instance.IsNotNullAndEmpty())
                {
                    AppSettings.CurrentUserInstance = Instance;
                    SaveAppSettings();

                    LoadDashboard();
                }
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_RPT_LocationTree.ddlInstance_SelectedIndexChanged()", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }

        protected void btnApply_Click(object sender, EventArgs e)
        {
            try
            {
                if (Instance.IsNotNullAndEmpty())
                {
                    AppSettings.CurrentReportInstance = Instance;
                    SaveAppSettings();

                    LoadDashboard();
                }
            }
            catch (Exception ex)
            {
                Helper.LogMessage("WEB", "AM_RPT_LocationTree.btnApply_Click()", ex.ToString(), false);
                ShowMessage(GetGlobalMessage("PageError"), MessageType.Error, MessageContainer.OnScreen);
            }
        }

        private void LoadLocationTree(DataTable dvData, ref StringBuilder refTable)
        {
            DataRelation relData = new DataRelation("ParentChild", dvData.Columns["StoreID"], dvData.Columns["LocRoot"], false);
            relData.Nested = false;
            dvData.ChildRelations.Add(relData);

            foreach (DataRow parentItem in dvData.Rows)
            {
                if (parentItem["LocRoot"] == DBNull.Value)
                {
                    refTable.Append(string.Format("<tr data-tt-id='{0}'>", parentItem["StoreID"].ToString()));
                    refTable.Append("<td>" + parentItem["Value"].ToString() + "</td>");
                    refTable.Append("<td>" + parentItem["ItemType"].ToString() + "</td>");
                    if (!parentItem["ItemType"].ToString().Equals("Location", StringComparison.OrdinalIgnoreCase))
                    {
                        refTable.Append("<td><a href='" + AM_Common.DummyNavigateURL + "' class='GridValue' onclick=\"return fnOpenChildStore('" + parentItem["StoreID"].ToString().Trim() + "','" + Instance + "','');\" >" + parentItem["NoOfAsset"].ToString() + "</a></td>");
                    }
                    else
                    {
                        refTable.Append("<td>" + parentItem["NoOfAsset"].ToString() + "</td>");
                    }
                    refTable.Append("</tr>");

                    BuildLocationSubTree(parentItem, parentItem["StoreID"].ToString(), ref refTable);
                }
            }
        }

        /// <summary>
        /// Build Sub Tree
        /// </summary>
        private void BuildLocationSubTree(DataRow parentItem, string parentID, ref StringBuilder refTable)
        {
            foreach (DataRow childItem in parentItem.GetChildRows("ParentChild"))
            {
                refTable.Append(string.Format("<tr data-tt-id='{0}' data-tt-parent-id='{1}'>", childItem["StoreID"].ToString(), parentID));
                refTable.Append("<td>" + childItem["Value"].ToString() + "</td>");
                refTable.Append("<td>" + childItem["ItemType"].ToString() + "</td>");
                if (!childItem["ItemType"].ToString().Equals("Location", StringComparison.OrdinalIgnoreCase))
                {
                    refTable.Append("<td><a href='"+AM_Common.DummyNavigateURL+"' class='GridValue' onclick=\"return fnOpenChildStore('" + childItem["StoreID"].ToString().Trim() + "','" + Instance + "','');\" >" + childItem["NoOfAsset"].ToString() + "</a></td>");
                }
                else
                {
                    refTable.Append("<td>" + childItem["NoOfAsset"].ToString() + "</td>");
                }
                //refTable.Append("<td>" + childItem["NoOfAsset"].ToString() + "</td>");
                refTable.Append("</tr>");

                BuildLocationSubTree(childItem, childItem["StoreID"].ToString(), ref refTable);
            }
        }

        private void LoadDashboard()
        {
            if (!Validation())
                return;

            AM_RPTAssetM _RPTAssetM = new AM_RPTAssetM();
            DataView dvLocReport = null;
            if (_RPTAssetM.Get_LocationTreeSummary(Instance, "0"))
            {
                dvLocReport = _RPTAssetM.DVData;
                if (_RPTAssetM.DVData.Count > 0)
                {
                    rowCount = dvLocReport.Count;
                    StringBuilder table = new StringBuilder();
                    LoadLocationTree(dvLocReport.Table, ref table);
                    ltrlTree.Text = table.ToString();
                }
                else
                {
                    string noData="<tr class='align-center'><td colspan='3'>"+GetGlobalMessage("NoData")+"</td></tr>";
                    ltrlTree.Text = noData;
                }
                SetHdnPopupFlagValue("0");
            }
        }

        /// <summary>
        /// This validates filter criteria before Search
        /// </summary>
        private bool Validation()
        {
            bool isError = true;
            string message = string.Empty;
            if (string.IsNullOrEmpty(Instance))
            {
                isError = false;
                message = string.Format(GetGlobalMessage("SelectThe"), AppSettings.InstanceDisplayName);
            }

            if (!string.IsNullOrEmpty(message))
            {
                ShowMessage(message, MessageType.Information, MessageContainer.OnScreen);
            }

            if (isError == false)
                SetHdnPopupFlagValue("1"); //error code

            return isError;
        }

        /// <summary>
        /// This sets hdnDefaultPopupFlag value to handle opening/closing of filter.
        /// </summary>
        private void SetHdnPopupFlagValue(string value)
        {
            hdnDefaultPopupFlag.Value = value;
        }
    }
}