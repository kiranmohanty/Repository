﻿///app.init.js - global initializers - scope: entire application
var ModulesCodes = [{ Module: 'Incident', Code: 'IM' }, { Module: 'Child Incident', Code: 'IM' }, { Module: 'Problem', Code: 'PM' }, { Module: 'Change', Code: 'CR' }, { Module: 'Work Order', Code: 'WO' }, { Module: 'Configuration Item', Code: 'CI' }, { Module: 'Service Request', Code: 'SR' }, { Module: 'Task', Code: 'TA' }, { Module: 'Asset', Code: 'AM' }, { Module: 'Knowledge', Code: 'KM' }, { Module: 'Availability', Code: 'AVM' }, { Module: 'Event', Code: 'EVM' }, { Module: 'Project', Code: 'PRJM' }, { Module: 'Release', Code: 'RM' }, { Module: 'Service Catalog', Code: 'SC' }, { Module: 'Asset', Code: 'AM' }, { Module: 'User Asset', Code: 'UA' }, { Module: 'SLR', Code: 'SLAR' }, { Module: 'Portfolio', Code: 'PFM' }, { Module: 'Service Level Agreement', Code: 'SLA' }, { Module: 'Operational Level Agreement', Code: 'OLA' }, { Module: 'Underpining Contract', Code: 'UPC' }, { Module: 'CIServices', Code: 'CISER' }, { Module: 'Release', Code: 'RM' }, { Module: 'CAB Meeting', Code: 'CRMEET' }, { Module: 'Purchase Request', Code: 'EPROC' }];
var EmptyPlaceholderForInputs = ['0001-01-01T00:00:00', '0001-01-01 00:00:00'];
//Declare the Global Error Message Interval
var ErrorMessageInterval = { value: 5000 };
var InitializeSelect2 = function () {
    $("select.select2").select2({ minimumResultsForSearch: -1 });
    $("select.select2WithSearch").select2();
    $('.popup-controls .select2-arrow').addClass('select2-arrow-popup b');
    $('select.select2WithTooltip').select2({
        formatResult: function (data, par) {
            return $("<span title='" + data.text + "' style='word-wrap:break-word'></span>").text(data.text);
        }
    });
}
var Select2Readonly = function () {
    $("select.select2").select2("readonly", true);
    $("select.select2WithSearch").select2("readonly", true);
}
var DisableDatepicker = function () {
    $('.datepicker').each(function (ind, item) {
        $(this).datepicker("disable");
    });
    $('.datetimepicker').each(function (ind, item) {
        $(this).datepicker("disable");
    });
}
var InitializeUI = function () {
    InitializeSelect2();
    $('[data-toggle="tooltip"]').tooltip();
    $('.page-wrapper').css({
        'min-height': '600px'
    });
    if (window.__ExtentionMethodsInit) __ExtentionMethodsInit();
    datepicker();
    datetimepicker();
    MarkRequiredInputs();
}
var MarkRequiredInputs = function () {
    $('.mandatoryField').each(function () {
        if (!$(this).hasClass('mandatoryMark')) $(this).html($(this).text() + ' <span class="mandatory">*</span>').addClass('mandatoryMark');

    });
    //$('label.required').each(function () { $(this).prev('label').after('*'); });
}
var RemoveMandatoryMark = function () {
    $('.mandatoryField').each(function () { $(this).find('span.mandatory').remove(); });
    $('.mandatoryMark').each(function () { $(this).find('font').remove(); });
}
//blockUI
$.blockUI.defaults.overlayCSS.backgroundColor = '#ffffff';
$.blockUI.defaults.css.border = '5px solid #99b433';
$.blockUI.defaults.css.backgroundColor = '#99b433';
$.blockUI.defaults.css.color = '#fff';
// make overlay more transparent 
$.blockUI.defaults.overlayCSS.opacity = 1;
var blockUI = function (nomsg) {
    if (nomsg) $.blockUI.defaults.overlayCSS.opacity = .7; else $.blockUI.defaults.overlayCSS.opacity = 1;
    $('#page-wrapper').block({ message: ((nomsg) ? '' : '<h4>Processing</h4>') });
}
var unblockUI = function () {
    $('#page-wrapper').unblock();
}
//-------------------
var IntOnly = function () {
    $(".intOnly").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Allow: Ctrl+V, Ctrl+v
            ((e.keyCode == 86 || e.keyCode == 118) && e.ctrlKey === true) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    }).blur(function (e) {
        var v = $(this).val();
        if (v != '') $(this).val(v.replace(/[^0-9\.]/g, ''));
    });
}

var __FilterGridRows = function (gridClientID, filterTextClientID) {
    var textBox = $('#' + filterTextClientID);
    $('#' + gridClientID + ' tr:has(td)').each(function () {
        var t = $(this).find('td:not(.ZeroWidth)'); // bug :23448 -> excluding the zerowidth cells for search
                 t= t.text().toLowerCase()        
              //  var t = $(this).text().toLowerCase();
               $("<td class='indexColumn'></td>").hide().text(t).appendTo(this);           
    });
    textBox.keyup(function () {       
        var txt = textBox.val().toLowerCase();        
        if (txt.length > 1) {
            $("#" + gridClientID + " tr:hidden").show();
            $.each(txt.split(" "), function () {
                $("#" + gridClientID + " tr:visible .indexColumn:not(:contains('" + this + "'))").parent().hide();
            });
        } else {
            $("#" + gridClientID + " tr:hidden").show();
        }
    });
}
var InitPopovers = function () {
    //$('.bs-popover').popover();

}



var InitializeJqueryValidator = function () {
    $.validator.setDefaults({
        ignore: []
    });
}
var InitOnScreenNotification = function (msg, type, timeOutInterval, maxVisible) {
    try
    {
        var interval = 30000; if (timeOutInterval) interval = timeOutInterval;
        var maxVisibleCount = 1; if (maxVisible && maxVisible > 0) maxVisibleCount = maxVisible;
        $.noty.closeAll();
        var to = setTimeout(function () {
            var n = noty({
                text: msg, timeout: interval, type: type, maxVisible: maxVisibleCount, dismissQueue: true,
                callback: {
                    afterClose: function () {
                        unblockUI();
                    }
                }
            });
            clearTimeout(to);
        }, 600);
    }
    catch(e)
    {
    }
}

var InitTooltip = function (classname, placement, trigger, animation, container) {
    $(classname).tooltip({
        placement: placement, trigger: trigger, animation: animation, container: container
    });
}

var Confirmation = function (msg, okCallback, cancelCallback) {
    bootbox.confirm(msg, function (result) {
        if (result && okCallback)
            okCallback();
        else if (cancelCallback)
            cancelCallback();
    });
}

var ClearCalendarButton = function () {
    var dpFunc = $.datepicker._generateHTML;
    $.datepicker._generateHTML = function (inst) {
        var thishtml = $(dpFunc.call($.datepicker, inst));
        thishtml = $('<div />').append(thishtml); //add a wrapper div for jQuery context
        //locate the button panel and add our button - with a custom css class.
        $('.ui-datepicker-buttonpane', thishtml).append(
            $('<button class="\
                 ui-datepicker-clear ui-state-default ui-priority-primary ui-corner-all\
                  "\>Clear</button>'
            ).click(function () {
                inst.input.datepicker('hide');
                inst.input.attr('value', '');
            })
        );
        thishtml = thishtml.children();
        return thishtml;
    };
}
var addDateSelector = function (ele) {
    if (!$(ele).hasClass('datatimeselectorset')) {
        $(ele).addClass('datatimeselectorset');
        $(ele).wrap('<div class="input-group"></div>');
        $('<span class="input-group-btn"><button type="button" class="btn btn-default search-btn"><span class="fa fa-calendar search-input-group"></span></button></span>').insertAfter($(ele)).click(function () {
            $(ele).datetimepicker('show');
        });
    }
}

$(document).ready(function () {
    $.datepicker._gotoToday = function (id) {
        try {

            var browser = get_browser_info();
            if (browser.name.trim().toLowerCase().match('ie|msie')) {
                $(id).datepicker('setDate', new Date()); $(id).blur();
                setTimeout(function () { $(id).datepicker('hide').click(); }, 50);
            }
            else
                $(id).datepicker('setDate', new Date()).datepicker('hide').blur();
        } catch (e) { console.log(e) }
    }


    //jQuery.datepicker._gotoToday = function (id) {
    //    var target = jQuery(id);
    //    var inst = this._getInst(target[0]);
    //    if (this._get(inst, 'gotoCurrent') && inst.currentDay) {
    //        inst.selectedDay = inst.currentDay;
    //        inst.drawMonth = inst.selectedMonth = inst.currentMonth;
    //        inst.drawYear = inst.selectedYear = inst.currentYear;
    //    }
    //    else {
    //        var date = new Date();
    //        inst.selectedDay = date.getDate();
    //        inst.drawMonth = inst.selectedMonth = date.getMonth();
    //        inst.drawYear = inst.selectedYear = date.getFullYear();
    //        this._setDateDatepicker(target, date);
    //        this._selectDate(id, this._getDateDatepicker(target));
    //    }
    //    this._notifyChange(inst);
    //    this._adjustDate(target);
    //}

});


var beforeShowDatePicker = function (input, inst) {
    if ($('body').hasClass('mCustomScrollbar')) {
        setTimeout(function () {
            var top = parseInt(inst.dpDiv.parent().css("top"));
            top = isNaN(top) ? 0 : Math.abs(top);
            var topOfDp = parseFloat(inst.dpDiv.css("top"));
            topOfDp = isNaN(topOfDp) ? 0 : topOfDp;
            var newTop = top + topOfDp;
            inst.dpDiv.css({ 'top': newTop + 'px' });
        }, 0)
    }
}

var onSelectDatePicker = function (input, inst) {
    try {
        var f = $(this).data('onselect'); if (f != '' && f != undefined) eval(f + '()');
    } catch (e) { }
    if (inst != null && typeof (inst) != 'undefined' && inst.input != null && typeof (inst.input) != 'undefined' && inst.input.length > 0
        && typeof ($(inst.input[0]).attr('data-field-type')) != 'undefined' && $(inst.input[0]).attr('data-field-type') == 'date' && input != '') {
        $(this).valid();
    }


};

var datepicker = function () {
    var pickerOpts = { showButtonPanel: true, dateFormat: "yy-mm-dd", buttonText: "", changeMonth: true, changeYear: true, yearRange: "-100:+50", beforeShow: beforeShowDatePicker };  //, onSelect: onSelectDatePicker 
    $('.datepicker').datepicker(pickerOpts);
    $('.datepicker').each(function (ind, item) {
        if ($(item).data('disabledatepicker')) {
            $(item).datepicker("option", "disabled", true);
        } else {
            addDateSelector(item);
        }
        //addDateSelector(item);
    });
}
var datetimepicker = function () {
    $('.datetimepicker').datetimepicker({ controlType: 'select', showButtonPanel: true, changeMonth: true, buttonText: "", dateFormat: "yy-mm-dd", changeYear: true, onSelect: function () { var f = $(this).data('onselect'); if (f != '' && f != undefined) eval(f + '()'); }, onClose: function () { var f = $(this).data('onclose'); if (f != '' && f != undefined && $(this).val() != '') eval(f + '()'); } });
    $('.datetimepicker').each(function (ind, item) { addDateTimeSelector(item); });
}




var addDateTimeSelector = function (ele) {
    if (!$(ele).hasClass('datatimeselectorset')) {
        $(ele).addClass('datatimeselectorset');
        $(ele).wrap('<div class="input-group"></div>');
        $('<span class="input-group-btn"><button type="button" class="btn btn-default search-btn"><span class="fa fa-calendar search-input-group"></span></button></span>').insertAfter($(ele)).click(function () {
            var ele_val = $('#' + ele.id).val();
            if (ele_val.length > 0) {
                var inputDateFormat = ['YYYY-MM-DD hh:mm:ss A', 'YYYY-MM-DD HH:mm:ss'];
                ele_val = moment(ele_val, inputDateFormat).format('YYYY-MM-DD HH:mm');
                $('#' + ele.id).val(ele_val);
            }
            $(ele).datetimepicker('show');
        });
    }
}
var ScrollTo = function (id) { $('html, body').animate({ scrollTop: $('#' + id).offset().top }, 900); }
var InitBootboxPopup = function () {
    bootbox.setDefaults({
        backdrop: true,
        closeButton: true,
        animate: true,
        className: "my-modal",
        onEscape: function () { $('.modal-backdrop.fade').remove() }
    });
}
var bootAlert = function (msg, callBack) {
    if (!callBack) callBack = function () {
        $('.modal-backdrop').css({ 'position': 'relative' });
    }
    bootbox.alert(msg, callBack);
}
var InitImageOpenerForTimeline = function () {
    $('.description img').click(function () {
        bootbox.alert({
            foo: "bar", width: "1000px", height: function () { return String($(window).height() - 165) + 'px'; }
            , message: '<img src="' + $(this).attr('src') + '" />'
        }).find("div.modal-dialog").addClass("bootboxforImage");
    });
}
var InitializePopoverForm = function () {
    $('.popover-form').each(function () {
        var t = $(this);
        var p = t.find('.opener').popover({ placement: 'top', html: true, title: t.find('.popover-head').html(), content: t.find('.popover-content').html() });
    });
}
var InitializeTabSelection = function (callback) {
    if (callback) {
        $('.tab-wrapper ul li').each(function (ind, item) {
            $(item).click(function () { callback(ind, $(item).text()); });
        });
    }
}

function ShowSModalPopUP(url, title, BaseURL, size) {
    var width = '98%'; if (size && size == 'medium') width = '60%';
    $.SPopUp({ 'modal': true, 'transitionIn': 'none', 'transitionOut': 'none', showDefaultActivity: true, 'ajax': { cache: false }, 'centerOnScroll': true, 'autoScale': false, 'type': 'iframe', 'width': width, 'height': '100%', 'href': url, 'showCustomTitle': true, 'title': title, 'titlePosition': 'top', 'image_path': BaseURL + '/Images/' });
}

function ShowSPopUP(url, title, BaseURL, size) {
    var width = '98%';
    var height = '100%';
    if (size && size == 'medium') width = '60%';
    if (size && size == 'small') {
        width = '60%';
        height = '75%';
    }
    showSpopUpNav({
        'transitionIn': 'none', 'transitionOut': 'none', showDefaultActivity: true, 'ajax': { cache: false }, 'centerOnScroll': true, 'autoScale': false, 'type': 'iframe', 'width': width, 'height': height, 'href': url, 'showCustomTitle': true, 'title': title, 'titlePosition': 'top', 'image_path': BaseURL + '/Images/'
    });
}
function OpenSummary(id, mod, baseurl, params) {
    if (mod == 'IM')
        ShowSPopUP("../MDLIncidentMgmt/IM_RPT_TicketDetail.aspx?ID=" + id, "Incident", baseurl);
    else if (mod == 'PM')
        ShowSPopUP("../MDLProblemMgmt/PM_ProblemTicket.aspx?ID=" + id, "Problem Record", baseurl);
    else if (mod == 'CM')
        ShowSPopUP("../MDLChangeMgmt/CM_RPT_ChangeRequest.aspx?ID=" + id, "Change Record", baseurl);
    else if (mod == 'CI')
        ShowSPopUP("../MDLCMDB/CMDB_DBConfigurationItem.aspx?Configuration_Item_Id=" + id + "&Hide_Menu=True", "Configuration Item", baseurl);
    else if (mod == 'CIDIAGRAM')
        ShowSPopUP("../MDLCMDB/CMDB_ViewConfigurationItem_Relation.aspx?id=" + id, "Configuration Item Relationship", baseurl);
    else if (mod == 'KB')
        ShowSPopUP("../MDLKnowledgeMgmt/KM_RPT_KADetails.aspx?ID=" + id, "Knowledge Article", baseurl);
    else if (mod == 'ASSET')
        ShowSPopUP("../MDLAssetMgmt/AM_RPT_Miscellaneous_DetailView.aspx?AstID=" + id + "&CatID=" + params.CatID, "Asset", baseurl);
    else if (mod == 'SERVER')
        ShowSPopUP("../MDLAVMMgmt/AVM_Common_SRV_ServerDetails.aspx?id=" + id, "Server", baseurl);
    else if (mod == 'NETWORK')
        ShowSPopUP("../MDLAVMMgmt/AVM_Common_NW_DeviceDetails.aspx?id=" + id, "Network", baseurl);
    else if (mod == 'NETWORK LINK')
        ShowSPopUP("../MDLAVMMgmt/AVM_Common_NW_LinkDetails.aspx?id=" + id, "Network Link", baseurl);
    else if (mod == 'SR')
        ShowSPopUP("../MDLServiceMgmt/SR_RPT_Report_Detail.aspx?ID=" + id, "Service Request", baseurl);
}

$(document).ready(function () {
    MarkRequiredInputs();
    IntOnly();
    InitPopovers();
    InitializeJqueryValidator();
    datepicker();
    datetimepicker();
    ClearCalendarButton();
    InitBootboxPopup();
    InitializePopoverForm();
    $(".hide-input").filestyle({ input: false });
    $(":file").filestyle('buttonText', '');
    $(':file').each(function () {
        if ($(this).is(':disabled'))
        { $(this).filestyle('disabled', true); }
    });
    //initializeNiceScroll();
    fnInitializeTextAreaKeyup();
    fnInitializeOnlyNumbers();
    fnInitTooltip();
    var browser = get_browser_info();
    $('body').addClass(browser.name + browser.version);
    $('.actions .icon,.actions .control-label,.actions .export-excel').tooltip({ placement: 'left', html: 'true' });
    $('.icon .popup-icon-header').tooltip({ placement: 'bottom', html: 'true' });

    $('.filter-tooltip').tooltip({ placement: 'left', html: 'true' });

    //Added by sudarsan
    $(".filter-tooltip").each(function () {
        $(this).parent().append($(this).find("#filters"));
    });
    //ends here



    $(".filters-content,.filters-content .select2-container").mouseenter(function () {
        $('.tooltip').css({ 'z-index': '0', 'opacity': '0', 'left': '-100000px' });
    });
    $('.filters-pop').hover(function () {
        $('.tooltip').css({ 'z-index': '0', 'opacity': '1' });
    });
    fnInitPriceValidation();
    fnInitCheckList();
    fnHideCustomControls();
    if (document.addEventListener) {
        document.addEventListener('paste', onPasteTriggered, false);
    }

});

//Trim()
function fnTrim(str, chars) {
    return fnLTrim(fnRTrim(str, chars), chars);
}
//LTrim()
function fnLTrim(str, chars) {
    chars = chars || "\\s";
    return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
}
//RTrim()
function fnRTrim(str, chars) {
    chars = chars || "\\s";
    return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
}
//Replacing String with RegEx
function fnReplaceReg(find, replaceWith, str) {
    var re = new RegExp(find, 'g');
    str = str.replace(re, replaceWith);
    return str;
}
//To Print grid View Data
function PrintGridData(divID, Heading) {

    var w = 950;
    var h = 650;
    var left = (screen.width / 2) - (w / 2);
    var top = (screen.height / 2) - (h / 2);

    var disp_setting = "toolbar=no,location=no,directories=no,menubar=no,";
    disp_setting += "scrollbars=yes,width=" + w + ", height=" + h + ", left=" + left + ", top=" + top + ",status=no";

    var content = divID;
    var contentValue;

    //if (content != null)
    //   contentValue = content.innerHTML.fnReplaceAll('<a', '<b');
    // contentValue = content.innerHTML;
    if (content != null) {
        contentValue = content.innerHTML;
        contentValue = fnReplaceReg('<a', '<span', contentValue)
    }
    if (Heading == null)
        Heading = "Asset Details";

    var docprint = window.open("", "", disp_setting);
    docprint.document.open();
    docprint.document.write('<html><head><title>' + Heading + '</title>');
    docprint.document.write('<style type="text/css">.grid-pager{display:none !important;} .mstGV{border:solid 1px;border-collapse: collapse; }.mstGV tr th,.mstGV tr td{border:solid 1px} .ZeroWidth{display:none;} .ControlHide{display:none;} .dynamic-table > td:first-child {width: 70%;}</style>')
    docprint.document.write('</head><body><h3>' + Heading + '</h3></body><body onLoad="self.print()"><center>');
    docprint.document.write(contentValue);
    docprint.document.write('</center></body></html>');
    docprint.document.close();
    docprint.focus();
    //docprint.close();//to close back window automatically once print ok r cancel
    return false;
}
//var initializeNiceScroll = function () {
//    $(".action-container").niceScroll({ cursorcolor: "#5078b3" });
//}


String.prototype.fnReplaceAll = function (stringToFind, stringToReplace) { var temp = this; var index = temp.indexOf(stringToFind); while (index != -1) { temp = temp.replace(stringToFind, stringToReplace); index = temp.indexOf(stringToFind); } return temp; }
jQuery.fn.center = function () {
    this.css("position", "fixed");
    this.css("top", ($(window).height() / 2) - (this.outerHeight() / 2));
    this.css("left", ($(window).width() / 2) - (this.outerWidth() / 2));
    return this;
}

function MultiUserParameter() {
    this.HdnMultiUsers = "";
    this.HdnMultiUserIDs = "";
    this.HdnEmail = "";
    this.ControlId = "";
    this.IsDisplayTextEmail = false;
    this.UserIdToAdd = 0;
    this.UserNameToAdd = "";
    this.UserEmailToAdd = "";
    this.isAddEvent = true;
}

function addRemoveMultiUser(multiuserObject) {
    try {
        var __ud = 'undefined'
        var _multiuser = new MultiUserParameter()
        _multiuser = multiuserObject;
        if (typeof (_multiuser) != __ud) {
            var multiUser = new Array();
            var multiUserID = new Array();
            var multiUserEmail = new Array();
            var lstMultiUser = $('#' + _multiuser.ControlId)[0];
            if (typeof (lstMultiUser) == __ud)
                console.log('invalid controlId');
            var _isdisplayEmail = false;
            if (typeof ($('#' + _multiuser.ControlId)[0]) != __ud && $('#' + _multiuser.ControlId)[0].getAttribute("il") == null) {
                if (typeof _multiuser.HdnMultiUsers != __ud && typeof $('#' + _multiuser.HdnMultiUsers)[0] != __ud && $('#' + _multiuser.HdnMultiUsers).val().trim().length > 0)
                    multiUser = $('#' + _multiuser.HdnMultiUsers).val().split('|');
                if (typeof _multiuser.HdnMultiUserIDs != __ud && typeof $('#' + _multiuser.HdnMultiUserIDs)[0] != __ud && $('#' + _multiuser.HdnMultiUserIDs).val().trim().length > 0)
                    multiUserID = $('#' + _multiuser.HdnMultiUserIDs).val().split(',');
                if (typeof _multiuser.HdnEmail != __ud && typeof $('#' + _multiuser.HdnEmail)[0] != __ud && $('#' + _multiuser.HdnEmail).val().trim().length > 0)
                    multiUserEmail = $('#' + _multiuser.HdnEmail).val().split('|');
                _isdisplayEmail = (typeof (_multiuser.IsDisplayTextEmail) != __ud && _multiuser.IsDisplayTextEmail == true) ? true : false;
                if ($('#' + _multiuser.ControlId)[0].getAttribute("il") == null) {
                    $('#' + _multiuser.ControlId)[0].setAttribute("hid", _multiuser.HdnMultiUserIDs);
                    $('#' + _multiuser.ControlId)[0].setAttribute("hus", _multiuser.HdnMultiUsers);
                    $('#' + _multiuser.ControlId)[0].setAttribute("hem", _multiuser.HdnEmail);
                    $('#' + _multiuser.ControlId)[0].setAttribute("il", "true");
                    $('#' + _multiuser.ControlId)[0].setAttribute("ie", _multiuser.IsDisplayTextEmail);
                    $('#' + _multiuser.ControlId).on("change", function () {
                        var _cntrl = $(this)[0]
                        var _m = new MultiUserParameter();
                        _m.HdnMultiUserIDs = _cntrl.getAttribute("hid");
                        _m.HdnMultiUsers = _cntrl.getAttribute("hus");
                        _m.HdnEmail = _cntrl.getAttribute("hem");
                        _m.ControlId = _cntrl.id;
                        _m.IsDisplayTextEmail = _cntrl.getAttribute("ie");
                        _m.isAddEvent = false;
                        addRemoveMultiUser(_m);
                    });
                }
            } else if ($('#' + _multiuser.ControlId)[0].getAttribute("il") != null) {

                if (lstMultiUser.getAttribute("hid") != null && typeof $('#' + lstMultiUser.getAttribute("hid"))[0] != __ud && $('#' + lstMultiUser.getAttribute("hid")).val().trim().length > 0)
                    multiUserID = $('#' + lstMultiUser.getAttribute("hid")).val().split(',');
                if (typeof lstMultiUser.getAttribute("hus") != null && typeof $('#' + lstMultiUser.getAttribute("hus"))[0] != __ud && $('#' + lstMultiUser.getAttribute("hus")).val().trim().length > 0)
                    multiUser = $('#' + lstMultiUser.getAttribute("hus")).val().split('|');
                if (typeof lstMultiUser.getAttribute("hem") != null && typeof $('#' + lstMultiUser.getAttribute("hem"))[0] != __ud && $('#' + lstMultiUser.getAttribute("hem")).val().trim().length > 0)
                    multiUserEmail = $('#' + lstMultiUser.getAttribute("hem")).val().split('|');
                _isdisplayEmail = (typeof (lstMultiUser.getAttribute("ie")) != null && lstMultiUser.getAttribute("ie") == "true") ? true : false;
            }
            if (typeof (_multiuser.isAddEvent) != __ud && _multiuser.isAddEvent) {
                for (var i = 0; i < multiUserID.length; i++) {
                    if (parseInt(multiUserID[i]) == _multiuser.UserIdToAdd)
                        return;
                }
                var _user = (_isdisplayEmail) ? _multiuser.UserEmailToAdd : _multiuser.UserNameToAdd;
                if (typeof (_multiuser.UserIdToAdd) != __ud && _multiuser.UserIdToAdd > 0 && typeof (_user) != __ud && _user.length > 0) {
                    multiUserID.push(_multiuser.UserIdToAdd + '');
                    multiUser.push(_multiuser.UserNameToAdd + '');
                    multiUserEmail.push(_multiuser.UserEmailToAdd + '');
                }
            } else {
                for (var i = 0; i < lstMultiUser.options.length; i++) {
                    if (!lstMultiUser.options[i].selected) {
                        lstMultiUser.remove(i);
                        break;
                    }
                }
                multiUser = new Array();
                multiUserEmail = new Array();
                multiUserID = new Array();
                for (var i = 0; i < lstMultiUser.options.length; i++) {
                    multiUserID.push(lstMultiUser.options[i].value);
                    multiUser.push(lstMultiUser.options[i].getAttribute("dtl").split(':')[1]);
                    multiUserEmail.push(lstMultiUser.options[i].getAttribute("dtl").split(':')[2]);
                }
            }
            if (lstMultiUser.getAttribute("hid") != null && typeof $('#' + lstMultiUser.getAttribute("hid"))[0] != __ud)
                $('#' + lstMultiUser.getAttribute("hid")).val(multiUserID.join(','));
            if (lstMultiUser.getAttribute("hus") != null && typeof $('#' + lstMultiUser.getAttribute("hus"))[0] != __ud)
                $('#' + lstMultiUser.getAttribute("hus")).val(multiUser.join('|'));
            if (lstMultiUser.getAttribute("hem") != null && typeof $('#' + lstMultiUser.getAttribute("hem"))[0] != __ud)
                $('#' + lstMultiUser.getAttribute("hem")).val(multiUserEmail.join('|'));

            if (typeof (_multiuser.isAddEvent) != __ud && _multiuser.isAddEvent == true && multiUserID.length > 0 && multiUser.length > 0 && multiUser.length > 0) {
                lstMultiUser.options.length = 0;
                for (var i = 0; i < multiUserID.length; i++) {
                    var optn = document.createElement("OPTION");
                    optn.text = (_isdisplayEmail) ? multiUserEmail[i] : multiUser[i];
                    optn.value = multiUserID[i];
                    lstMultiUser.options.add(optn);
                    lstMultiUser.options[i].selected = true;
                    var User = (typeof (multiUser[i]) != __ud) ? multiUser[i] : "";
                    var Email = (typeof (multiUserEmail[i]) != __ud) ? multiUserEmail[i] : "";
                    lstMultiUser.options[i].setAttribute("dtl", multiUserID[i] + ":" + User + ":" + Email);
                }
                InitializeSelect2();
            }
        } else {
            console.log("invalid multiuserparameter")
        }
    }
    catch (e) { if (typeof window.console != 'undefined') { console.log(e) } }
}

function showSpopUpNav(obj) {
    var snav
    if (typeof parent.parent._SPopUpNavigation != 'undefined')
        snav = parent.parent._SPopUpNavigation;
    else if (typeof parent._SPopUpNavigation != 'undefined')
        snav = parent._SPopUpNavigation
    else if (typeof _SPopUpNavigation != 'undefined')
        snav = _SPopUpNavigation

    if (typeof snav == 'undefined') {
        if (typeof parent.parent.SPopUpNavigation != 'undefined') {
            parent.parent._SPopUpNavigation = new parent.parent.SPopUpNavigation();
            snav = parent.parent._SPopUpNavigation
        }
        else if (typeof parent.SPopUpNavigation != 'undefined') {
            parent._SPopUpNavigation = new parent.SPopUpNavigation();
            snav = parent._SPopUpNavigation
        }
        else if (typeof SPopUpNavigation != 'undefined') {
            _SPopUpNavigation = new SPopUpNavigation();
            snav = _SPopUpNavigation
        }
    }
    snav.showPopup(snav, obj);

}
function showSpopUpBack(level) {
    var snav
    if (typeof parent.parent._SPopUpNavigation != 'undefined')
        snav = parent.parent._SPopUpNavigation;
    else if (typeof parent._SPopUpNavigation != 'undefined')
        snav = parent._SPopUpNavigation
    else if (typeof _SPopUpNavigation != 'undefined')
        snav = _SPopUpNavigation
    snav.GoBack(snav, level);
}

var SPopUpNavigation = function () {
    this.Displaydtl = null,
this.NavUrls = [],
    this.iframeobj = null,
    this.loadingimage = null,
    this.title = [],
    SPopUpNavigation.prototype.showPopup = function (ctrl, sPopupObj) {
        //if more then url in navigation show back button 
        //check spopup if there refresh the url else 
        //load new popup
        if (typeof sPopupObj != 'undefined' && typeof sPopupObj.href != 'undefined') {
            if (typeof this.Displaydtl != 'undefined' && this.Displaydtl != null && $('#SPopUp-frame')[0] != 'undefined' && $('#SPopUp-frame').is(':visible')) {
                if (typeof $('#SPopUp-frame')[0] != 'undefined') {
                    this.iframeobj = $('#SPopUp-frame')[0];
                    this.NavUrls.push(sPopupObj.href);
                    this.title.push(sPopupObj.title);
                    var iframeDocument = this.iframeobj.contentDocument || this.iframeobj.contentWindow.document;
                    iframeDocument.body.innerHTML = "";
                    try {
                        iframeDocument.body.appendChild(this.loadingimage);
                    } catch (e) {
                        iframeDocument.write('<div style="width:50%;margin-left:50%;top:50%;position:absolute;"><img src="../Images/AM_Waiting1.GIF" alt="Loading.." /></div>');
                    }
                    this.iframeobj.src = $("<div/>").html(sPopupObj.href).text().replace('¶', '&para');
                    if (this.NavUrls.length > 1)
                        ctrl.showBackButton();
                }
            }
            else {
                $.SPopUp(sPopupObj);
                this.NavUrls = [];
                this.NavUrls.push(sPopupObj.href);
                this.title = [];
                this.title.push(sPopupObj.title);
                this.Displaydtl = sPopupObj;
                this.loadingimage = new Image();
                this.loadingimage.style.top = "50%";
                this.loadingimage.style.position = "absolute";
                this.loadingimage.style.marginLeft = "50%";
                this.loadingimage.src = "../Images/AM_Waiting1.GIF";
            }
        }
    },
    SPopUpNavigation.prototype.GoBack = function (ctrl, level) {
        if (this.NavUrls.length > 1) {
            if (typeof level == 'undefined')
                level = 1
            this.title.splice(this.title.length - level, level);
            this.NavUrls.splice(this.NavUrls.length - level, level);//use splice url
            if (typeof $('#SPopUp-frame')[0] != 'undefined') {
                this.iframeobj = $('#SPopUp-frame')[0];
                var iframeDocument = this.iframeobj.contentDocument || this.iframeobj.contentWindow.document;
                iframeDocument.body.innerHTML = "";
                try {
                    iframeDocument.body.appendChild(this.loadingimage);
                } catch (e) {
                    iframeDocument.write('<div style="width:50%;margin-left:50%;top:50%;position:absolute;"><img src="../Images/AM_Waiting1.GIF" alt="Loading.." /></div>');
                }

                this.NavUrls[this.NavUrls.length - 1] = $("<div/>").html(this.NavUrls[this.NavUrls.length - 1]).text().replace('¶', '&para');
                this.iframeobj.src = this.NavUrls[this.NavUrls.length - 1];
                ctrl.showBackButton();
            }
        }
        //if only one url remove back button
        if (this.NavUrls.length < 2)
            ctrl.hideBackButton();
    },
    SPopUpNavigation.prototype.showBackButton = function () {
        if ($('#SPopUp-bg-n .TitlePanel')[0] != 'undefined') {
            var title = $('#SPopUp-bg-n .TitlePanel')[0]; var strTitle = ""; var level = 0;
            strTitle +="<div>"
            if (this.title.length == 1)
                strTitle += "<span class='popup-nav-title' style='overflow:auto;max-width:60em;overflow-text:inherit;' onclick='showSpopUpBack(" + level + ");'>" + this.title[0] + "</span>";
            else {
                for (var i in this.title) {
                    level = this.title.length - (parseInt(i) + 1);
                    strTitle += "<span class='popup-nav-title' onclick='showSpopUpBack(" + level + ");' data-toggle='tooltip' title='" + this.title[i].replace('"', '""').toUpperCase() + "'>" + this.title[i] + "</span>";
                    if (this.title.length - 1 != i)
                        strTitle += "<span class='fa fa-play popup-nav-arrow'>&nbsp; </span>";
                    
                }
            }
            strTitle += "</div>"
            $('.tooltip').hide();
            title.innerHTML = strTitle + '<span class="pull-right BackButton fa fa-backward" style="margin-right:50px;font-size: 28px;color:#d3d3d3; cursor:pointer" onclick="showSpopUpBack();">&nbsp;</span>' + '<a class="pull-right close" href="javascript:void(0)" onclick="$.SPopUp.close();">X</a>';
            InitTooltip(".popup-nav-title", "right", "hover", "true", "#SPopUp-bg-n");
            fnSpopBreadCrumbWidth();
        }
    }
    ,
    SPopUpNavigation.prototype.hideBackButton = function () {
        if ($('#SPopUp-bg-n .TitlePanel .BackButton')[0] != 'undefined') {
            var title = $('#SPopUp-bg-n .TitlePanel')[0];
            var child = $('#SPopUp-bg-n .TitlePanel').find('.BackButton')[0];
            if (typeof title != 'undefined' && typeof child != 'undefined')
                title.removeChild(child);
        }
    }
}

function fnSpopBreadCrumbWidth()
{
    try {
        var itemOuterWidth = $(".TitlePanel").width();
        var itemsWidth = $(".TitlePanel > div").width() + 100;
        console.log(itemsWidth);
        if (itemOuterWidth <= itemsWidth) {
            $(".popup-nav-title").css("max-width", "100px");
        }
    } catch (e) {
        console.log(e.message);
    }
}

function fnAssetDetail() {
    this.AssetID = '';
    this.CatID = '';
    this.SerialNo = '';
    this.HostName = '';
    this.IsDiscovery = '';
    this.MailDisplay = '';
    this.Criticality = '';
    this.Instance = '';
    this.Module = '';
    fnAssetDetail.prototype.fnNavAssetDetail = function (title) {

        var params = "?";
        if (typeof this.AssetID != 'undefined' && this.AssetID > 0)
            params += "AssetID=" + this.AssetID;
        if (typeof this.Criticality != 'undefined' && this.Criticality.length > 0)
            params += (params.length > 1) ? "&Criticality=" + this.Criticality : "Criticality=" + this.Criticality;
        if (typeof this.Module != 'undefined' && this.Module.length > 0)
            params += (params.length > 1) ? "&Module=" + this.Module : "Module=" + this.Module;
        if (typeof this.Instance != 'undefined' && this.Instance.length > 0)
            params += (params.length > 1) ? "&Instance=" + this.Instance : "Instance=" + this.Instance;
        if (typeof this.CatID != 'undefined' && this.CatID > 0)
            params += (params.length > 1) ? "&CatID=" + this.CatID : "CatID=" + this.CatID;
        if (typeof this.SerialNo != 'undefined' && this.SerialNo.length > 0)
            params += (params.length > 1) ? "&SerialNo=" + this.SerialNo : "SerialNo=" + this.SerialNo;
        if (typeof this.HostName != 'undefined' && this.HostName.length > 0)
            params += (params.length > 1) ? "&HostName=" + this.HostName : "HostName=" + this.HostName;
        if (typeof this.IsDiscovery != 'undefined' && this.IsDiscovery.length > 0)
            params += (params.length > 1) ? "&IsDiscovery=" + this.IsDiscovery : "IsDiscovery=" + this.IsDiscovery;
        if (typeof this.MailDisplay != 'undefined' && this.MailDisplay > 0)
            params += (params.length > 1) ? "&MailDisplay=" + this.MailDisplay : "MailDisplay=" + this.MailDisplay;

        var url = "../MDLAssetMgmt/AM_RPT_AssetDetailView.aspx" + params;
        var title = typeof (title) == 'undefined' ? 'ASSET DETAILS' : title;

        var obj = {
            'width': '100%',
            'height': '100%',
            'autoScale': false,
            'transitionIn': 'fade',
            'transitionOut': 'elastic',
            'type': 'iframe', 'showCustomTitle': true, 'title': title, 'titlePosition': 'top', 'href': url
        };
        showSpopUpNav(obj);
    }
}

function fnEntityDetail() {
    this.EntityID = '';
    this.EntityType = '';
    fnEntityDetail.prototype.fnNavDetailByEntityType = function (title) {
        var params = "?";
        if (typeof this.EntityID != 'undefined' && this.EntityID > 0)
            params += "id=" + this.EntityID;
        var url = '';
        var titleText = '';
        if (this.EntityType != 'undefined' && this.EntityType != null) {
            if (this.EntityType.toLocaleLowerCase() == 'server') {
                url = "../MDLAVMMgmt/AVM_Common_SRV_ServerDetails.aspx" + params;
                titleText = typeof (title) == 'undefined' ? 'SERVER DETAILS' : title;
            }
            else if (this.EntityType.toLocaleLowerCase() == 'device' || this.EntityType.toLocaleLowerCase() == 'network device') {
                url = "../MDLAVMMgmt/AVM_Common_NW_DeviceDetails.aspx" + params;
                titleText = typeof (title) == 'undefined' ? 'NETWORK DEVICE DETAILS' : title;
            }
            else if (this.EntityType.toLocaleLowerCase() == 'link' || this.EntityType.toLocaleLowerCase() == 'network link') {
                url = "../MDLAVMMgmt/AVM_Common_NW_LinkDetails.aspx" + params;
                titleText = typeof (title) == 'undefined' ? 'NETWORK LINK DETAILS' : title;
            }
            else if (this.EntityType.toLocaleLowerCase() == 'printer') {
                url = "../MDLAVMMgmt/AVM_Common_PRT_PrinterDetails.aspx" + params;
                titleText = typeof (title) == 'undefined' ? 'PRINTER DETAILS' : title;
            }
            else if (this.EntityType.toLocaleLowerCase() == 'proxy') {
                url = "../MDLAVMMgmt/AVM_ProxyDetail.aspx" + params;
                titleText = typeof (title) == 'undefined' ? 'PROXY DETAILS' : title;
            }
            else if (this.EntityType.toLocaleLowerCase() == 'url') {
                url = "../MDLAVMMgmt/AVM_Common_URLDetails.aspx" + params;
                titleText = typeof (title) == 'undefined' ? 'URL DETAILS' : title;
            }
            else if (this.EntityType.toLocaleLowerCase() == 'network interface') {
                url = "../MDLAVMMgmt/AVM_Common_NW_InterfaceDetails.aspx" + params;
                titleText = typeof (title) == 'undefined' ? 'NETWORK INTERFACE DETAILS' : title;
            }
            else {
                alert("Page is not found error");
            }
        }
        else {
            alert("Page is not found error");
        }
        var obj = {
            'width': '100%',
            'height': '100%',
            'autoScale': false,
            'transitionIn': 'fade',
            'transitionOut': 'elastic',
            'type': 'iframe', 'showCustomTitle': true, 'title': titleText, 'titlePosition': 'top', 'href': url
        };
        showSpopUpNav(obj);
    }
}

fnLoadAssetDetail = function (obj) {
    var assetDetail = new fnAssetDetail();
    if (typeof obj != 'undefined') {
        if (typeof obj.assetid != 'undefined') {
            assetDetail.AssetID = obj.assetid;
        }
        if (typeof obj.hostname != 'undefined') {
            assetDetail.HostName = obj.hostname;
        }
        if (typeof obj.catid != 'undefined') {
            assetDetail.CatID = obj.catid;
        }
        if (typeof obj.Instance != 'undefined') {
            assetDetail.Instance = obj.Instance;
        }
        if (typeof obj.serialno != 'undefined') {
            assetDetail.SerialNo = obj.serialno;
        }
        if (typeof obj.IsDiscovery != 'undefined') {
            assetDetail.IsDiscovery = obj.IsDiscovery;
        }
        if (typeof obj.MailDisplay != 'undefined') {
            assetDetail.MailDisplay = obj.MailDisplay;
        }
        if (typeof obj.Criticality != 'undefined') {
            assetDetail.Criticality = obj.Criticality;
        }
        if (typeof obj.Module != 'undefined') {
            assetDetail.Module = obj.Module;
        }
        if (typeof obj.title != 'undefined') {
            assetDetail.fnNavAssetDetail(obj.title);
        } else
            assetDetail.fnNavAssetDetail();
    }
}

fnLoadEntityTypeDetail = function (obj) {
    var entityDetail = new fnEntityDetail();
    if (typeof obj != 'undefined') {
        if (typeof obj.entityId != 'undefined') {
            entityDetail.EntityID = obj.entityId;
        }
        if (typeof obj.entityType != 'undefined') {
            entityDetail.EntityType = obj.entityType;
        }

        if (typeof obj.title != 'undefined') {
            entityDetail.fnNavDetailByEntityType(obj.title);
        } else {
            entityDetail.fnNavDetailByEntityType();
        }
    }
}

function AddClassToCell() {
    $('.mstNoWrap').find('td').each(function (index, value) {

        var _this = $(this)
        $(this).hover(function () {
            //alert("sdfdsf");
            // alert("ddddd");
            addCssClass($(this));
        })
    })
}
function addCssClass(obj) {
    var $element = obj;
    var $c = $element.clone().css({ display: 'inline', width: 'auto', visibility: 'hidden' }).appendTo('body');
    // alert("$c.width()===" + $c.width() + "$element.width()--" + $element.width());
    if ($c.width() > $element.width()) {
        obj.hover();
        obj.attr("data-container", "body").attr("data-toggle", "popover").attr("data-placement", "bottom").attr("data-content", obj.text()).popover({ trigger: "hover" });
        //obj.hover();
    }
    $c.remove();
}
function checkElipsis() {
    var $element = $('#element-to-test');
    var $c = $element
    .clone()
    .css({ display: 'inline', width: 'auto', visibility: 'hidden' })
    .appendTo('body');
    if ($c.width() > $element.width()) {
        // text was truncated. 
        // do what you need to do
    }
}

$(document).ready(function () {
    AddClassToCell();
})
/*Used for chart*/
// This is function to format string.
String.prototype.Format = function (args) {
    var str = this;
    return str.replace(String.prototype.Format.regex, function (item) {
        var intVal = parseInt(item.substring(1, item.length - 1));
        var replace;
        if (intVal >= 0) {
            replace = args[intVal];
        } else if (intVal === -1) {
            replace = "{";
        } else if (intVal === -2) {
            replace = "}";
        } else {
            replace = "";
        }
        return replace;
    });
};
String.prototype.Format.regex = new RegExp("{-?[0-9]+}", "g");

function ChartDetails() {
    this.ChartData = '';
    this.ChartTemplates = new Array();
}

function ChartTemplate() {
    this.Name = '';
    this.Template = '';
}

function GetChartTemplateByName(chartName, chartTemplateList) {
    var chartTemplate = '';
    if (chartTemplateList.length > 0) {
        for (var i = 0; i < chartTemplateList.length; i++) {
            var templateObject = chartTemplateList[i];
            if (templateObject.Name == chartName) {
                chartTemplate = templateObject.Template;
                break;
            }
        }
    }
    return chartTemplate;
}

function GetChartName(dropDownID) {
    var chartName = $('#' + dropDownID).val();
    return chartName;
}

function DrawChart(id, xmlData, chartName, divContainerForDrawChart, width, height) {
    FusionCharts.setCurrentRenderer('javascript');
    var fusionChart = new FusionCharts(chartName, id, width, height, "0");
    fusionChart.setXMLData(xmlData);
    fusionChart.render(divContainerForDrawChart);
}

function fnValidateMaxlengthforTextArea(maxLength, control) {
    var val = $(control).val();
    if (val.length > maxLength) {
        $(control).val(val.slice(0, maxLength));
    }
}
function fnInitializeTextAreaKeyup() {
    $(document).on("keyup", '.custom-textarea', function (event) {
        var val = $(this).val();
        var maxLength = $(this).attr('data-max-length');
        if (typeof (maxLength) != 'undefined' && maxLength != '') {
            if (val.length > parseInt(maxLength, 10)) {
                $(this).val(val.slice(0, maxLength));
            }
        }
    });
};

function fnValidateCustomAttributes() {
    var proceed = true;
    $('.cont-validate').each(function () {
        if (typeof ($(this).attr('data-ismultigroup-attribute')) != 'undefined' && $(this).attr('data-ismultigroup-attribute').toLowerCase() == "false") {
            //MANDOTARY VALIDATION STARTS 

            //Except checkbox
            if (typeof ($(this).attr('data-val-required')) != 'undefined') {
                if ($(this).attr('data-val-required').toLowerCase() == "true") {

                    // if ($(this).val().trim() == "") {
                    if (typeof ($(this).val()) == 'undefined' || $(this).val().trim() == "") {
                        InitOnScreenNotification('<div class="">' + $(this).attr('data-msg-required') + '</div>', 'validationmsg', 1000000);
                        $(this).addClass('error');
                        if (typeof ($(this).attr('data-tab')) != 'undefined') {
                            $($(this).attr('data-tab')).click();
                        }
                        proceed = false;
                        return false;
                    }
                    else {
                        $(this).removeClass('error');
                    }
                }
            }

            // For CheckboxList
            //Except checkbox
            if (typeof ($(this).attr('data-val-required-checkboxlist')) != 'undefined') {
                if ($(this).attr('data-val-required-checkboxlist').toLowerCase() == "true") {

                    // if ($(this).val().trim() == "") {
                    if (typeof ($(this).find(":checked").val()) == 'undefined') {
                        InitOnScreenNotification('<div class="">' + $(this).attr('data-msg-required') + '</div>', 'validationmsg', 1000000);
                        $(this).addClass('error');
                        if (typeof ($(this).attr('data-tab')) != 'undefined') {
                            $($(this).attr('data-tab')).click();
                        }
                        proceed = false;
                        return false;
                    }
                    else {
                        $(this).removeClass('error');
                    }
                }
            }

            // Only for checkbox 
            if (typeof ($(this).attr('data-val-required-checkbox')) != 'undefined') {
                if ($(this).attr('data-val-required-checkbox').toLowerCase() == "true") {
                    if ($(this).find('input[type=checkbox]').is(':checked') == false) {
                        InitOnScreenNotification('<div class="">' + $(this).attr('data-msg-required') + '</div>', 'validationmsg', 1000000);
                        $(this).addClass('error');
                        if (typeof ($(this).attr('data-tab')) != 'undefined') {
                            $($(this).attr('data-tab')).click();
                        }
                        proceed = false;
                        return false;
                    }
                    else {
                        $(this).removeClass('error');
                    }
                }
            }


            //MANDOTARY VALIDATION ENDS

            //MANDOTARY VALIDATION FOR THE CONTROLS WHICH ARE DEPENDENT ON STATUS STARTS
            //Except checkbox
            if (typeof ($(this).attr('data-rule-cfvdependsonstatus')) != 'undefined') {
                if (ddlStatus != null && typeof ddlStatus != 'undefined') {

                    var cfgroupid = $(this).attr('data-rule-cfgroupid');
                    var showValidation = false;
                    if (typeof (oCAWGAccess) != 'undefined' && oCAWGAccess && oCAWGAccess.length > 0) {
                        $.each(oCAWGAccess, function (i, item) {
                            if (item.IM_CtmGroup_ID == cfgroupid && item.WG_ID == ddlWorkgroup.val()) {
                                showValidation = true;
                            }
                        });
                    } else {
                        showValidation = true;
                    }

                    if (showValidation && ddlStatus.val() == $(this).attr('data-rule-cfvstatus') && ($(this).attr('type') != 'checkbox' && $(this).attr('data-field-type') != 'multidropdown' && $(this).val().trim() == '')) {
                        InitOnScreenNotification('<div class="">Specify ' + $(this).attr('data-msg-cfvdependsonstatus') + '</div>', 'validationmsg', 1000000);
                        $(this).addClass('error');
                        if (typeof ($(this).attr('data-tab')) != 'undefined') {
                            $($(this).attr('data-tab')).click();
                        }
                        proceed = false;
                        return false;
                    }
                    else {
                        $(this).removeClass('error');
                    }

                    if (showValidation && ddlStatus.val() == $(this).attr('data-rule-cfvstatus') && ($(this).attr('data-field-type') == 'multidropdown' && $(this).val() == null)) {
                        InitOnScreenNotification('<div class="">Specify ' + $(this).attr('data-msg-cfvdependsonstatus') + '</div>', 'validationmsg', 1000000);
                        $(this).addClass('error');
                        if (typeof ($(this).attr('data-tab')) != 'undefined') {
                            $($(this).attr('data-tab')).click();
                        }
                        proceed = false;
                        return false;
                    }
                    else {
                        $(this).removeClass('error');
                    }

                    // Only for checkbox 
                    if (ddlStatus.val() == $(this).attr('rule-cfvstatus') && ($(this).attr('type') != 'checkbox' && $(this).is(':checked') == false)) {
                        InitOnScreenNotification('<div class="">Specify ' + $(this).attr('data-msg-cfvdependsonstatus') + '</div>', 'validationmsg', 1000000);
                        $(this).addClass('error');
                        if (typeof ($(this).attr('data-tab')) != 'undefined') {
                            $($(this).attr('data-tab')).click();
                        }
                        proceed = false;
                        return false;
                    }
                    else {
                        $(this).removeClass('error');
                    }
                }
            }
            //MANDOTARY VALIDATION FOR THE CONTROLS WHICH ARE DEPENDENT ON STATUS ENDS

            // MIN LENGTH VALIDATION STARTS
            var minLength = $(this).attr('data-min-length');
            if (typeof (minLength) != 'undefined' && minLength != '') {
                if ($(this).val() != "" && $(this).val().length < parseInt(minLength, 10)) {
                    if (typeof ($(this).attr('data-min-length-msg')) != 'undefined') {
                        InitOnScreenNotification('<div class="">' + $(this).attr('data-min-length-msg') + '</div>', 'validationmsg', 1000000);
                        $(this).addClass('error');
                        if (typeof ($(this).attr('data-tab')) != 'undefined') {
                            $($(this).attr('data-tab')).click();
                        }
                        proceed = false;
                        return false;
                    }
                }
                else {
                    $(this).removeClass('error');
                }
            }
            // MIN LENGTH VALIDATION ENDS

            //NUMBER VALIDATION STARTS
            if (typeof ($(this).attr('data-field-type')) != 'undefined' && $(this).attr('data-field-type') == 'number') {
                if (typeof ($(this).attr('data-above')) != 'undefined' && typeof ($(this).attr('data-below')) != 'undefined') {
                    var From = parseInt($(this).attr('data-above'), 10);
                    var To = parseInt($(this).attr('data-below'), 10);
                    if ($(this).val() != "" && To > From) {
                        var value = parseInt($(this).val(), 10);
                        if (value > To || value < From) {
                            InitOnScreenNotification('<div class="">' + $(this).attr('data-range-msg') + '</div>', 'validationmsg', 1000000);
                            $(this).addClass('error');
                            if (typeof ($(this).attr('data-tab')) != 'undefined') {
                                $($(this).attr('data-tab')).click();
                            }
                            proceed = false;
                            return false;
                        }
                        else {
                            $(this).removeClass('error');
                        }
                    }
                }
            }
            //NUMBER VALIDATION ENDS

            // EMAIL VALIDATION STARTS
            if (typeof ($(this).attr('data-field-type')) != 'undefined' && $(this).attr('data-field-type') == 'email') {
                var valid = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/.test(this.value),
                    val = this.value;
                if (val != '') {
                    if (!valid) {
                        InitOnScreenNotification('<div class="">' + $(this).attr('data-email-msg') + '</div>', 'validationmsg', 1000000);
                        $(this).addClass('error');
                        if (typeof ($(this).attr('data-tab')) != 'undefined') {
                            $($(this).attr('data-tab')).click();
                        }
                        proceed = false;
                        return false;
                    }
                    else {
                        $(this).removeClass('error');
                    }
                }
            }
            // EMAIL VALIDATION ENDS

            // WEBSITE VALIDATION STARTS
            if (typeof ($(this).attr('data-field-type')) != 'undefined' && $(this).attr('data-field-type') == 'website' && typeof ($(this).attr('data-website-msg')) != 'undefined') {
                var valid = /^http([s]?)|ftp:\/\/.*/.test(this.value),
                    val = this.value;
                if (val != '') {
                    if (!valid) {
                        InitOnScreenNotification('<div class="">' + $(this).attr('data-website-msg') + '</div>', 'validationmsg', 1000000);
                        $(this).addClass('error');
                        if (typeof ($(this).attr('data-tab')) != 'undefined') {
                            $($(this).attr('data-tab')).click();
                        }
                        proceed = false;
                        return false;
                    }
                    else {
                        $(this).removeClass('error');
                    }
                }
            }
            // WEBSITE VALIDATION ENDS

        }
    });
    if (proceed == false) {
        return false;
    }
    else {
        return true;
    }
};

function fnValidateMultiValueControls(Controls) {
    $('.customfield-required-error').removeClass('customfield-required-error');
    var proceed = true;
    if (Controls == "") return true;
    var str_array = Controls.split(',');
    $.each(str_array, function (key, val) {
        var ControlID = $("#BodyContentPlaceHolder_" + val);
        if (val.match("^chk_")) {
            if (typeof (ControlID) != 'undefined') {
                if (typeof ($(ControlID).parent().attr('data-mvg-att-name')) != 'undefined') {
                    if ($(ControlID).prop('checked') == false) {
                        InitOnScreenNotification('<div class="">Specify ' + $(ControlID).parent().attr("data-mvg-att-name") + '.</div>', 'validationmsg', 1000000);
                        $(ControlID).addClass('error');
                        proceed = false;
                        return false;
                    }
                    else {
                        $(ControlID).removeClass('error');
                    }
                }
            }
        }
        else if (val.match("^rbl_")) {
            if (typeof (ControlID) != 'undefined') {
                if (typeof ($(ControlID).attr('data-mvg-att-name')) != 'undefined') {
                    if ($(ControlID).find("input:checked").length == 0) {
                        InitOnScreenNotification('<div class="">Specify ' + $(ControlID).attr("data-mvg-att-name") + '.</div>', 'validationmsg', 1000000);
                        $(ControlID).addClass('error');
                        proceed = false;
                        return false;
                    }
                    else {
                        $(ControlID).removeClass('error');
                    }
                    if ($(ControlID).find("input:checked").val() == "0") {
                        if ($($(ControlID).selector.replace("rbl", "txtOthers")).val() == "") {
                            InitOnScreenNotification('<div class="">Specify a value for Others option (' + $(ControlID).attr("data-mvg-att-name") + ').</div>', 'validationmsg', 1000000);
                            $(ControlID).addClass('error');
                            proceed = false;
                            return false;
                        }
                    }
                }
            }
        }            
        else if (val.match("^lst_")) {
                //Validate multivalue dropdown
                if (typeof (ControlID) != 'undefined') {
                    if (typeof ($('#' + val).attr('data-mvg-att-name')) != 'undefined') {
                        var id = ($('#' + val + " option:selected"));
                       var count = id.length;
                        if (count == 0) {
                            InitOnScreenNotification('<div class="">Specify ' + $('#' + val).attr("data-mvg-att-name") + '.</div>', 'validationmsg', 1000000);
                            $('#' + val).next(".btn-group").find(".multiselect").addClass('customfield-required-error');
                            proceed = false;
                            return false;
                        }
                    }
                    else {
                        $(ControlID).removeClass('error');
                    }
                }
        }            
        else if ($(ControlID).hasClass("multi-valued-attachment") && $(ControlID).hasClass("multi-valued-attachment-required")) {
            //validate File upload
            var AttachmentLink = $(ControlID).next('a');
            if (AttachmentLink != null && AttachmentLink != undefined) {
                var val = AttachmentLink.attr('href');
                if (val == 'undefined' || val == undefined) {
                    InitOnScreenNotification('<div class="">Specify ' + $(ControlID).attr("data-mvg-att-name") + '.</div>', 'validationmsg', 1000000);
                    $(ControlID).addClass('customfield-required-error');
                    proceed = false;
                    return false;
                }
            }
        }
        else {
            if (typeof (ControlID) != 'undefined') {
                if (typeof ($(ControlID).attr('data-mvg-att-name')) != 'undefined') {
                    if ($(ControlID).val() == "") {
                        InitOnScreenNotification('<div class="">Specify ' + $(ControlID).attr("data-mvg-att-name") + '.</div>', 'validationmsg', 1000000);
                        $(ControlID).addClass('error');
                        proceed = false;
                        return false;
                    }
                    else {
                        $(ControlID).removeClass('error');
                    }
                }
            }
        }
    });

    if (proceed == false) {
        return false;
    }
    else {
        return true;
    }
};

function fnInitializeOnlyNumbers() {
    $(document).on("keyup", '.onlynumbers', function (event) {
        if (event.keyCode == 46 || event.keyCode == 8) {
            // let it happen, don't do anything
        } else if (/\D/g.test(this.value)) {
            // Filter non-digits from input value.
            this.value = this.value.replace(/\D/g, '');
        }
    });
};

function fnInitTooltip() {
    $('[data-toggle="tooltip"]').tooltip();
};
function log() { console.log(arguments); }
String.prototype.toDateTime = function (o) {
    var v = this;
    if (v && v != '') { var bits = v.split(/\D/); var date = new Date(bits[0], --bits[1], bits[2], bits[3], bits[4], bits[5]); return date; }
}

//To Print grid View Data where div has scroll
function PrintGridDataHavingScrollRemoved(divID, Heading) {

    var w = 950;
    var h = 650;
    var left = (screen.width / 2) - (w / 2);
    var top = (screen.height / 2) - (h / 2);

    var disp_setting = "toolbar=no,location=no,directories=no,menubar=no,";
    disp_setting += "scrollbars=yes,width=" + w + ", height=" + h + ", left=" + left + ", top=" + top + ",status=no";

    var content = divID;
    var contentValue;

    if (content != null) {
        contentValue = content.innerHTML;
        contentValue = fnReplaceReg('<a', '<b', contentValue);
        contentValue = fnReplaceReg('overflow:', '', contentValue);
    }
    if (Heading == null)
        Heading = "Asset Details";

    var docprint = window.open("", "", disp_setting);
    var cssString = ".grid-pager{display:none !important;} .mstGV{border:solid 1px }";
    docprint.document.open();
    docprint.document.write('<html><head><title>' + Heading + '</title>');
    docprint.document.write('<style type="text/css">' + cssString + '</style>')
    docprint.document.write('</head><body><h3>' + Heading + '</h3></body><body onLoad="self.print()"><center>');
    docprint.document.write(contentValue);
    docprint.document.write('</center></body></html>');
    docprint.document.close();
    docprint.focus();
    //docprint.close();//to close back window automatically once print ok r cancel
    return false;
}

//For showing/hiding Export to excel options
var showHideExportExcelOptions = function () {
    $('.export-excel-icon').mouseenter(function () {
        $(".showExportOpt").show().animate({ "right": $(".action-container").width() - 2 }, "slow");
    });
    $('.export-excel-icon-img').mouseenter(function () {
        $(".showExportOpt").show().animate({ "right": $(".action-container").width() - 2 }, "slow");
    });
    $(".showExportOpt").click(function (e) {
        e.stopPropagation();
    });
    $('html').click(function () {
        $(".showExportOpt").hide(200);
    });
}

/*************************************************************************************
' TextBox validation - restrict to 2 decimal places on keypress
' Author: Gautam Bhat 
' Use: onkeypress="return validateFloatKeyPress(this,event);"
' Note: charCode 8 is backspace and to be allowed
*************************************************************************************/
function validateFloatKeyPress(el, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    var number = el.value.split('.');
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    //just one dot
    if (number.length > 1 && charCode == 46) {
        return false;
    }
    //get the carat position
    var caratPos = getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && (number[1].length > 1) && charCode != 8) {
        return false;
    }
    return true;
}
function getSelectionStart(o) {
    if (o.createTextRange) {
        var r = document.selection.createRange().duplicate()
        r.moveEnd('character', o.value.length)
        if (r.text == '') return o.value.length
        return o.value.lastIndexOf(r.text)
    } else return o.selectionStart
}

function getEditorContent(id) {
    var nicEditor = nicEditors.findEditor(id);
    var content = '';
    if (nicEditor != undefined && nicEditor != null) {
        content = nicEditor.getContent();
        if ($('#__trimmedContent').length == 0) {
            $('body').append('<pre id="__trimmedContent" style="display: none;"></pre>');
        }
        $('#__trimmedContent').html(content);
        content = $.trim($('#__trimmedContent').text());
    }
    return content;
}

/*************************************************************************************
' Function to get client id of control in external JS file
' Author: Rakesh Sajja
' Use: fnGetClientID('YOUR_ID_HERE');
*************************************************************************************/
function fnGetClientID(controlID) {
    if (controlID == '') return;
    return $("[id$=" + controlID + "]").attr("id");
};

/**To Get Browser Information ** Usage -  var browser = get_browser_info(); browser.name = 'Chrome';browser.version = '40'**/

function get_browser_info() {
    var ua = navigator.userAgent, tem, M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
    if (/trident/i.test(M[1])) {
        tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
        return { name: 'IE ', version: (tem[1] || '') };
    }
    if (M[1] === 'Chrome') {
        tem = ua.match(/\bOPR\/(\d+)/)
        if (tem != null) { return { name: 'Opera', version: tem[1] }; }
    }
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
    if ((tem = ua.match(/version\/(\d+)/i)) != null) { M.splice(1, 1, tem[1]); }
    return {
        name: M[0],
        version: M[1]
    };
}

/**For Scroll Tabs For Relations Tab**/
var initializeScrollTabs = function () {
    if ($(".slider-slide-wrap:not(.ng-hide)").length > 4) {
        $('.silder-btns').show();
    }
    var n = $(".slider-slide-wrap:not(.ng-hide)").length,
      width = 150,
      newwidth = width * n;

    $('.slide-wrap').css({
        'width': newwidth
    });

    $(".slider-slide-wrap:not(.ng-hide)").each(function (i) {
        if (i === 0) { $(this).addClass('shown'); }
        var thiswid = 150;
        $(this).css({
            'left': thiswid * i
        });

    });
    /*on scroll move the indicator 'shown' class to the
    most visible slide on viewport
    */
    $('.slider-wrap:not(.ng-hide)').scroll(function () {
        var scrollLeft = $(this).scrollLeft();
        $(".slider-slide-wrap:not(.ng-hide)").each(function (i) {
            var posLeft = $(this).position().left
            var w = $(this).width();
            if (scrollLeft >= posLeft && scrollLeft < posLeft + w) {
                $(this).addClass('shown').siblings().removeClass('shown');
            }
        });
    });
    //commented by Sudarsan// Old Code
    /* on left button click scroll to the previous sibling of the current visible slide */
    //$('#slider-left').click(function () {
    //    var $prev = $('.slide-wrap .shown').prev();
    //    $prev.addClass('shown').siblings().removeClass('shown');
    //    if ($prev.length) {
    //        $('.slider-wrap').animate({
    //            scrollLeft: $prev.position().left
    //        }, 'fast');
    //    }
    //});
    /* on right button click scroll to the next sibling of the current visible slide */
    //$('#slider-right').click(function () {
    //    var $next = $('.slide-wrap .shown').next();
    //    $next.addClass('shown').siblings().removeClass('shown');
    //    if ($next.length) {
    //        $('.slider-wrap').animate({
    //            scrollLeft: ($next.position().left == 0) ? 160 : $next.position().left
    //        }, 'fast');
    //    }
    //});

    //Added by Sudarsan on 1/22/2016 for bug 16848 //New Code
    /* on left button click scroll to the previous sibling of the current visible slide */
    $('#slider-left').click(function () {
        var el = $('.slider-wrap');
        var childEmmWidth = $(".slider-slide-wrap").outerWidth();
        var scrLeft = el.scrollLeft();
        if (scrLeft) {
            var scrToLeft = scrLeft % childEmmWidth;
            el.animate({
                scrollLeft: (scrToLeft ? scrLeft - scrToLeft : scrLeft - childEmmWidth)
            }, 200);
        }
    });
    /* on right button click scroll to the next sibling of the current visible slide */
    $('#slider-right').click(function () {
        var el = $('.slider-wrap');
        var childEmmWidth = $(".slider-slide-wrap").outerWidth();
        var scrLeft = el.scrollLeft();
        el.animate({
            scrollLeft: scrLeft + childEmmWidth
        }, 200);
    });
    //modified by Sudarsan on 1/22/2016//Ends here 

}


/*************************************************************************************
' Function to compare/check whether first date is greater than second date. Using moment.js plugin. http://momentjs.com/
' Author: Gautam Bhat
' Use: sDateCompare(txtScheduleDate.val(),lblLogTime.text());
' Returns: Bool
*************************************************************************************/
function sDateCompare(firstDate, secondDate) {
    var flag = false;
    var inputDateFormat = ['YYYY-MM-DD hh:mm:ss A', 'YYYY-MM-DD HH:mm:ss'];

    var firstDate = moment(firstDate, inputDateFormat);
    var secondDate = moment(secondDate, inputDateFormat);

    if (firstDate > secondDate)
        flag = true;

    return flag;
}

/*************************************************************************************
' Function to get date difference in days Using moment.js plugin. http://momentjs.com/
' Use: sDateDifference(txtFromDate.text,txtToDate.text());
' Returns: Bool
*************************************************************************************/
function sDateDifference(firstDate, secondDate, period) {
    var diff;
    var inputDateFormat = ['YYYY-MM-DD hh:mm:ss A', 'YYYY-MM-DD HH:mm:ss'];

    if (period = '')
        period = 'days'

    var firstDate = moment(firstDate, inputDateFormat);
    var secondDate = moment(secondDate, inputDateFormat);
    var duration = moment.duration(secondDate.diff(firstDate));
    if (period = 'days')
        diff = duration.asDays();
    return diff;
}

function fnSetCurrentTab(divid) {
    try {
        $('#' + divid + ' a').each(function (index) {
            var _thisid = $(this)[0].id;
            $(this).click(function () { fnSetCurrentDetailTab(_thisid) })
        })
        if (typeof top._AVMTabDetail != 'undefined' && typeof top._AVMTabDetail.tabId != 'undefined' && top._AVMTabDetail.tabId.length > 0 && !top._AVMTabDetail.isLoaded) {
            top._AVMTabDetail.isLoaded = true
            var tab = top._AVMTabDetail.tabId;
            $('#' + tab).click();
        }



    } catch (e) { console.log(e) }
}
function tryDecodeURIComponent(uri) {
    try {
        decodeURIComponent(uri);
    }
    catch (ex) {
        return uri;
    }

    return decodeURIComponent(uri);
}
var checkNum = function (evt) {
    var carCode = (evt.which) ? evt.which : event.keyCode
    if (carCode > 31 && (carCode < 48) || (carCode > 57)) {
        return false;
    }
}
//restrict the user enter only numeric values.
var specialKeys = new Array();
specialKeys.push(8); //Backspace
$(function () {
    $(".onlynumeric").bind("keypress", function (e) {
        var keyCode = e.which ? e.which : e.keyCode
        var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
        //if (ret == false)
        //    InitOnScreenNotification('<div class="">Enter only numeric</div>', 'validationmsg');
        return ret;
    });
    $(".onlynumeric").bind("blur", function (e) {
        var v = $(this).val();
        if (v != '') $(this).val(v.replace(/[^0-9\.]/g, ''));
    });
});

function fnSetCurrentTab(divid) {
    try {
        $('#' + divid + ' a').each(function (index) {
            var _thisid = $(this)[0].id;
            $(this).click(function () { fnSetCurrentDetailTab(_thisid) })
        })
        if (typeof top._AVMTabDetail != 'undefined' && typeof top._AVMTabDetail.tabId != 'undefined' && top._AVMTabDetail.tabId.length > 0 && !top._AVMTabDetail.isLoaded) {
            top._AVMTabDetail.isLoaded = true
            var tab = top._AVMTabDetail.tabId;
            $('#' + tab).click();
        }

    } catch (e) { console.log(e) }
}

function fnSetCurrentDetailTab(id) {
    top._AVMTabDetail = { tabId: id, isLoaded: false }
}
var alphanumeric = /^[\w\d]*$/;
var domainuser = /^([^\<\>\&'\\\s])+\\([^\<\>\&'\\\s])+$/;
var commonregex = /^[^\<\>\&']+$/;
var zip = /^[0-9-]+$/;
var email = /^([^\<\>\&'@\s\n])+@(([^\<\>\&'@\s\n])+\.)+([^\<\>\&'@,;]{2,4})+$/i;
var contactnumber = /^[0-9-+() ]+$/;
var amount = /^\d+(\.\d{0,3})?$/;
var formula = /^[a-zA-Z0-9()%=*<>/.+\-\s]+$/;
var number = /^[0-9]+$/;
var date = /^[0-9:\-\s]+$/;
var alphabet = /^[a-zA-Z\s]+$/;
var countrycode = /^[0-9()+._\-\s]+$/;
var url = /^(http|https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/;
var decimal = /(^-?\d\d*\.\d*$)|(^-?\d\d*$)|(^-?\.\d\d*$)/;
var istextexists = /^([a-zA-Z0-9_\.\-~!@#$%^&*()_+{}:><?])/;
var minmaxvalue = /^\d+$/;
var LocalHostUrl = /^(http|https|ftp):\/\/\w+(\.\w+)*(:[0-9]+)?\/?(\/[.\w]*)*$/;
var ipAddress = /^(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))$/;
var withOutSingleQuote = /^[^\<\>\&]+$/;

function JValidateRegexForLocalization(elID, value, element, type) {
    if (!type) {
        return elID.optional(element) || commonregex.test(value);
    }
        //added new
    else if (type && type.toLowerCase() == "withoutsinglequote") {
        return elID.optional(element) || withOutSingleQuote.test(value);
    }
    else if (type && type.toLowerCase() == "zip") {
        return elID.optional(element) || zip.test(value);
    }
    else if (type && type.toLowerCase() == "email") {
        return elID.optional(element) || (email.test(value));
    }
    else if (type && type.toLowerCase() == "contactnumber") {
        var split = value.split(',');
        var Count = 0;
        var result = true;
        for (var i = 0; i < split.length; i++) { if ((split[i].length > 0 && contactnumber.test(split[i]))) { } else { Count = Count + 1; } }
        if (Count > 0) { return false; } else { return true; }
    }
    else if (type && type.toLowerCase() == "amount") {
        return elID.optional(element) || (amount.test(value));
    }
    else if (type && type.toLowerCase() == "formula") {
        return elID.optional(element) || (formula.test(value));
    }
    else if (type && type.toLowerCase() == "numbers") {
        return elID.optional(element) || (number.test(value));
    }
    else if (type && type.toLowerCase() == "date") {
        return elID.optional(element) || (date.test(value));
    }
    else if (type && type.toLowerCase() == "alphabet") {
        return elID.optional(element) || alphabet.test(value);
    }
    else if (type && type.toLowerCase() == "url") {
        return elID.optional(element) || (url.test(value));
    }
    else if (type && type.toLowerCase() == "countrycode") {
        return elID.optional(element) || (countrycode.test(value));
    }
    else if (type && type.toLowerCase() == "multiemailvalidationsemicolon") {
        var Emails = value.split(';');
        var Count = 0;
        for (var i = 0; i < Emails.length; i++) { if ((Emails[i].length > 0 && email.test(Emails[i]))) { } else { Count = Count + 1; } }
        if (Count > 0) { return false; } else { return true; }
    }
    else if (type && type.toLowerCase() == "multiemailvalidationcomma") {
        var Emails = value.split(',');
        var Count = 0;
        for (var i = 0; i < Emails.length; i++) { if ((Emails[i].length > 0 && email.test(Emails[i]))) { } else { Count = Count + 1; } }
        if (Count > 0) { return false; } else { return true; }
    }
    else if (type && type.toLowerCase() == "multiemailvalidationsommasemicolon") {
        var Emails = value.split(/[;,]+/);
        var Count = 0;
        for (var i = 0; i < Emails.length; i++) { if ((Emails[i].length > 0 && email.test(Emails[i]))) { } else { Count = Count + 1; } }
        if (Count > 0) { return false; } else { return true; }
    }
    else if (type && type.toLowerCase() == "localhosturl") {
        return elID.optional(element) || (LocalHostUrl.test(value));
    }
    else if (type && type.toLowerCase() == "ipaddress") {
        return elID.optional(element) || (ipAddress.test(value));
    }
}

function ValidateRegexForLocalization(elID, value, type) {

    if (!type) {
        return commonregex.test(value);
    }
    else if (type && type.toLowerCase() == "domainuser") {
        return (domainuser.test(value));
    }
    else if (type && type.toLowerCase() == "alphanumeric")
        return (alphanumeric.test(value));
    else if (type && type.toLowerCase() == "email") {
        return (email.test(value));
    }
    else if (type && type.toLowerCase() == "contactnumber") {
        return (contactnumber.test(value));
    }
    else if (type && type.toLowerCase() == "zip") {
        return (zip.test(value));
    }
    else if (type && type.toLowerCase() == "decimal") {
        return (decimal.test(value));
    }
    else if (type && type.toLowerCase() == "alphabet") {
        return alphabet.test(value);
    }
    else if (type && type.toLowerCase() == "numbers") {
        return (number.test(value));
    }
    else if (type && type.toLowerCase() == "istextexists") {
        return istextexists.test(value);
    }
    else if (type && type.toLowerCase() == "validateinteger") {
        return zip.test(value);
    }
    else if (type && type.toLowerCase() == "minmaxvalue") {
        return minmaxvalue.test(value);
    }
    else if (type && type.toLowerCase() == "multiemailvalidationsemicolon") {
        var Emails = value.split(';');
        var Count = 0;
        for (var i = 0; i < Emails.length; i++) { if ((Emails[i].length > 0 && email.test(Emails[i]))) { } else { Count = Count + 1; } }
        if (Count > 0) { return false; } else { return true; }
    }
    else if (type && type.toLowerCase() == "multiemailvalidationcomma") {
        var Emails = value.split(',');
        var Count = 0;
        for (var i = 0; i < Emails.length; i++) { if ((Emails[i].length > 0 && email.test(Emails[i]))) { } else { Count = Count + 1; } }
        if (Count > 0) { return false; } else { return true; }
    }
    else if (type && type.toLowerCase() == "multiemailvalidationsommasemicolon") {
        var Emails = value.split(/[;,]+/);
        var Count = 0;
        for (var i = 0; i < Emails.length; i++) { if ((Emails[i].length > 0 && email.test(Emails[i]))) { } else { Count = Count + 1; } }
        if (Count > 0) { return false; } else { return true; }
    }

}

function fnInitPriceValidation() {
    $(document).on("keyup", '.price', function (event) {
        var value = $(this).val();
        var valid = /^\d{0,9}(\.\d{0,2})?$/.test(value);

        if (!valid) {
            $(this).val(value.substring(0, value.length - 1));
        }
    });
};

//show hide page blocker method
function ShowProcessing() {
    $("#pageblocker").show();
    if ($('#divShowProcess') != null && $('#divShowProcess') != 'undefined') { $('#divShowProcess').show(); }
}

function HideProcessing() {
    $("#pageblocker").hide();
    if ($('#divShowProcess') != null && $('#divShowProcess') != 'undefined') { $('#divShowProcess').hide(); }
}

/*************************************************************************************
' Function to upload file from HTTP handler using jQuery (works in IE-10+)
' Author: Rakesh Sajja
' Use: refer this page - /MDLAdmin/Summit_CustomTabs.aspx
*************************************************************************************/
function uploadFile(file, args, callBack, isAsync) {
    if (file == null || typeof file == 'undefined') {
        return;
    }
    var files = file;
    var formData = new FormData();
    formData.append(file.name, file);
    $.ajax({
        url: "../UploadHandler.ashx?args=" + JSON.stringify(args) + "",
        type: "POST",
        contentType: false,
        processData: false,
        data: formData,
        async: isAsync,
        // dataType: "json",
        success: function (result) {
            if (callBack) { callBack(result); }
        },
        error: function (err) {
            console.log(err.statusText);
        }
    });
};
function deletefile(args, isAsync) {

    $.ajax({
        url: "../UploadHandler.ashx?args=" + JSON.stringify(args) + "",
        type: "POST",
        contentType: false,
        processData: false,
        data: '',
        async: isAsync,
        // dataType: "json",
        success: function (result) {
            // if (callback) { callback(result); }
        },
        error: function (err) {
            console.log(err.statusText);
        }
    });
};
var hdnFieldForCustomCheckList = '';
function fnUpdateCheckBoxListValueToHiddenObject(ID, isChecked) {
    if (hdnFieldForCustomCheckList == '') {
        return;
    }
    var json = $.parseJSON($(hdnFieldForCustomCheckList).val());

    for (i = 0; i < json.length; i++) {
        if (json[i].ID == ID) {
            json[i].Checked = isChecked;
        }
    }

    $(hdnFieldForCustomCheckList).val(JSON.stringify(json));
};

function fnInitCheckList() {
    $('.list-group.checked-list-box .list-group-item').each(function () {

        // Settings
        var $widget = $(this),
            $checkbox = $('<input type="checkbox" class="hidden" />'),
            color = ($widget.data('color') ? $widget.data('color') : "primary"),
            style = ($widget.data('style') == "button" ? "btn-" : "list-group-item-"),
            settings = {
                on: {
                    icon: 'fa fa-check-square-o'
                },
                off: {
                    icon: 'fa fa-square-o'
                }
            };

        $widget.css('cursor', 'pointer')
        $widget.append($checkbox);

        // Event Handlers
        $widget.on('click', function () {
            $checkbox.prop('checked', !$checkbox.is(':checked'));
            $checkbox.triggerHandler('change');
            updateDisplay();
        });
        $checkbox.on('change', function () {
            updateDisplay();
        });


        // Actions
        function updateDisplay() {
            var isChecked = $checkbox.is(':checked');

            // Set the button's state
            $widget.data('state', (isChecked) ? "on" : "off");

            // Set the button's icon
            $widget.find('.state-icon')
                .removeClass()
                .addClass('state-icon ' + settings[$widget.data('state')].icon);

            // Update the button's color
            if (isChecked) {
                $widget.addClass(style + color + ' checked');
            } else {
                $widget.removeClass(style + color + ' checked');
            }

            fnUpdateCheckBoxListValueToHiddenObject('#' + $widget.attr('id'), isChecked);
        }

        // Initialization
        function init() {

            if ($widget.data('checked') == true) {
                $checkbox.prop('checked', !$checkbox.is(':checked'));
            }

            updateDisplay();

            // Inject the icon if applicable
            if ($widget.find('.state-icon').length == 0) {
                $widget.prepend('<span class="state-icon ' + settings[$widget.data('state')].icon + '"></span>');
            }
        }
        init();
    });
};

function fnGetCheckListCheckedData(id) {
    var checkedItems = [], counter = 0;
    $("#" + id + " li.checked").each(function (idx, li) {
        var obj = { id: $(li).attr('id'), text: $(li).text() };
        checkedItems[counter] = obj;
        counter++;
    });
    return checkedItems;
};

function fnBindCheckList(valuesString) {
    if (typeof valuesString == 'undefined' || valuesString == '' || valuesString == '[]') {
        return;
    }

    var json = $.parseJSON(valuesString);
    $.each(json, function (key, value) {
        if (value.ID != null && typeof value.ID != 'undefined') {
            if (value.Checked) {
                $(value.ID).attr('data-checked', 'true');
            }
            else {
                $(value.ID).attr('data-checked', 'false');
            }

        }
    });
    fnInitCheckList();
};

var hdnCustomTreeListsControlID = '';
function fnUpdateTreeListValueToHiddenObject(TreeID, ID, isChecked, children) {
    if (hdnCustomTreeListsControlID == '') {
        return;
    }
    var json = $.parseJSON($(hdnCustomTreeListsControlID).val());
    $.each(json, function (key, value) {
        if (value.TreeID == TreeID) {
            var data = value.Data;
            for (i = 0; i < data.length; i++) {
                if (data[i].id == ID) {
                    data[i].checked = isChecked;
                    // updating children
                    for (j = 0; j < children.length; j++) {
                        $.each(json, function (key_child, value_child) {
                            if (value_child.TreeID == TreeID) {
                                var data_child = value_child.Data;
                                for (k = 0; k < data_child.length; k++) {
                                    if (data_child[k].id == children[j]) {
                                        data_child[k].checked = isChecked;
                                    }
                                }
                            }
                        });
                    }
                }
            }
        }
    });


    $(hdnCustomTreeListsControlID).val(JSON.stringify(json));
};

function fnCreateTreeControls(valuesString) {
    if (typeof valuesString == 'undefined' || valuesString == '' || valuesString == '[]') {
        return;
    }

    var json = $.parseJSON(valuesString);
    $.each(json, function (key, value) {
        $(value.TreeID).jstree({
            "core": {
                "animation": 0,
                "check_callback": true,
                "themes": { "stripes": false, "icons": false },
                'data': value.Data,
                "error": function (err) {
                },
            },
            "types": {
                "#": {
                    "max_children": 1,
                    "max_depth": 4,
                    "valid_children": ["root"]
                },
                "root": {
                    // "icons" : false,
                    "valid_children": ["default"]
                },
                "default": {
                    "valid_children": ["default", "file"]
                }
            },
            "plugins": ["checkbox", "search"]
        })
        .bind('ready.jstree', function (e, data) {
            $(value.TreeID).jstree(true).open_all();
            $(value.Data).each(function (key, val) {
                //var node = $(value.ID).jstree(true).get_node(val.id);
                if (val.checked) {

                    $(value.TreeID).jstree('check_node', val.id);
                }
                //if (node.children.length > 0) { }
                //else
                //{

                //}
            });
            $(value.TreeID).jstree(true).close_all();
        })
        .bind("changed.jstree", function (e, data) {
            fnUpdateTreeListValueToHiddenObject('#' + e.target.id, data.node.id, data.node.state.selected, data.node.children_d);
        })
        //.bind("open_node.jstree", function (e, data) {
        //    data.instance.toggle_node(data.node);
        //})

    });
};

/**Functions used to show tooltip on hover of mouse**/
function showtext(current, e, message) {
    message = message.ReplaceAll("%27", "'");
    if (document.layers) {
        theString = "<DIV CLASS='ttip'>" + decode(message) + "</DIV>";
        document.tooltip.document.write(theString); document.tooltip.document.close();
        document.tooltip.left = e.pageX + 1 + 'px'; document.tooltip.top = e.pageY + 0 + 'px';
        document.tooltip.visibility = "show";
    }
    else {
        if (document.getElementById) {
            elm = document.getElementById("tooltip");
            elml = current;
            elm.innerHTML = decode(message);
            elm.style.height = elml.style.height;
            elm.style.top = parseInt(yMousePos + elml.offsetHeight) + 'px';
            elm.style.left = parseInt(xMousePos + elml.offsetWidth + 10) + 'px'; elm.style.visibility = "visible";
        }
    }
}

function hidetip() { if (document.layers) { document.tooltip.visibility = "hidden"; } else { if (document.getElementById) { elm.style.visibility = "hidden"; } } }
String.prototype.ReplaceAll = function (stringToFind, stringToReplace) { var temp = this; var index = temp.indexOf(stringToFind); while (index != -1) { temp = temp.replace(stringToFind, stringToReplace); index = temp.indexOf(stringToFind); } return temp; }
function decode(encoded) { return tryDecodeURIComponent(encoded.replace(/\+/g, " ")); }
document.onmousemove = function (e) { if (typeof (e) == "undefined" && typeof (window.event) != "undefined") e = window.event; if (e.pageX || e.pageY) { xMousePos = e.pageX; yMousePos = e.pageY; } else if (e.clientX || e.clientY) { xMousePos = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft; yMousePos = e.clientY + document.body.scrollTop + document.documentElement.scrollTop; } };
/**End**/

String.format = function () {
    var theString = arguments[0];
    for (var i = 1; i < arguments.length; i++) {
        var regEx = new RegExp("\\{" + (i - 1) + "\\}", "gm");
        theString = theString.replace(regEx, arguments[i]);
    }
    return theString;
}

/* Start setNiceScrollandSync for GridView */
function setNiceScrollandSync(gridClientID, padding) {

    var rowCount = $('#' + gridClientID + '> tbody > tr').length;
    if (rowCount > 0) {
        var totalWindowWidth = $(window).width();
        var singleColWidth = totalWindowWidth / 12;
        var totalPadding = 0;
        if (padding) totalPadding = padding;
        //Added 65px for left navigation need to calculate dynamically this width
        
        var divMenuWidth = 0;
        if ($("#divMenu").length) { divMenuWidth = $(".compact_nav > ul").width() + 5; }
        console.log(divMenuWidth);
        var totalDivWidth = (singleColWidth * 11) - divMenuWidth + totalPadding;
        $('.gv_scroll_container').css("width", totalDivWidth + "px");
        $('.gv_scroll_container').height($('#' + gridClientID).height() + 9);
        $('.dvTopScroll').css("width", totalDivWidth + "px");        
        $('.dvTopScrollWidth').width($('#' + gridClientID).width());
        $('.dvTopScroll').css('overflow-x', 'scroll');

        $(".dvTopScroll").scroll(function () {
            $(".dvGridScroll")
                .scrollLeft($(".dvTopScroll").scrollLeft());
        });
        $(".dvGridScroll").scroll(function () {
            $(".dvTopScroll")
                .scrollLeft($(".dvGridScroll").scrollLeft());
        });
    }
    $(".dvTopScroll,.dvGridScroll").niceScroll({ zindex: 99, autohidemode: false });
    //$(".dvTopScroll,.dvGridScroll").mCustomScrollbar({
    //    theme: "inset-dark", autoExpandScrollbar: true, mouseWheel: { scrollAmount: 700 }
    //});
}
var setScroll = function (i) {
    if ($(i).length > 0)
        // $(i).niceScroll().updateScrollBar();
        $(i).mCustomScrollbar({
            theme: "inset-dark", autoExpandScrollbar: true, mouseWheel: { scrollAmount: 700 }
        });
}

/* End setNiceScrollandSync for GridView */


/*************************************************************************************
' Function to hide controls by default based on configuration in formbuilder
' Author: Rakesh Sajja
*************************************************************************************/
function fnHideCustomControls() {
    $('.control-default-hide').parent().hide();
    $('.label-default-hide').hide();

    // hiding group if none of the controls are visible in group
    //$.each($('.group-heading'), function (key, value) {
    //    var defaultHideLabelCount = 0, controlLabelCount = -1;
    //    if (typeof ($(this).children('.custom-form-group').find('.label-default-hide')) != 'undefined' && $(this).children('.custom-form-group').find('.label-default-hide').length > 0) {
    //        defaultHideLabelCount = $(this).children('.custom-form-group').find('.label-default-hide').length;
    //    }
    //    if (typeof ($(this).children('.custom-form-group').find('.control-label')) != 'undefined' && $(this).children('.custom-form-group').find('.control-label').length > 0) {
    //        controlLabelCount = $(this).children('.custom-form-group').find('.control-label').length;
    //    }

    //    if (defaultHideLabelCount > 0 && controlLabelCount > 0 && defaultHideLabelCount == controlLabelCount) {
    //        $(this).hide();
    //    }
    //});
};
//Method for adding delay to callback while typing - used for autocomplete
var TypeDelay = (function () {
    var timer = 0;
    return function (callback, ms) {
        clearTimeout(timer);
        timer = setTimeout(callback, ms);
    };
})();

//File upload validation
var blackListedExtensionsString = '.php,.php2,.php3,.php4,.php5,.phtml,.pwml,.inc,.asp,.aspx,.ascx,.jsp,.cfm,.cfc,.pl,.com,.dll,.js,.reg,.cgi,.htaccess,.asis,.sh,.shtml,.shtm,.phtm'.toUpperCase();
$(document).ready(function () {
    var blackListedExtensions = blackListedExtensionsString.split(',');
    if (typeof maxFileUploadSize !== 'undefined') {
        $('.bootstrap-filestyle input').attr("placeholder", "Max Upload File Size " + maxFileUploadSize + "MB");
        $('input[type="file"]:not(.inputfile-pm)').on('change', function () {
            ValidateFile(this.files, this);
        });
    }

    var ValidateFile = function (files, el) {

        $.noty.closeAll();
        if (files && files.length > 0) {
            if (!validateExtensions(files)) {
                $(el).filestyle('clear');
                var to = setTimeout(function () {
                    notyid = noty({
                        text: "Invalid file type", timeout: 500000, type: 'error', maxVisible: 1
                    });
                    clearTimeout(to);
                }, 800);
                return;
            }

            if (!ValidateSize(files)) {
                $(el).filestyle('clear');
                if (browser != undefined && browser.name == "MSIE" && parseInt(browser.version, 10) <= 10) {
                    $fileInput = $(el);
                    $fileInput.replaceWith($fileInput = $fileInput.clone(true));
                }
                var to = setTimeout(function () {
                    notyid = noty({
                        text: "The file size should not be more than " + maxFileUploadSize + "MB.", timeout: 500000, type: 'error', maxVisible: 1
                    });
                    clearTimeout(to);
                }, 800);
                return;
            }
        }
    };

    var ValidateSize = function (files) {
        var totalSize = 0;
        if (files && files.length > 0) {
            for (var i = 0; i < files.length; i++) {
                totalSize += getFileLength(files[i])
            }
        }
        return (maxFileUploadSize * 1024 * 1024) >= totalSize;
    };

    var validateExtensions = function (files) {
        for (var i = 0; i < files.length; i++) {
            var fExt = (getFileExtension(files[i])).toUpperCase();
            for (var j = 0; j < blackListedExtensions.length; j++) {
                if (fExt == blackListedExtensions[j])
                    return false;
            }
        }
        return true;
    };

    var getFileLength = function (file) {
        return file ? file.size : 0;
    };

    var getFileExtension = function (file) {
        return file ? file.name.substr(file.name.lastIndexOf('.')) : '';
    };

});

function fnValidateUniqueValues(Module, TicketID, callback) {
    var Result = false;
    if ($('.unique').length == 0) {
        Result = true;
        if (typeof (callback) == 'function') callback(Result);
    }
    else {
        blockUI();
        var lstData = [];
        $.each($('.unique'), function (key, value) {
            var AttributeID = $(value).attr('data-attr-id');
            var AttributeValue = $(value).val();

            lstData.push({ AttributeID: AttributeID, AttributeValue: AttributeValue });
        });

        var Data = { "args": JSON.stringify({ Module: Module, TicketID: TicketID, AttributeList: lstData }) };
        $.ajax({
            url: "../WS/Admin/FormBuilder.asmx/ValidateUniqueValues",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify(Data),
            success: function (result) {
                if (result.d != null && typeof (result.d) != 'undefined' && result.d != '') {
                    var data = $.parseJSON(result.d);
                    if (data.length > 0) {
                        var AttributeName = data[0].AttributeName;
                        var AttributeID = data[0].AttributeID;
                        InitOnScreenNotification('<div class="">Value already exist for ' + AttributeName + '</div>', 'validationmsg', 1000000);
                        $('[data-attr-id=' + AttributeID + ']').addClass('error');
                        $('html, body').animate({ scrollTop: $('[data-attr-id=' + AttributeID + ']').offset().top - 150 }, 900);
                        Result = false;
                    }
                    else {
                        Result = true;
                        if (typeof (callback) == 'function') callback(Result);
                    }
                }
                else {
                    Result = true;
                    if (typeof (callback) == 'function') callback(Result);
                }
                unblockUI();
                if (typeof (callback) == 'function') callback(Result);
            },
            error: function (err) {
                console.log(err);
                unblockUI();
                if (typeof (callback) == 'function') callback(true);
            }
        });


    }
    return Result;
};

function onPasteTriggered(e) {
    var focused = document.activeElement;
    //console.log(focused.className);
    if (typeof e.clipboardData != 'undefined') {
        var copiedData = e.clipboardData.items[0]; //Get the clipboard data
        /*If the clipboard data is of type image, read the data*/
        if (copiedData.type.indexOf("image") == 0) {
            var imageFile = copiedData.getAsFile();
            /*We will use HTML5 FileReader API to read the image file*/
            var reader = new FileReader();

            reader.onload = function (evt) {
                var result = evt.target.result; //base64 encoded image
                /*Create an image element and append it to the content editable div*/
                var img = document.createElement("img");
                img.src = result;
                // document.getElementById("editablediv").appendChild(img);
                // $(".nicEdit-main").append(img);

                // insert the image
                var range = window.getSelection().getRangeAt(0);
                range.insertNode(img);
                range.collapse(false);

                // set the selection to after the image
                var selection = window.getSelection();
                selection.removeAllRanges();
                selection.addRange(range);
            };
            /*Read the image file*/
            reader.readAsDataURL(imageFile);
        }
    }
}