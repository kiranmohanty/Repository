﻿/*
    Created By : Rakesh Sajja
    Date : 03-09-2015
    Description : creating angular directives
*/

angularApp.directive("fileModel", ["$parse",
function ($parse) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            element.bind("change", function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

angularApp.directive('getFileInfo', function () {
    return {
        scope: { fileInfoCallBack: '&fileinfocallbackFn' },
        link: function (scope, elem, attr, ctrl) {
            $(elem).bind('change', function () {
                if (typeof this.files[0] != 'undefined') {
                    scope.fileInfoCallBack({ fileInfo: { fileName: this.files[0].name, fileExtension: this.files[0].name.split(".").pop(), fileSize: this.files[0].size, } });
                }
            });
        }
    }
});

angularApp.directive('onFinishRepeat', ["$timeout", function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit(attr.finishrepeatcallback ? attr.finishrepeatcallback : 'ngRepeatFinished');
                });
            }
        }
    }
}]);