﻿///angularjs initializers
var angularApp = angular.module('angularApp', ['angular-loading-bar', 'cfp.loadingBar', 'ngAnimate', 'angular.filter'])
.config(['cfpLoadingBarProvider', '$httpProvider', function (cfpLoadingBarProvider, $httpProvider) {
    // enable http caching
    //$httpProvider.defaults.cache = true;

    cfpLoadingBarProvider.includeSpinner = false;
    cfpLoadingBarProvider.includeBar = true;
}]);
angularApp.filter('unsafe', ['$sce', function ($sce) {
    return function (val) {
        return $sce.trustAsHtml(val);
    };
}]).filter('placeholdEmpty', function() {
    return function (input) {
        if (!(input == undefined || input == null || input == '' || ($.inArray(input, EmptyPlaceholderForInputs) !=-1))) { return input;
} else {return "-"; }}
});
var UserSelectionPopupControllerScope = function () {
    return angular.element('[ng-controller=UserSelectionPopupController]').scope();
}

angularApp.controller('UserSelectionPopupController', ['$scope', 'cfpLoadingBar', 'GeneralConfigService', '$timeout', function ($scope, cfpLoadingBar, GeneralConfigService, $timeout) {
    var genConfigService;    
    $scope.init = function (parameters) {               
        $scope.params = parameters;
        genConfigService = GeneralConfigService.getInstance($scope.params);
        genConfigService.Init($scope.params);
    };
    $scope.Users = [];
    var filterTextTimeout;
    $scope.$watch('searchText', function (val) {       
        if (filterTextTimeout) $timeout.cancel(filterTextTimeout);
        filterTextTimeout = $timeout(function () {
            if (val != undefined && val != '') {              
                var values = $scope.params;                
                values.SearchText = val;
                if ($("#includeInactivePop").is(":checked")) {
                    values.IncludeInActive = 1;
                }
                else { values.IncludeInActive = 0; }
                genConfigService.GetUsers(values,true).then(function (d) {
                    $scope.Users = d.data;
                });
            } else $scope.Users = [];
        }, 450);
    });
    $scope.RegisterAutoSearchForLocation = function (ctrl, callback, options) {
        var autoSearchService = GeneralConfigService.getInstance($scope.params);
        autoSearchService.AutoSearchLocation(ctrl, callback, options);
    }
}]);

angularApp.controller('RelationshipController', ['$scope', 'cfpLoadingBar', 'RelationshipService', '$timeout', 'filterFilter','SummaryService', function ($scope, cfpLoadingBar, RelationshipService, $timeout, filterData,SummaryService) {
    var relService;
    var sumService;
    $scope.EprocUrl = '';
    $scope.Configurations;
    $scope.init = function (parameters) {
        $scope.params = parameters;
        relService = RelationshipService.getInstance($scope.params);
        relService.Init($scope.params);
        if ($scope.params.instance == '') {
            console.log('Instance not specified - Linking disabled');
            $scope.DisableLinking = true;
            $scope.DisableCreate = true;
        }
        sumService = SummaryService.getInstance({});
    };
    $scope.applyCss = function (mod) {
        return mod.replace(' ','_');
    }
    $scope.excludeModules = function(s,m){
        if (m && m.length > 0) {            
            var b = [];
            $.each(s, function (i,item) {
                if ($.inArray(item.Value, m)==-1)
                    b.push(item);
            });
            s = b;
        }
        return s;
    }
    $scope.includeModules = function (s, m) {
        if (m && m.length > 0) {
            var b = [];
            $.each(s, function (i, item) {
                if ($.inArray(item.Value, m) >= 0)
                {
                    b.push(item);
                }
            });
            s = b;
        }
        return s;
    }
    $scope.LinkageModulesConfig = [{ Text: 'Incident', Value: 'IM' }, { Text: 'Change', Value: 'CM' }, { Text: 'Problem', Value: 'PM' }, { Text: 'Work Order', Value: 'WO' }, { Text: 'Configuration Item', Value: 'CI' }, { Text: 'Service Request', Value: 'SR' }, { Text: 'Knowledge Base', Value: 'KB' }, { Text: 'Task', Value: 'TA' }, { Text: 'Event', Value: 'EVM' }, { Text: 'Availability', Value: 'AVM' }, { Text: 'Project', Value: 'PRJM' }, { Text: 'Service Catalog', Value: 'SC' }, { Text: 'Asset', Value: 'AM' }, { Text: 'User Asset', Value: 'UA' }, { Text: 'Service Level Requirements', Value: 'SLAR' }, { Text: 'Portfolio', Value: 'PFM' }, { Text: 'Service Level Agreement', Value: 'SLA' }, { Text: 'Operational Level Agreement', Value: 'OLA' }, { Text: 'Underpining Contract', Value: 'UPC' }, { Text: 'CIServices', Value: 'CISER' }, { Text: 'Release', Value: 'RM' }, { Text: 'Allocate Asset', Value: 'AM_A' }];
    $scope.CreateModulesConfig = [{ Text: 'Incident', Value: 'IM', Src: 'MDLIncidentMgmt/IM_TicketDetail.aspx?' }, { Text: 'Change', Value: 'CM', Src: 'MDLChangeMgmt/CM_EditChangeRequest.aspx?' }, { Text: 'Problem', Value: 'PM', Src: 'MDLProblemMgmt/PM_EditProblemTicket.aspx?' }, { Text: 'Work Order', Value: 'WO', Src: 'MDLIncidentMgmt/WO_WorkorderDetail.aspx?' }, { Text: 'Service Request', Value: 'SR', Src: 'MDLServiceMgmt/SR_LogServiceTicket.aspx?' }, { Text: 'Task', Value: 'TA', Src: 'MDLChangeMgmt/CM_TaskDetail.aspx?' }, { Text: 'Event', Value: 'EVM', Src: 'MDLAVMMgmt/AVM_Event_Details.aspx?' }, { Text: 'Availability', Value: 'AVM', Src: 'MDLIncidentMgmt/IM_TicketDetail.aspx?' }, {
        Text: 'Configuration Item', Value: 'CI', Src: 'MDLCMDB/CMDB_EditConfigurationItem.aspx?'
    }, { Text: 'Knowledge Base', Value: 'KB', Src: 'MDLKnowledgeMgmt/KM_Add_KB.aspx?' }, { Text: 'Portfolio', Value: 'PFM', Src: 'MDLPortfolioMgmt/EditPortFolio.aspx?' }, { Text: 'CAB Meeting', Value: 'CRMEET', Src: 'MDLChangeMgmt/CM_CAB_Meeting.aspx?' }, { Text: 'Release', Value: 'RM', Src: 'MDLReleaseMgmt/RM_EditReleaseRecord.aspx?' }];
    $scope.DetailUrlConfig = [{ Value: 'CR', Src: 'MDLChangeMgmt/CM_EditChangeRequest.aspx?' }, { Value: 'SR', Src: 'MDLServiceMgmt/SR_Detail.aspx?' }, { Value: 'KM', Src: 'MDLKnowledgeMgmt/KM_Add_KB.aspx?' }, { Value: 'AM', Src: 'MDLAssetMgmt/AM_RPT_AssetDetailView.aspx?' }, { Value: 'UA', Src: 'MDLAssetMgmt/AM_RPT_AssetDetailView.aspx?' }, { Value: 'SC', Src: 'MDLServiceMgmt/SR_ApproveCatalogItem.aspx?' }, { Value: 'RM', Src: 'MDLReleaseMgmt/RM_EditReleaseRecord.aspx?' }, { Value: 'CRMEET', Src: 'MDLChangeMgmt/CM_CAB_Meeting.aspx?' }, { Value: 'PFM', Src: 'MDLPortfolioMgmt/PF_EditPortFolio.aspx?' }, { Value: 'CI', Src: 'MDLCMDB/CMDB_EditConfigurationItem.aspx?' }, { Value: 'CISER', Src: 'MDLCMDB/CMDB_EditServices.aspx?' }, { Value: 'PRJM', Src: 'MDLProjectMgmt/PT_Project.aspx?' }];
    $scope.RelationshipRecords;
    $scope.GetRelations = function (config,callback) {
        $scope.Configuration = config;

        // #region EPROC Block
        $scope.EPROC_EnableRelationship = false;
        if (config.procurementSetting && config.procurementSetting.IsEnabled && config.procurementSetting.Url.length > 0)
        {
            $scope.EPROC_EnableRelationship = true;
            $scope.EprocUrl = config.procurementSetting.Url;
            var result = $.grep($scope.CreateModulesConfig, function (e) { return e.Value == 'EPROC'; });
            if (result == 0)
            {
                $scope.CreateModulesConfig.push({ Text: 'Procurement', Value: 'EPROC', Src: config.procurementSetting.Url + '/MDLEProcurement/Requests/RaisePurchaseRequest.aspx?' });
                $scope.LinkageModulesConfig.push({ Text: 'Procurement', Value: 'EPROC' });
            }
        }
        // #endregion

        if (config.excludeLinkageModules) $scope.LinkageModules = $scope.excludeModules($scope.LinkageModulesConfig, config.excludeLinkageModules);
        if (config.excludeCreateModules) $scope.CreateModules = $scope.excludeModules($scope.CreateModulesConfig, config.excludeCreateModules);
        if (config.includeLinkageModules) $scope.LinkageModules = $scope.includeModules($scope.LinkageModulesConfig, config.includeLinkageModules);
        if (config.includeCreateModules) $scope.CreateModules = $scope.includeModules($scope.CreateModulesConfig, config.includeCreateModules);

        if ((config.SourceID && config.SourceID != '') || (config.PreloadItems)) {
        $scope.SourceID = config.SourceID;        
        $scope.SourceType = config.SourceType;
        $scope.HideCreateButton = config.HideCreateButton;
        if ($scope.CallerID && $scope.CallerID>0)
            config.CallerID=$scope.CallerID;
        relService.GetRelations(config).then(function (response) {
            $scope.RelationshipRecords = response.data;
            $scope.RecordCount = 0;
            $.each(response.data, function (index, item) { if (item.length > 0) $scope.RecordCount = $scope.RecordCount + item.length; });

            //set first module as active and load the relationship records
            $.each(response.data, function (index, item) { if (response.data[index].length > 0) { $scope.FilterRelations(index); return false; } $scope.FilteredRelationshipRecords = []; });

            //Required for 'Do Not Update Child Priority' in IM/SR
            $scope.IncidentRecordCount = response.data['Child Incident'] != null ? response.data['Child Incident'].length : 0;
            $scope.RequestRecordCount = response.data['Child Request'] != null ? response.data['Child Request'].length : 0;

            if (callback) callback();
            if ($scope.ActivityCallBack) $scope.ActivityCallBack();
        });
        }
        if (config.SourceID == '') {
            $scope.HideCreateButton =true;
    }
    }

    $scope.FilterRelations = function (mod) {
        $('ul.moduleNavigation li.active').removeClass('active');
        var data = $scope.RelationshipRecords;
        $.each(data, function (index, item) {
            if (data[index].length > 0 && index == mod) {
                $scope.FilteredRelationshipRecords = data[index];
                setTimeout(function () {
                    $('ul.moduleNavigation li.active').removeClass('active');
                    $('ul.moduleNavigation li.' + $scope.applyCss(mod)).addClass('active');

                }, 10);
                
                return false;
                
    } 
        });
        
        //$(mod).parent().addClass('active');
}
    $scope.selectedRelationshipItems =[];
    $scope.IsSelectedTile = function (id, mod) {
    var exists = false;
    $.each($scope.selectedRelationshipItems, function (index, item) { 
        if (item.SelectedItemID == id && item.Module == mod) {
                exists = true; return false;
            }
        });
        return exists;
    }
    $scope.GetSelectedTileClass = function (id, mod) {
        return $scope.IsSelectedTile(id, mod) ? 'cardSelected': '';
    }
    $scope.GetModuleCode = function (moduleName) {
        var module;
        $.each(ModulesCodes, function (index, item) {
            if (item && item.Module == moduleName) {
                module = item; return false;
            }
        });
        return module.Code;
    }
    $scope.AddRelationItem = function (id, mod) {
        if (!$scope.IsSelectedTile(id, mod)) {
            $scope.selectedRelationshipItems.push({ SelectedItemID: id, Module: mod });
        } else $scope.DeleteRelationItem(id, mod);
        console.log(mod);
    }
    $scope.DeleteRelationItem = function (id, mod) {
        if ($scope.IsSelectedTile(id, mod)) {
            $.each($scope.selectedRelationshipItems, function (index, item) {
                if (item.SelectedItemID == id && item.Module == mod) {
                    $scope.selectedRelationshipItems.splice(index, 1); return false;
                }
            });
        }
    }
    $scope.DelinkRelations = function (callback) {
        var values = $scope.Configuration;
        values.SelectedRecords = $scope.selectedRelationshipItems;        
        if (!relService) {
            $scope.init($scope.params);
        }
        if (($scope.SourceID && $scope.SourceID != '')) {
        relService.Delink(values).then(function (resp) {
            $scope.GetRelations($scope.Configuration);
            $scope.selectedRelationshipItems =[];
        });
        if (callback) callback();
        if ($scope.ActivityCallBack) $scope.ActivityCallBack();
        } else {
        if($scope.DelinkRelationNewMode) $scope.DelinkRelationNewMode(values.SelectedRecords);
    }
        }
    $scope.ClearSelectedItems = function () {
        $scope.selectedRelationshipItems =[];
    }
    $scope.AddNewRelation = function (mod) {
        var __url = '../PopupControls/RelationMapping.aspx?sfn=' + $scope.params.instance + '&tid=' + $scope.Configuration.SourceID + '&mod=' + mod + '&SourceType=' + $scope.Configuration.SourceType + '&Old_Status=' + $scope.Configuration.Old_Status + '&EprocRel=' + $scope.EPROC_EnableRelationship;
        console.log('url:', __url);
        if ($scope.CallerID && $scope.CallerID > 0) __url += '&CallerID=' +$scope.CallerID;
        else if ($scope.Configuration.CallerID && $scope.Configuration.CallerID > 0) __url += '&CallerID=' +$scope.Configuration.CallerID;
        showSpopUpNav({'hideOnOverlayClick': false, 'CallOnClose': $scope.CallOnClose, 'width': '100%', 'height': '100%', 'autoScale': true, 'transitionIn': 'none', 'transitionOut': 'none', showDefaultActivity: true, onComplete: $scope.OnPopupLoaded, 'type': 'iframe', 'href': __url, 'showCustomTitle': true, 'title': 'RELATIONSHIP', 'titlePosition': 'top'
    });
    }
    $scope.OnPopupLoaded = function () {
    }
    $scope.OnRelationSelection = function () { $scope.GetRelations($scope.Configuration);
    }
    $scope.GetNavUrl = function ($event, item) {
        var url = '';
        var module = $scope.GetModuleCode(item[1].Key);
        var filtered = filterData($scope.DetailUrlConfig, { Value: module });
        if (filtered.length==0)filtered = filterData($scope.CreateModulesConfig, { Value: module });
        if (filtered && filtered.length > 0 && filtered[0].Src != '')url = '../' + filtered[0].Src;
        if (url != '') {
            var eidrow = filterData(item, { Key: 'EID' });
            if (eidrow && eidrow.length > 0) {
                if (module == 'SC') url += 'request=' + eidrow[0].Value;
                else if (module == 'AM' || module == 'UA') url += 'AssetID=' + eidrow[0].Value;
                else if (module == 'EVM') {
                    var filteredValues = filterData(item, { Key: 'Entity_Type' });
                    var entityType = '';
                    if (filteredValues && filteredValues.length && filteredValues[0].Value != '') entityType = filteredValues[0].Value;
                    url += 'EventID=' + eidrow[0].Value + '&EntityType=' + entityType + '&instance=' + $scope.params.instance;
                }
                else if (module == 'TA') {
                    url += 'ID=' + eidrow[0].Value + '&CRID=' + item[6].Value;
                }             
                else if(module == 'EPROC')
                {
                    item.push({ Key:'EprocUrl',Value: $scope.EprocUrl });
                    url = sumService.ShowEprocRelationalSummaryPopup(item);
                }
                else url += 'ID=' + eidrow[0].Value;
                $($event.target).prop('href', url);
            }
        } else { console.log('URL not specified for module:',module); }
    }
    $scope.ShowRelationship = function (options) {
        relService.ShowSummary(options)
    }
}]);
var RelationshipControllerScope = function () {
    return angular.element('[ng-controller=RelationshipController]').scope();
}

angularApp.controller('UserSelectionController', ['$scope', 'cfpLoadingBar', 'TreeViewPopupService', 'GeneralConfigService', '$parse', '$filter', 'filterFilter', function ($scope, cfpLoadingBar, TreeViewPopupService, GeneralConfigService, $parse, $filter, filterData) {

    $scope.init = function (parameters) {
        $scope.params = parameters;
        if($scope.params.appsettingsparams)$scope.appSettings = $scope.params.appsettingsparams;
        };

    $scope.RegisterAutoSearchForUser = function (ctrl, callback, options) {
        var autoSearchService = GeneralConfigService.getInstance($scope.params);
        autoSearchService.AutoSearchUser(ctrl, callback, options);
        var clearCtrl = ctrl.parent().find('.ClearSelection');
        clearCtrl.click(function () {
            ctrl.Clear();
            if (callback) callback({
                UserID: ''});
            });
    }
    $scope.RegisterAutoSearchForAllUser = function (ctrl, callback, options) {
        var autoSearchService = GeneralConfigService.getInstance($scope.params);
        autoSearchService.AutoSearchAllUser(ctrl, callback, options);
        var clearCtrl = ctrl.parent().find('.ClearSelection');
        clearCtrl.click(function () {
            ctrl.Clear();
            if (callback) callback({
                UserID: ''
            });
        });
    }

    $scope.OnUserSelection;//method invoked when the user is selected from the autosearch or the popup    
    $scope.RegisterUserSelectionPopup = function (ctrl, callback, options) {
        var autoSearchService = GeneralConfigService.getInstance($scope.params);
        autoSearchService.UserSelectionPopup($scope, ctrl, callback, options);
    }
    $scope.RegisterAllUserSelectionPopup = function (ctrl, callback, options) {
        var autoSearchService = GeneralConfigService.getInstance($scope.params);
        autoSearchService.AllUserSelectionPopup($scope, ctrl, callback, options);
    }
    $scope.UserSelectionPopupClose = function () {
        bootbox.hideAll();
        $(".modal-backdrop.fade").remove();
    }
}]);
var UserSelectionControllerScope = function () {
    return angular.element('[ng-controller=UserSelectionController]').scope();
}
