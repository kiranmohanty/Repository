﻿//app.service.js - service layer for angularjs modules
//dependency: first: angular.min.js, second: app.init.js
var browser = get_browser_info();
angularApp.factory('GeneralConfigService', ['$http', '$q', '$compile', function ($http, $q, $compile) {
    var OrgID = 0, UserID = 0, IncludeInactive = 1, InstanceBasedAccess=0;
    var blockUI = false;
    var IncidentWebAPIUrl = '../WS/Common/GeneralConfigService.asmx';
    this.APIUrl = IncidentWebAPIUrl;

    var serviceProvider = function () { };
    serviceProvider.prototype.Init = function (params) {
        if (params.orgid) OrgID = params.orgid; else OrgID = params.OrgID;
        if (params.userid) UserID = params.userid; else UserID = params.UserID;
        if (params.instance) Instance = params.instance; else Instance = params.Instance;
        if (params.IncludeInactive) { IncludeInactive = params.IncludeInactive; } else { IncludeInactive = params.IncludeInactive; }
        if (params.InstanceBasedAccess) { InstanceBasedAccess = params.InstanceBasedAccess; }

        blockUI = params.blockUI;
    }
    //instantiate auto search method for the given contrl
    serviceProvider.prototype.AutoSearchUser = function (ctrl, callback, options) {        
        var self = this;        
        ctrl.autocomplete({
            source: function (request, response) {                
                 var inactiveCheck = ctrl.parent().find('#includeInactive');                
                if ($(inactiveCheck).is(":checked")) {                    
                    IncludeInactive = 1;
                }
                else {
                    IncludeInactive = 0;
                }
                var webApiurl = IncidentWebAPIUrl + '/GetUsers';
                var par = { OrgID: OrgID, Instance: Instance, IncludeInactive: IncludeInactive, SearchText: ctrl.val(), APIUrl: webApiurl, InstanceBasedAccess: InstanceBasedAccess };
                if (options != null && options != undefined) {
                    par.Level = options.Level;
                    par.CatalogID = options.CatalogID;
                    par.Requestor = options.UserID;
                    par.InstanceBasedAccess = InstanceBasedAccess;
                }
                self.AsyncData(par).then(function (d) {

                    response($.map(d.data, function (item) {
                        return { label: item.UserName, UserName: item.UserName, UserID: item.UserID, EmailID: item.EmailID, MobileNo: item.MobileNo, Contact: item.Contact, CustomerName: item.CustomerName, LocationName: item.LocationName,Location:item.Location,Customer:item.Customer, ProfileImg: item.UserProfileImageName, dataItem: item }
                    }));
                });
            },minLength:2, autoFocus: true, messages: { noResults: '', results: function () { } },
            select: function (event, ui) { ctrl.val(ui.item.label); if (callback) callback(ui.item); return false; }
        });
        ctrl.keydown(function (event) { return (event.keyCode != 13); });
    };

    //instantiate auto search method for the given contrl
    serviceProvider.prototype.AutoSearchAllUser = function (ctrl, callback, options) {
        var self = this;
        ctrl.autocomplete({
            source: function (request, response) {             
                
                    IncludeInactive = 1;               
                var webApiurl = IncidentWebAPIUrl + '/GetUsers';
                var par = { OrgID: OrgID, Instance: Instance, IncludeInactive: IncludeInactive, SearchText: ctrl.val(), APIUrl: webApiurl ,InstanceBasedAccess:InstanceBasedAccess};
                if (options != null && options != undefined) {
                    par.Level = options.Level;
                    par.CatalogID = options.CatalogID;
                    par.Requestor = options.UserID;
                    par.InstanceBasedAccess = InstanceBasedAccess;
                }
                self.AsyncData(par).then(function (d) {
                    response($.map(d.data, function (item) {
                        return { label: item.UserName, UserName: item.UserName, UserID: item.UserID, EmailID: item.EmailID, MobileNo: item.MobileNo, Contact: item.Contact, CustomerName: item.CustomerName, LocationName: item.LocationName, ProfileImg: item.UserProfileImageName, dataItem: item }
                    }));
                });
            }, minLength: 2, autoFocus: true, messages: { noResults: '', results: function () { } },
            select: function (event, ui) { ctrl.val(ui.item.label); if (callback) callback(ui.item); return false; }
        });
        ctrl.keydown(function (event) { return (event.keyCode != 13); });
    };

    serviceProvider.prototype.AutoSearchLocation = function (ctrl, callback, options) {
        var self = this;
        ctrl.autocomplete({
            source: function (request, response) {
                var values = { SearchText: ctrl.val() };
                self.GetLocations(values).then(function (d) {
                    response($.map(d.data, function (item) {
                        return { label: item.Text, Id: item.Value}
                    }));
                });
            }, autoFocus: true, messages: { noResults: '', results: function () { } },
            select: function (event, ui) { ctrl.val(ui.item.label); if (callback) callback(ui.item); return false; }
        });
    };
    serviceProvider.prototype.AutoSearchCustomer = function (ctrl, callback, options) {
        var self = this;
        ctrl.autocomplete({
            source: function (request, response) {
                var values = { SearchText: ctrl.val() };
                self.GetCustomers(values).then(function (d) { response($.map(d.data, function (item) { return { label: item.Text, Id: item.Value } })); });
            }, autoFocus: true, messages: { noResults: '', results: function () { } },
            select: function (event, ui) { ctrl.val(ui.item.label); if (callback) callback(ui.item); return false; }
        });
    };
    serviceProvider.prototype.GetUsers = function (o, ignoreLocalParams) {
       // console.log("GetUsers");
        var webApiurl = IncidentWebAPIUrl + '/GetUsers';
        var par = {};
        if (ignoreLocalParams){ par = o; par.APIUrl = webApiurl; }
        else par = { OrgID: OrgID, Instance: Instance, SearchText: o.SearchText, APIUrl: webApiurl };
        response = this.AsyncData(par);
        return response;
    }
    serviceProvider.prototype.GetLocations = function (o) {
        var webApiurl = IncidentWebAPIUrl + '/GetLocations';
        var par = { OrgID: OrgID, Instance: Instance, SearchText: o.SearchText, APIUrl: webApiurl };
        response = this.AsyncData(par);
        return response;
    }
    serviceProvider.prototype.GetCustomers = function (o) {
        var webApiurl = IncidentWebAPIUrl + '/GetCustomers';
        var par = { OrgID: OrgID, Instance: Instance, SearchText: o.SearchText, APIUrl: webApiurl };
        response = this.AsyncData(par);
        return response;
    }
    serviceProvider.prototype.UserSelectionPopup = function (scope,ctrl, callback, options) {
        var self = this; var showInactiveUserChkbox = false;
        if ($("#includeInactive").length) { showInactiveUserChkbox = true; }
        
        ctrl.click(function () {
            var webApiurl = '../PopupControls/UserSelection.aspx';
            var par = { OrgID: OrgID, Instance: Instance, showInactiveUserChkbox: showInactiveUserChkbox, APIUrl: webApiurl ,InstanceBasedAccess:InstanceBasedAccess};
            if (options != null && options != undefined) {
                par.Level = options.Level;
                par.CatalogID = options.CatalogID;
                par.Requestor = options.UserID;
                par.InstanceBasedAccess = InstanceBasedAccess;
                //par.JsonParams = JSON.stringify(options);
            }
            self.AsyncContent(par).then(function (d) {
                var cont = $compile(d.data)(scope);
                var Popup = bootbox.dialog({
                    message: cont,
                    title: 'Select User', buttons: { main: { label: "OK", className: "btn-primary", callback: function () { bootbox.hideAll();
                }
                }
                }
                }).find("div.modal-dialog").addClass("bootboxWidth70");
                if (callback) scope.OnUserSelection = callback;
            });            
        });
    }

    serviceProvider.prototype.AllUserSelectionPopup = function (scope, ctrl, callback, options) {
        var self = this; var showInactiveUserChkbox = true;      

        ctrl.click(function () {
            var webApiurl = '../PopupControls/UserSelection.aspx';
            var par = { OrgID: OrgID, Instance: Instance, showInactiveUserChkbox: showInactiveUserChkbox,IncludeInactive:1,APIUrl: webApiurl };
            if (options != null && options != undefined) {
                par.Level = options.Level;
                par.CatalogID = options.CatalogID;
                par.Requestor = options.UserID;
                //par.JsonParams = JSON.stringify(options);
            }
            self.AsyncContent(par).then(function (d) {
                var cont = $compile(d.data)(scope);
                var Popup = bootbox.dialog({
                    message: cont,
                    title: 'Select User', buttons: {
                        main: {
                            label: "OK", className: "btn-primary", callback: function () {
                                bootbox.hideAll();
                            }
                        }
                    }
                }).find("div.modal-dialog").addClass("bootboxWidth70");
                if (callback) scope.OnUserSelection = callback;
            });
        });
    }
    serviceProvider.prototype.AsyncData = function (o) {
        var webApiurl = o.APIUrl;       
        var par = o;
        delete par.APIUrl;
        //console.log('GCS:' + JSON.stringify(par));
        var response = $http({
                method: "GET", url: webApiurl, params: { args: tryDecodeURIComponent(JSON.stringify(par)) }, headers: { 'Accept': 'application/json, text/javascript', 'Content-Type': 'application/json; charset=utf-8' }
        }).success(function (data, status, headers, config) {
            return data;
        }).error(function (data, status, headers, config) {
            console.log('error');
            return null;
        });
        return response;
    }
    serviceProvider.prototype.AsyncContent = function (o) {
        var webApiurl = o.APIUrl;
        var par = o;
        
        var response = $http({
            method: "GET", url: webApiurl, params: { args: JSON.stringify(par) }
        }).success(function (data, status, headers, config) {
            return data;
        }).error(function (data, status, headers, config) {
            console.log('error');
            return null;
        });
        return response;
    }
    //to get new instance of GeneralConfigService object
    var service = {
        getInstance: function (config) { var _instance = new serviceProvider(); _instance.Init(config); return _instance; }
    }

    return service;
}]);

angularApp.factory('TreeViewPopupService', function () {
    var _config;
    var serviceProvider = function () { };
    //santosh
    serviceProvider.prototype.show = function (params, callbackevents) {
        var IMPopup = bootbox.dialog({
            message: "<div class='col-md-12'><i id='iNote' class='fa fa-info-circle' style='color: #555; font-size: 16px;display:none;'></i><span id='lblNote' class='label-text padding-zero align-left margin-left-5px'></span><input type='text' id='__searchJsTree' class='form-control' placeholder='Search...'/></div><div id='__modalpopupContent' class='clearfix padding-top-20px padding-left-5px'></div>",
            title: ((_config.popupTitle != null && _config.popupTitle.length > 0) ? _config.popupTitle : _config.title),
            buttons: {
                main: {
                    label: "OK", className: "btn-primary", callback: function () { if (callbackevents && callbackevents.okCallback && typeof (callbackevents.okCallback) == 'function') callbackevents.okCallback(_config.SelectedId); IMPopup.modal('hide'); if (typeof parent.parent.ShowModuleRefresh == 'function') { parent.parent.ShowModuleRefresh(); } }
                }
            },
            onEscape: function () {
                if (callbackevents && callbackevents.cancelCallback && typeof (callbackevents.cancelCallback) == 'function') callbackevents.cancelCallback(_config.SelectedId);
                if (typeof parent.parent.ShowModuleRefresh == 'function') { parent.parent.ShowModuleRefresh(); }
            }

        });


        // jstree conditional select node
        (function ($, undefined) {
            "use strict";
            $.jstree.defaults.conditionalselect = function () { return true; };

            $.jstree.plugins.conditionalselect = function (options, parent) {
                // own function
                this.select_node = function (obj, supress_event, prevent_open) {
                    if (this.settings.conditionalselect.call(this, this.get_node(obj))) {
                        parent.select_node.call(this, obj, supress_event, prevent_open);
                    }
                };
            };
        })(jQuery);

        var autoselect = false;
        $("#__modalpopupContent").jstree({
            "conditionalselect": function (node) {
                //Enable selection of parent node based on Instance config.
                var lblNoteMsg = 'Cannot select parent node.';
                if (node) {
                    if (_config.title == 'Category') {
                        if (_config.enableCategoryParentNode == null || _config.enableCategoryParentNode == undefined || node.children.length == 0) {
                        return true;
                    }
                    else if (node.children.length > 0) {
                            if (_config.enableCategoryParentNode == false) { $('#iNote').show(); $('#lblNote').text(lblNoteMsg); }
                        return _config.enableCategoryParentNode;
                    }
                }
                    else if (_config.title == 'Classification') {
                    if (_config.enableClassificationParentNode == null || _config.enableClassificationParentNode == undefined || node.children.length == 0) {
                        return true;
                    }
                    else if (node.children.length > 0) {
                            if (_config.enableClassificationParentNode == false) { $('#iNote').show(); $('#lblNote').text(lblNoteMsg); }
                        return _config.enableClassificationParentNode;
                    }
                }
                else if (_config.title == 'SR Catalog') {
                    if (_config.enableSRCatalogParentNode == null || _config.enableSRCatalogParentNode == undefined || node.children.length == 0) {
                        return true;
                    }
                    else if (node.children.length > 0) {
                        if (_config.enableSRCatalogParentNode == false) { $('#iNote').show(); $('#lblNote').text(lblNoteMsg); }
                        return _config.enableSRCatalogParentNode;
                    }
                }
                else if (_config.title == 'Project') {
                    if (_config.enableProjectParentNode == null || _config.enableProjectParentNode == undefined || node.children.length == 0) {
                        return true;
                    }
                    else if (node.children.length > 0) {
                        if (_config.enableProjectParentNode == false) { $('#iNote').show(); $('#lblNote').text(lblNoteMsg); }
                        return _config.enableProjectParentNode;
                    }
                }
                    else {
                        return true;
                    }
                }
                else {
                    return true;
                }
            },
            "plugins": ["search", "conditionalselect"],
            'core': { 'data': _config.content, "themes": { "icons": false, "theme": "classic", "dots": true } },
            'search': { 'fuzzy': false }
        }).bind("select_node.jstree", function (event, data) {
            
            // santosh
           // 
            //console.log('selected node:' + data.node.id);
            // get full path of selected node
            if (data.node.original.HasCatalog !=undefined && data.node.original.HasCatalog  == true  ) {
                $('#iNote').show(); $('#lblNote').text("You cannot create Service Category under a Service Category which has Service Catalogs.");
                return false;
            }
            var strFullPath = data.instance.get_path(data.node, '\\');
            if (strFullPath.length > 0) {
                //Full path will be assign to fullname property instead text of node :bug-25734
              //  data.node.text = strFullPath;
                data.node.fullname = strFullPath;
            }

            if (autoselect == false) {
                IMPopup.modal('hide');                
                if (typeof parent.parent.ShowModuleRefresh == 'function') { parent.parent.ShowModuleRefresh(); };
                if (_config.onSelect) _config.onSelect(data.node);
            }
        }).bind("ready.jstree", function () {
            if (_config.SelectedId > 0) {
                autoselect = true;
                $('#__modalpopupContent').jstree('select_node', _config.SelectedId);
                autoselect = false;
            }

            if (params && params.SearchText && $.trim(params.SearchText).length > 0) {
                var searchText = $.trim(params.SearchText);
                $('#__searchJsTree').val(searchText);
                $('#__modalpopupContent').jstree(true).search(searchText);
            }

            $.each(_config.content, function (key, value) {
                if (value.HasCatalog == undefined) {
                    return false;
                }
                if (value.HasCatalog != undefined && value.HasCatalog == true) {
                    var id = value.id;

                    if (typeof ($("#__modalpopupContent").jstree(true).get_node(id).li_attr) != 'undefined') {
                        //if (browser.name == 'IE8') {
                        //    $("#__modalpopupContent").jstree(true).get_node(id).li_attr.addClass("has-catalog");
                        //}
                        //else {
                        //    $("#__modalpopupContent").jstree(true).get_node(id).li_attr.class = "has-catalog";
                        //}
                        $("#__modalpopupContent").jstree(true).get_node(id).li_attr["class"]= "has-catalog";
                    }
                    $("#__modalpopupContent").jstree(true).redraw_node(id, true);
                }

                if (value.HasCatalog == "0") {
                    var id = value.id;
                    if (typeof ($("#__modalpopupContent").jstree(true).get_node(id).li_attr) != 'undefined') {
                        //if (browser.name == 'IE8') {
                        //    $("#__modalpopupContent").jstree(true).get_node(id).li_attr.addClass("no-catalog");
                        //}
                        //else {
                        //    $("#__modalpopupContent").jstree(true).get_node(id).li_attr.class = "no-catalog";
                        //}
                        $("#__modalpopupContent").jstree(true).get_node(id).li_attr["class"] = "no-catalog";
                    }
                    $("#__modalpopupContent").jstree(true).redraw_node(id, true);
                }
            });
        });



        var to = false;
        var t = 250;
        $('#__searchJsTree').keyup(function () {
          
            if(to)clearTimeout(t)
            to = setTimeout(function () {
                var v = $('#__searchJsTree').val();
                $('#__modalpopupContent').jstree(true).search(v);
            }, 250);
          
        });


    };
    //to get new instance of PopupProviderFactory object
    var service = {
        getInstance: function (config) { _config = config; return new serviceProvider(); }
    }

    return service;
});

angularApp.factory('SummaryService', ['$http', '$q', '$compile', 'GeneralConfigService', 'filterFilter', function ($http, $q, $compile, GeneralConfigService, filterData) {
    var OrgID = 0, UserID = 0;
    var blockUI = false;
    var Url = '../WS/Common/RelationshipService.asmx';
    var serviceProvider = function () { };
    serviceProvider.prototype.Init = function (params) {
        OrgID = params.orgid;
        UserID = params.userid;
        Instance = params.instance;
        blockUI = params.blockUI;
    }

    serviceProvider.prototype.GetAsyncData = function (o) {
        var webApiurl = o.APIUrl;
        if (o.Method && o.Method != '') webApiurl += o.Method;
        var par = o;
        //delete par.APIUrl;
        //console.log('SS:' +JSON.stringify(par));
        return $http({ method: "GET", url: webApiurl, params: { args: tryDecodeURIComponent(JSON.stringify(par)) }, headers: { 'Accept': 'application/json, text/javascript', 'Content-Type': 'application/json; charset=utf-8' } }).success(function (data, status, headers, config) { return data; }).error(function (data, status, headers, config) { console.log('error'); return null;
});
    }
    serviceProvider.prototype.GetSummaryData = function (o, callback) {
        this.GetAsyncData(o).then(callback);
    }
    serviceProvider.prototype.ShowSummary = function (o) {
        //console.log('Incident Summary:', o);
        if (o.Module == 'IM') {
            ShowSPopUP("../MDLIncidentMgmt/IM_Summary.aspx?id=" + o.ID, 'Incident', o.BaseURL, 'large');
        } else if (o.Module == 'Configuration Item') {
            ShowSPopUP("../MDLCMDB/CMDB_ViewConfigurationItem_Relation.aspx?id=" + o.ID, 'Configuration Item - Relationship', o.BaseURL, 'large');
        }
    }

    serviceProvider.prototype.ShowEprocRelationalSummaryPopup = function (o) {
        var popupHeader = 'Purchase Request';
        var EID = filterData(o, { Key: 'EID' })[0].Value;
        var PNO = filterData(o, { Key: 'Purchase Request' })[0].Value;
        var EprocUrl = filterData(o, { Key: 'EprocUrl' })[0].Value;
        if (PNO.length > 0)
        {
            popupHeader = popupHeader + ' - ' + PNO;
        }

        ShowSPopUP("../PopupControls/EPROC_RelationSummary.aspx?ID=" + EID + '&EprocUrl=' + EprocUrl, popupHeader, '', 'large');
    }

    serviceProvider.prototype.SaveData = function (o, callback) {
        this.GetAsyncData(o).then(callback);
    }
    var service = { getInstance: function (config) { var _instance = new serviceProvider(); _instance.Init(config); return _instance; } }

    return service;
}]);

angularApp.factory('RelationshipService', ['$http', '$q', '$compile', 'SummaryService', function ($http, $q, $compile, SummaryService) {
    var OrgID = 0, UserID = 0;
    var blockUI = false;
    var summaryService;
    var serviceProvider = function () { };
    serviceProvider.prototype.Init = function (params) {
        OrgID = params.orgid;
        UserID = params.userid;
        Instance = params.instance;
        blockUI = params.blockUI;
        summaryService = SummaryService.getInstance(params);
    }  
    serviceProvider.prototype.GetRelations = function (config) {
        var url = config.WsURL + config.ListServiceName;
        var currentUser = (config.CallerID && config.CallerID > 0 ? config.CallerID : UserID);
        var par = { OrgID: OrgID, UserID: currentUser, Instance: Instance, APIUrl: url, SourceID: config.SourceID, SourceType: config.SourceType, CategoryId: config.CategoryId, ClassificationId: config.ClassificationId, PreloadItems: config.PreloadItems };
        return this.AsyncData(par);
        }
    serviceProvider.prototype.AsyncData = function (o) {
        var webApiurl = o.APIUrl;
        var par = o;
        delete par.APIUrl;
        //console.log('RS:' + JSON.stringify(par));
        return $http({ method: "GET", url: webApiurl, params: { args: tryDecodeURIComponent(JSON.stringify(par)) }, headers: { 'Accept': 'application/json, text/javascript', 'Content-Type': 'application/json; charset=utf-8' }}).success(function (data, status, headers, config) { return data; }).error(function (data, status, headers, config) {console.log('error'); return null;
        });
    }
    serviceProvider.prototype.Delink = function (values) {
        var url = values.WsURL + values.DelinkServiceName;
        var selectedTiles = values;
        selectedTiles.APIUrl = url;
        //if (selectedTiles.WsURL) delete selectedTiles.WsURL;
        //if (values.ListServiceName) delete values.ListServiceName;
        //if (values.DelinkServiceName) delete values.DelinkServiceName;
        return this.AsyncData(selectedTiles);
    }
    serviceProvider.prototype.ShowSummary = function (o) {
        summaryService.ShowSummary(o);
    }
    var service = {getInstance: function (config) { var _instance = new serviceProvider(); _instance.Init(config); return _instance; }}

    return service;
}]);

angularApp.factory('Utils', ['$http', '$q', '$compile', function ($http, $q, $compile) {
    return {
       DateTimeFormat:'yyyy-MM-dd HH:mm:ss'
    }
}]);

