﻿
function SummaryController($scope, SummaryService, $filter, filterData, $compile, $rootScope, Utils, $templateCache, $http, $parse, RelationshipService) {
    $scope.datetimeformat = Utils.DateTimeFormat;
    $scope.loading = false;
    var parentWindow = false;
    $rootScope.$on('$includeContentLoaded', function (event) {
        $scope.loaded = true;
    });
    $scope.$watchCollection('[loaded]', function (newValues) {
        if ($scope.loaded && $scope.show) $scope.showPopup();
            //User Story-20770 - added to get summary details as a Div
        //else if ($scope.options.ID != null || $scope.options.ID != '') {
        //    $scope.showDiv(); 
        //}

    });
    $scope.init = function (o) {
        $scope.options = o;
        $scope.WsURL = '../WS/Common/SummaryService.asmx/';
        $scope.APIUrl = $scope.WsURL + 'GetSummaryDetail';
        if (o.ModuleCode && o.ModuleCode != '')
        {
            if (o.ModuleCode == 'IM') { $scope.TemplateUrl = '../MDLIncidentMgmt/' + o.ModuleCode + '_Summary.aspx'; }
            else { $scope.TemplateUrl = o.ModuleCode + '_Summary.aspx'; }
        }

        $scope.cacheTpl();
    }
    $scope.loadedModels = [];
    $scope.UpdateModel = function (modelstr, val) {
        var model = $parse(modelstr);
        model.assign($scope, val);
        $scope.loadedModels.push(modelstr);
    }
    $scope.getContent = function (options, callback) {
        var response = $http({
            method: "GET", url: options.url, params: { args: JSON.stringify(options.params) }
        }).success(function (data, status, headers, config) {
            if (callback) callback(data);
        }).error(function (data, status, headers, config) { console.log('error'); });
    }
    $scope.cacheTpl = function (o) {
        var cfg = $scope.options;
        if ($scope.TemplateUrl && $scope.TemplateUrl != '') {
            var options = { url: $scope.TemplateUrl, params: { Role: $scope.options.Role } };
            $scope.getContent(options, function (data) {
                $scope.loaded = true; $scope.tpl = data;
            });
        } else log('Template not found.');
    }
    $scope.initUI = function () {
        $("ul#tabs li:first").addClass('active');
        $(".tab-content li").each(function () {
            if ($(this).hasClass('active')) $(this).removeClass('active');
        });
        $(".tab-content li:first").addClass('active');
    }
    $scope.loadSummary = function (o) {
        parentWindow = o.parentWindow ? o.parentWindow : false;
        o.APIUrl = $scope.APIUrl;
        $scope.options = o;
        $scope.summaryData = {};
        $scope.show = true;
        if ($scope.loading) { return; } else $scope.loading = true;
        var summary = SummaryService.getInstance({});
        summary.GetSummaryData(o, function (response) {
            $scope.clear();
            $scope.clearLoadedIframes();
            $scope.summaryData = response.data;
            $scope.initUI();
            if ($scope.loaded) $scope.showPopup();
            $scope.GetRelations();
            $scope.loading = false;
        });
    }
///User story - 20770 - added to load summary details to a div
    $scope.loadSummaryDetails = function (o) {
        parentWindow = true;
        o.APIUrl = $scope.APIUrl;
        $scope.options = o;
        $scope.summaryData = {};
        $scope.show = false;
        if ($scope.loading) { return; } else $scope.loading = true;
        var summary = SummaryService.getInstance({});
        summary.GetSummaryData(o, function (response) {
            $scope.clear();
            $scope.clearLoadedIframes();
            $scope.summaryData = response.data;
            $scope.initUI();
            $scope.GetRelations();
            $scope.loading = false;
            if ($scope.loaded) $scope.showDiv();
        });
    }
    $scope.showPopup = function () {
        if (typeof parent.parent.HideModuleRefresh == 'function') {
            parent.parent.HideModuleRefresh();
        }
        var linkFn = $compile($scope.tpl);
        var content = linkFn($scope);



        var __divContent = '<div id="__divContent" style="max-height:450px;overflow:auto; overflow-y:auto;overflow-x:hidden;width:98%"></div>';
        //added by Sudarsan on 12/1/2016
        console.log("ok");
        if (parentWindow) {
            parent.bootbox.dialog({ title: $scope.options.Title + ' - Summary', message: __divContent, buttons: { success: { label: 'OK', className: "btn-primary" } } }).find("div.modal-dialog").addClass("bootboxWidth95").find('div.bootbox-body').css({});
            $('#__divContent', parent.document).append(content);
        }
            //ends here
        else {
            bootbox.dialog({ title: $scope.options.Title + ' - Summary', message: __divContent, buttons: { success: { label: 'OK', className: "btn-primary" } } }).on('hidden.bs.modal', function () { try { if (typeof parent.ShowModuleRefresh == "function") { parent.ShowModuleRefresh(); } } catch (er) { console.log(er.message);} }).find("div.modal-dialog").addClass("bootboxWidth95").find('div.bootbox-body').css({});
            $('#__divContent').append(content);
        }

        //bootbox.dialog({ title: $scope.options.Title + ' - Summary', message: __divContent, buttons: { success: { label: 'OK', className: "btn-primary" } } }).find("div.modal-dialog").addClass("bootboxWidth95").find('div.bootbox-body').css({});
        //$('#__divContent').append(content);
    }
//User story - 20770 - added this method to Show the summary details as a div
    $scope.showDiv = function () {
        if (typeof parent.parent.HideModuleRefresh == 'function') {
            parent.parent.HideModuleRefresh();
        }
        var linkFn = $compile($scope.tpl);
        var content = linkFn($scope);
        if ($scope.options) {
            if (parentWindow) {
                $($scope.options.ID).append(content);
            }
            else {
                $($scope.options.ID).append(content);
            }
        }
    }
    var relService;
    $scope.GetRelations = function (callback) {
        var config = $scope.options;
        config.SourceType = config.ModuleCode;
        if (config.EID) config.SourceID = config.EID;
        else if (config.TicketID) config.SourceID = config.TicketID;
        config.WsURL = '../WS/Common/RelationshipService.asmx/';
        config.ListServiceName = 'GetRelations'
        if (!relService) relService = RelationshipService.getInstance(config);
        relService.GetRelations(config).then(function (response) {
            $scope.RelationshipRecords = response.data;
            if (callback) callback();
        });
    }

    $scope.ViewDetails = function (Key, card) {
        var ind = card.map(function (i) { return i.Key }).indexOf('EID');
        var indEntity = card.map(function (i) { return i.Key }).indexOf('Entity_Type');
        console.log(Key);
        // console.log(card);
        var url = '';
        if (Key == 'Asset') { url = '../MDLAssetMgmt/AM_RPT_AssetDetailView.aspx?AssetID=' + card[ind].Value + ''; }
        else if (Key == 'Change') { url = '../MDLChangeMgmt/CM_EditChangeRequest.aspx?ID=' + card[ind].Value + ''; }
        else if (Key == 'Incident') { url = '../MDLIncidentMgmt/IM_TicketDetail.aspx?TicketID=' + card[ind].Value + ''; }
        else if (Key == 'Knowledge') { url = '../MDLKnowledgeMgmt/KM_Add_KB.aspx?ID=' + card[ind].Value + ''; }
        else if (Key == 'Problem') { url = '../MDLProblemMgmt/PM_EditProblemTicket.aspx?ID=' + card[ind].Value + ''; }
        else if (Key == 'Project') { url = '../MDLProjectMgmt/PT_Project.aspx?ID=' + card[ind].Value + ''; }
        else if (Key == 'Service Request') { url = '../MDLServiceMgmt/SR_Detail.aspx?ID=' + card[ind].Value + ''; }
        else if (Key == 'User Asset') { url = '..//MDLAssetMgmt/AM_RPT_AssetDetailView.aspx?AssetID=' + card[ind].Value + ''; }
        else if (Key == 'Work Order') { url = '../MDLIncidentMgmt/WO_WorkorderDetail.aspx?ID=' + card[ind].Value + ''; }
        else if (Key == 'Portfolio') { url = '../MDLPortfolioMgmt/PF_EditPortFolio.aspx?ID=' + card[ind].Value + ''; }
        else if (Key == 'Configuration Item') { url = '../MDLCMDB/CMDB_EditConfigurationItem.aspx?ID=' + card[ind].Value + ''; }
        else if (Key == 'CatalogName') { url = '../MDLServiceMgmt/SR_ApproveCatalogItem.aspx?request=' + card[ind].Value + ''; }
        else if (Key == 'Event') { url = '../MDLAVMMgmt/AVM_Event_Details.aspx?EventID=' + card[ind].Value + '&EntityType=' + card[indEntity].Value + ''; }
        else if (Key == 'Parent Incident') { url = '../MDLIncidentMgmt/IM_TicketDetail.aspx?TicketID=' + card[ind].Value + ''; }


        return url;
    }
    //-- Column Specification by Module
    $scope.processRel = function (mod) {
        if (mod == 'Asset') {
            $scope.DisplayColumns = ['Asset', 'Serial No', 'Host Name'];
            $scope.Columns = $scope.DisplayColumns;
        } else if (ContainsInArray(mod ,[ 'Child Incident','Parent Incident'])) {
            $scope.DisplayColumns = ['Incident', 'Status', 'Symptom'];
            $scope.Columns = $scope.DisplayColumns;
        } else if (mod == 'Change') {
            $scope.DisplayColumns = ['Change', 'Status', 'Symptom'];
            $scope.Columns = $scope.DisplayColumns;
        } else if (mod == 'Problem') {
            $scope.DisplayColumns = ['Problem', 'Status', 'Symptom'];
            $scope.Columns = $scope.DisplayColumns;
        } else if (mod == 'Configuration Item') {
            $scope.DisplayColumns = ['Configuration Item', 'Status', 'Host Name', 'SOP'];
            $scope.Columns = ['Configuration Item', 'Status', 'Symptom', 'ESOPId'];
        } else if (mod == 'Knowledge') {
            $scope.DisplayColumns = ['Knowledge', 'Subject', 'Category'];
            $scope.Columns = $scope.DisplayColumns;
        } else if (mod == 'Service Request') {
            $scope.DisplayColumns = ['Service Request', 'Status', 'Symptom'];
            $scope.Columns = $scope.DisplayColumns;
        } else if (mod == 'Work Order') {
            $scope.DisplayColumns = ['Work Order', 'Status', 'Symptom'];
            $scope.Columns = $scope.DisplayColumns;
        } else if (mod == 'Service Catalog') {
            $scope.DisplayColumns = ['CategoryName', 'CatalogName', 'Description', 'Status'];
            $scope.Columns = $scope.DisplayColumns;
        } else if (mod == 'Event') {
            $scope.DisplayColumns = ['Event', 'Entity_Type', 'Message', 'Category'];
            $scope.Columns = $scope.DisplayColumns;
        }
        else if (mod == 'Portfolio') {
            $scope.DisplayColumns = ['Portfolio', 'Status', 'Service_Name', 'Category_Name', 'Classification_Name'];
            $scope.Columns = $scope.DisplayColumns;
        }
        else if (mod == 'Project') {
            $scope.DisplayColumns = ['Project', 'Status', 'Start Date', 'Name', 'End Date', '% Completed'];
            $scope.Columns = $scope.DisplayColumns;
        }
        return true;
    }
    $scope.filterColumn = function (field) {
        return ($scope.Columns.indexOf(field.Key) !== -1);
    };
    var loadedTabs = [];
    $scope.loadTabData = function (options, callback) {
        var config = {
            url: $scope.WsURL + options.ApiMethod, params: $scope.options
        };
        var loaded = filterData(loadedTabs, {
            tab: options.ApiMethod
        });
        if (!loaded || loaded.length == 0) {
            $scope.getContent(config, function (data) {
                if (options.model && options.model != '') $scope.UpdateModel(options.model, data);
                if (callback) callback(data);
                loadedTabs.push({
                    tab: options.ApiMethod
                });
            });
        }
    }
    $scope.clearLoadedIframes = function () {
        $scope.loadedIframes = [];
    }

    $scope.loadIFrame = function (options, callback) {
        var filtered = filterData($scope.loadedIframes, { Page: options.Page });
        if (!filtered || filtered.length == 0) {
            $('#' + options.TargetID).prop('src', options.Page).load(function () {
                $scope.loadedIframes.push({ Page: options.Page });
            });
        }
    }

    $scope.clear = function () {
        loadedTabs = [];
        loadedModels = $scope.loadedModels;
        if (loadedModels && loadedModels.length > 0) {
            $.each(loadedModels, function (i, name) {
                $scope.UpdateModel(name, undefined);
            });
        }
    }

    $scope.SaveEvaluation = function (callback) {
        var p;
        if (window.evaluationParams) p = window.evaluationParams();
        p.APIUrl = '../WS/Common/SummaryService.asmx/SaveEvaluation';
        p.OrgID = $scope.options.OrgID;
        p.UserID = $scope.options.UserID;
        p.EID = $scope.options.EID;
        var summary = SummaryService.getInstance({});
        summary.SaveData(p, function (response) {
            $scope.EvaluationHistory = response.data.Data;
            if (window.SaveEvaluationCallback) window.SaveEvaluationCallback(response.data);
        });
    }

    $scope.fnCallSOPTemplatePop = function (SOPTemplate) {
        fnOpenSOPTemplate(SOPTemplate);
    }
}
SummaryController.$inject = ['$scope', 'SummaryService', '$filter', 'filterFilter', '$compile', '$rootScope', 'Utils', '$templateCache', '$http', '$parse', 'RelationshipService'];

var SummaryControllerScope = function () {
    return angular.element('[ng-controller=SummaryController]').scope();
}
