﻿//Asset.init.js - module specific initializer - Asset management

angularApp.controller('AssetController', ['$scope', 'cfpLoadingBar', 'AssetConfigService', 'TreeViewPopupService', 'GeneralConfigService', '$parse', function ($scope, cfpLoadingBar, AssetConfigService, TreeViewPopupService, GeneralConfigService, $parse) {
    $scope.SelectedCategory = 0;
   
    $scope.init = function (parameters) {
        $scope.params = parameters;
        AssetConfigService.Init($scope.params);
        $scope.appSettings = $scope.params.appsettingsparams;       
};

    $scope.showCategory = function (callback) {
        AssetConfigService.CategoryCollection().then(function (response) {
            $scope.CategoryList = response.data;
            var PopUpConfig = { content: $scope.CategoryList, title: 'Location Tree', SelectedId: $scope.SelectedCategory, onSelect: callback};
            var popupProvider = TreeViewPopupService.getInstance(PopUpConfig);
            popupProvider.show();
    });
    }

    $scope.getAllLocationsTree = function (callback) {        
        AssetConfigService.AllLocationCollection().then(function (response) {
            $scope.GetAllLocationTree = response.data;
            if (callback) callback();
        });
    }

}]);
var AssetControllerScope = function () {
    return angular.element('[ng-controller=AssetController]').scope();
}