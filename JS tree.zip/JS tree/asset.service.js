﻿angularApp.service('AssetConfigService', ['$http', '$q', function ($http, $q) {
    var Module = 'AM';
    var OrgID = 0, UserID = 0;
    var Instance = '';
    var IncidentWebAPIUrl = '../WS/Asset/TreeViewService.asmx';
    var Parameters;
    this.Init = function (params) {
        Parameter = params;
        OrgID = params.orgid;
        UserID = params.userid;
        Instance = params.instance;
    }

    this.CategoryCollection = function () {
        var webApiurl = IncidentWebAPIUrl + '/GetLocationTree';
        var par = Parameter;        
        var response = $http({
            method: "GET", url: webApiurl, params: { args: JSON.stringify(par) }, headers: { 'Accept': 'application/json, text/javascript', 'Content-Type': 'application/json; charset=utf-8' }
        }).success(function (data, status, headers, config) {
            return data;
        }).error(function (data, status, headers, config) {
            console.log('error');
            return null;
        });
        return response;
    }
    this.AllLocationCollection = function () {
        var webApiurl = IncidentWebAPIUrl + '/GetAllLocationTree';        
        var par = Parameter;
        var response = $http({
            method: "GET", url: webApiurl, params: { args: JSON.stringify(par) }, headers: { 'Accept': 'application/json, text/javascript', 'Content-Type': 'application/json; charset=utf-8' }
        }).success(function (data, status, headers, config) {
            return data;
        }).error(function (data, status, headers, config) {
            console.log('error');
            return null;
        });
        return response;
    }

}]);